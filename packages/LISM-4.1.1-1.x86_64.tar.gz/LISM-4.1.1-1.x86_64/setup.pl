#!/usr/bin/perl
#
#  This code was developped by SECIOSS, Inc. (https://www.secioss.co.jp/).
#
#  Copyright (C) 2017 SECIOSS, Inc.
#  All rights reserved.
#

use 5.016002;

use strict;
use warnings;
use Fcntl;
use Time::HiRes 'sleep';
use Term::ReadKey;
use Term::ReadLine;
use Digest::SHA1;
use DBI;
use XML::Twig;
use Config::General;
use Config::IniFiles;
use PHP::Serialization;
use Cache::Memcached::Fast;
use Net::FTP;
use Net::LDAP;
use Data::Dumper;

#
# 定数
#
use constant { Black=>0, Red=>1, Green=>2, Yellow=>3, Blue=>4, Purple=>5, Cyan=>6, White=>7 }; # 色
use constant { Regular=>0, Bold=>1, Underline=>4 }; # テキスト装飾
use constant { SETTINGS_DAT=>'/opt/secioss/var/lib/setup.dat' }; # 設定ファイル

#
# グローバル変数
#
our $width=`tput cols`;
our $height=`tput lines`;

#
# 関数
#

# 割り込みハンドラー
sub handler {
	my($sig) = @_;
	if ($sig eq "INT") {
		resetTerm();
		exit(0);
	}
	else {
		ReadMode('normal');
		setTextColor(White);
		setBackColor(Black);
	}
}

# ターミナルコンソールのリセット
sub resetTerm {
	printf("\ec"); 
	ReadMode('normal'); # コンソール入力を標準に戻す
}

# ターミナルコンソールの画面クリア
sub clearTerm {
	printf("\e[2J");
	setCursor(1, 1);
}

# カーソル位置の設定
sub setCursor {
	my ($x, $y) = @_;
	# 一番左上の座標が(1,1)
	printf("\e[%d;%dH", $y, $x);
}

# 文字色設定
sub setTextColor {
	my $color = shift;
	my $decoration = shift || Regular;
	# 文字の色
	#　 30 : 黒,  31 : 赤, 32 : 緑, 33 : 黄, 34 : 青, 35 : 紫, 36 : 水, 37 : 白
	printf("\e[".$decoration.";".(30+$color)."m");
}

# 背景色設定
sub setBackColor {
	# 背景色
	#　 40 : 黒, 41 : 赤, 42 : 緑, 43 : 黄, 44 : 青, 45 : 紫, 46 : 水, 47 : 白
	my $color = shift;
	printf("\e[".(40+$color)."m");
}

# 枠描画
sub drawFrame {
	setCursor(1, 1);
	printf("┏");
	for (my $x=2; $x<$width; $x++) {
		printf("━");
	}
	printf("┓");
	
	for (my $y=2; $y<$height; $y++) {
		setCursor(1, $y);
		printf("┃");
		setCursor($width, $y);
		printf("┃");
	}
	
	setCursor(1, $height);
	printf("┗");
	for (my $x=2; $x<$width; $x++) {
		printf("━");
	}
	printf("┛");
	
	setCursor(3, 2);
}

# 内枠描画
sub drawInnerFrame {
	my $y=shift;
	my $height=shift;
	
	setCursor(2, $y);
	printf("┏");
	for (my $x=3; $x<$width-1; $x++) {
		printf("━");
	}
	printf("┓");
	$y++;
	
	for (my $i=0; $i<$height; $i++) {
		setCursor(2, $y);
		printf("┃");
		for (my $x=3; $x<$width-1; $x++) {
			printf(" ");
		}
		setCursor($width-1, $y);
		printf("┃");
		$y++;
	}
	
	setCursor(2, $y);
	printf("┗");
	for (my $x=3; $x<$width-1; $x++) {
		printf("━");
	}
	printf("┛");
}

# スプラッシュスクリーン描画
sub drawTitle {
	setTextColor(White);
	setBackColor(Black);
	
	clearTerm(); # 画面クリア
	
	drawFrame(); # 枠の表示

	my $y = 2;
	setTextColor(Cyan);
	setCursor(2, $y++);printf("  _// //  _////////    _//   _//    _////       _// //    _// //  ");
	setCursor(2, $y++);printf("_//    _//_//       _//   _//_//  _//    _//  _//    _//_//    _//");
	setCursor(2, $y++);printf(" _//      _//      _//       _//_//        _// _//       _//      ");
	setCursor(2, $y++);printf("   _//    _//////  _//       _//_//        _//   _//       _//    ");
	setCursor(2, $y++);printf("      _// _//      _//       _//_//        _//      _//       _// ");
	setCursor(2, $y++);printf("_//    _//_//       _//   _//_//  _//     _// _//    _//_//    _//");
	setCursor(2, $y++);printf("  _// //  _////////   _////  _//    _////       _// //    _// //  ");
	setCursor(2, $y++);printf("                                                                  ");
	setCursor(2, $y++);printf("_//      _//  _// //  _//       _//                               ");
	setCursor(2, $y++);printf("_//      _//_//    _//_/ _//   _///                               ");
	setCursor(2, $y++);printf("_//      _// _//      _// _// _ _//                               ");
	setCursor(2, $y++);printf("_//      _//   _//    _//  _//  _//                               ");
	setCursor(2, $y++);printf("_//      _//      _// _//   _/  _//                               ");
	setCursor(2, $y++);printf("_//      _//_//    _//_//       _//                               ");
	setCursor(2, $y++);printf("_////////_//  _// //  _//       _//                               ");
	setCursor(2, $y++);printf("                                                                  ");
	setCursor(2, $y++);
	setTextColor(White);
	setCursor(2, $y++);printf("                              Copyright (C) 2017 SECIOSS, INC.");
	setCursor(2, $y++);
	setCursor(2, $y++);printf("Press Enter to setup...");
	
	while (<STDIN>) { last; }
}

# メニュー描画
sub selectMenu {
	my $menu_data = shift;
	
	ReadMode('cbreak');
	
	setTextColor(White);
	setBackColor(Black);
	
	clearTerm(); # 画面クリア
	
	drawFrame(); # 枠の表示
	
	# キャプションの表示
	setCursor(3, 2);
	printf("%s", $menu_data->{'caption'});
	setCursor(2, 3);
	for (my $x=2; $x<$width; $x++) {
		printf("-");
	}
	
	# メニュー項目の表示
	my @tmp_items = @{$menu_data->{'items'}};
	my @items = ();
	my $item_start_y=4;
	my $y=$item_start_y;
	foreach my $item (@tmp_items) {
		if (defined($item->{'visible'}) && ! $item->{'visible'}->()) {
			next;
		}
		push(@items, $item);
		
		setCursor(3, $y);
		printf("[ ] %s", $item->{'name'});
		$y++;
	}
	
	# 選択項目にカーソルの表示
	$y=$item_start_y;
	my $input = "";
	while (1) {
		setCursor(4, $y);
		printf("*");
		setCursor(4, $y);
		my $c = ReadKey(1);
		next if (!defined($c));
		last if $c eq "\n";
		
		setCursor(4, $y);
		printf(" ");
		setCursor(4, $y);
		
		$input .= $c;
		if ($input =~ /\e\[A$/) {
			$y -= 1;
		} elsif ($input =~ /\e\[B$/) {
			$y += 1;
		}
		
		if ($y > @items + $item_start_y - 1) {
			$y = @items + $item_start_y - 1;
		} elsif ($y < $item_start_y) {
			$y = $item_start_y;
		}
	}
	
	return $items[$y - $item_start_y]->{'id'};
}

# 入力項目描画
sub inputItems {
	my $items = shift;
	
	resetTerm(); # 画面クリア
	
	setTextColor(White);
	setBackColor(Black);
	
	# キャプションの表示
	my $captions = $items->{'caption'};
	if (ref($captions) ne 'ARRAY') {
		$captions = [ $items->{'caption'} ];
	}
	my $y = 1;
	for my $caption (@$captions) {
		setCursor(1, $y++);
		printf("%s", $caption);
	}
	setCursor(1, $y++);
	for (my $x=1; $x<$width; $x++) {
		printf("-");
	}
	setCursor(1, $y++);
	
	while (1) {
		# 項目の入力
		my $input_map={};
		foreach my $input (@{$items->{'inputs'}}) {
			if ($input->{'type'} eq "password") {
				ReadMode('noecho'); # echo backしない
			} else {
				ReadMode('normal'); # echo backする
			}
			
			# 項目名
			while (1) {
				my $default_value;
				if ($input->{'type'} ne "password" ) {
					# password属性以外なら、前回入力値をdefault valueとして入力する。
					# なかったら指定されたdefault値を使用する。それもないならデフォルト値なし。
					if (defined($input->{'value'})) {
						$default_value = $input->{'value'};
					}
					elsif (defined($input->{'default'})) {
						$default_value = $input->{'default'};
					}
				}
				
				if (defined($input->{'name'})) {
					printf("%sを入力してください。", $input->{'name'});
					printf("%s", $input->{'comment'}) if defined($input->{'comment'});
				}
				elsif (defined($input->{'custom_text'})) {
					print($input->{'custom_text'});
				}
				printf("(default: %s)", $default_value) if defined($default_value);
				printf("\n");
				my $str = readline();
				chomp($str);
				if ($input->{'type'} ne "password" && $default_value && length($str) == 0) {
					# password属性以外で入力値が空文字でデフォルトが設定されているならデフォルト値を使用する。
					$str = $default_value;
				}
				if (!$input->{'nullable'} && length($str) == 0) {
					# nullable属性以外は省略不可とする
					next;
				}
				if (defined($input->{'format'}) && $str !~ /$input->{'format'}/) {
					printf("不正な値が入力されました。\n");
					next;
				}
				$input->{'value'} = $str;
				if ($input->{'type'} eq "password" ) {
					printf("\n");
				}
				last;
			}
			
			$input_map->{$input->{'id'}} = $input;
		}
		
		# 入力チェック
		if (defined($items->{'check'}) && !$items->{'check'}($input_map)) {
			next;
		}
		last;
	}
	
	ReadMode('cbreak');
	
	return 0;
}

# INIファイルアクセスへルパー
sub ini_setval {
	my $file = shift;
	my $section = shift;
	my $parameter = shift;
	my $value = shift;
	
	my $double_quote = 0;
	
	my $old_value = $file->val($section, $parameter);
	if (defined($old_value) && $old_value =~ /^".*"$/) {
		$double_quote = 1;
	}
	elsif ($value =~ /.*=.*/) {
		$double_quote = 1;
	}
	
	if ($double_quote && $value !~ /^".*"$/) {
		$value = '"'.$value.'"';
	}
	
	if (!defined($file->setval($section, $parameter, $value))) {
		$file->newval($section, $parameter, $value);
	}
}

sub ini_getval {
	my $file = shift;
	my $section = shift;
	my $parameter = shift;
	
	my $value = $file->val($section, $parameter);
	$value =~ s/^"(.*)"$/$1/;
	
	return $value
}

sub ini_save {
	my $file = shift;
	
	# Config::IniFiles で 保存時にownerを書き換えてしまうバグがあるため
	my ($dev, $ino, $mode, $nlink, $uid, $gid, $rdev, $size, $atime, $mtime, $ctime, $blksize, $blocks) = stat $file->GetFileName();
	$file->RewriteConfig();
	chown($uid, $gid, $file->GetFileName());
}

# 入力項目の保存
sub update_config {
  my $additional_data = shift;

  my $data = read_config();
  $data = { %{$data}, %{$additional_data} };

  my $file = SETTINGS_DAT;

  sysopen(my $fh, $file, O_WRONLY | O_CREAT | O_TRUNC) or die("failed to open: $file : $!");
  my $serialized = PHP::Serialization::serialize($data);
  print($fh $serialized);
  close($fh);
}

sub read_config {
  my $file = SETTINGS_DAT;

  sysopen(my $fh, $file, O_RDONLY | O_CREAT) or die("failed to open: $file : $!");
  my $serialized = do { local $/ = '\0'; <$fh> };
  my $data ={ };
  if ($serialized) {
    $data = PHP::Serialization::unserialize($serialized);
  }
  close($fh);

  return $data;
}

sub check_selinux {
	my $msg = `/usr/sbin/getenforce`;
	chomp($msg);
	if ($msg =~ /(Permissive)|(Disabled)/i) {
		return;
	}
	
	setBackColor(White);
	
	clearTerm(); # 画面クリア

	my $y = 2;
	setBackColor(White);
	setTextColor(Red, Bold);
	setCursor(2, $y++);printf("LISMはSELinuxに対応しておりません。");
	setCursor(2, $y++);printf("SELinuxを無効化してください。");
	setCursor(2, $y++);printf("");
	setBackColor(White);
	setTextColor(Black, Bold);
	setCursor(2, $y++);printf("Press Enter to end...");
	
	while (<STDIN>) { last; }
	
	resetTerm();
	exit 1;
}

sub create_db_schema {
  my $data = shift;

  my $host = $data->{'mysql'}->{'host'};
  my $port = $data->{'mysql'}->{'port'};
  my $admin = $data->{'mysql'}->{'admin'};
  my $admin_password = $data->{'mysql'}->{'admin_password'};
  my $user = $data->{'mysql'}->{'user'};
  my $password = $data->{'mysql'}->{'password'};

  my $dbh = DBI->connect("DBI:mysql:host=$host;port=$port", $admin, $admin_password);
  if (!$dbh) {
    die("failed to connect db server");
  }

  my $create_db = sub {
    my $database = shift;

    my $rows = $dbh->selectall_arrayref("show databases");
    my $find = undef;
    foreach my $row (@$rows) {
      if ($row->[0] eq $database) {
        $find = 1;
        last;
      }
    }
    if (!$find) {
      if (!$dbh->do("CREATE DATABASE $database")) {
        die("failed to create db:".$dbh->errstr);
      }
    }
    if (!$dbh->do("GRANT ALL ON $database.* to $user")) {
      die("failed to grand authority:".$dbh->errstr);
    }
    if (!$dbh->do("GRANT ALL ON $database.* to $user\@localhost")) {
      die("failed to grand authority:".$dbh->errstr);
    }
    if (!$dbh->do("use $database")) {
      die("failed to use database:".$dbh->errstr);
    }
  };
  my $exists_table = sub {
    my $table = shift;
    my $rows = $dbh->selectall_arrayref("show tables");
    my $find = undef;
    foreach my $row (@$rows) {
      if ($row->[0] eq $table) {
        return 1;
      }
    }
    return undef;
  };

  # create db dlp 
  $create_db->('syslogng');
  if (!$exists_table->('dlp_alert')) {
    if (!$dbh->do("CREATE TABLE dlp_alert ( datetime CHAR(19) NULL, tenant VARCHAR(80) NULL, uid VARCHAR(130) NULL, service VARCHAR(64) NULL, file VARCHAR(255) NULL, msg TEXT ) ENGINE=InnoDB DEFAULT CHARSET=utf8")) {
      die("failed to create table:".$dbh->errstr);
    }
  }

  # set password of connect user
  if (!$dbh->do("SET PASSWORD FOR $user=password('$password')")) {
    die("failed to set password:".$dbh->errstr);
  }
  if (!$dbh->do("SET PASSWORD FOR $user\@localhost=password('$password')")) {
    die("failed to set password:".$dbh->errstr);
  }

  if (!$dbh->do("FLUSH PRIVILEGES")) {
    die("failed to flush privileges:".$dbh->errstr);
  }

  $dbh->disconnect();
}

sub update_sudoers {
	my $data = shift;
	
	sysopen(my $fh, '/etc/sudoers', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	if (defined($data->{'visudo'})) {
		if ($data->{'visudo'}->{'requiretty'} =~ /yes/i) {
			if ($contents !~ s/\n#?\s*(Defaults\s+)!?(requiretty\n)/\n$1!$2/) {
				$contents .= "\nDefaults !requiretty\n";
			}
		}
		
		if ($data->{'visudo'}->{'exec_in_apache'} =~ /yes/i) {
			if ($contents !~ s/\napache\s+.*\n/\napache ALL=\(ALL\) NOPASSWD: \/opt\/secioss\/sbin\/idm_rt.sh\n/) {
				$contents .= "\napache ALL=(ALL) NOPASSWD: /usr/share/seciossadmin/bin/replacecsv.sh, /usr/share/seciossadmin/bin/mkcert.sh, /opt/secioss/sbin/idm_rt.sh\n";
			}
		}
	}
	
	seek($fh, 0, 0);
	print($fh $contents);
	truncate($fh, tell($fh));
	
	close($fh);
}

sub update_secioss_ini_php {
	my $data = shift;
	
	sysopen(my $fh, '/usr/share/seciossadmin/etc/secioss-ini.php', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	# for ldap
	if (defined($data->{'ldap'})) {
		my $uri = $data->{'ldap'}->{'uri'};
		my $basedn = $data->{'ldap'}->{'basedn'};
		my $binddn = $data->{'ldap'}->{'binddn'};
		my $bindpw = $data->{'ldap'}->{'bindpw'};
		
		if ($contents !~ s/('ou=Master,[^']+'\s=>\sarray\(\s*\n\s*'uri'\s*=>\s*')([^']+)(')/$1$uri$3/g) {
			die("failed to update secioss-ini.php");
		}
		if ($contents !~ s/('ou=LDAP,[^']+'\s=>\sarray\(\s*\n\s*'uri'\s*=>\s*')([^']+)(')/$1$uri$3/g) {
			die("failed to update secioss-ini.php");
		}
		if ($contents !~ s/('binddn'\s*=>\s*')([^']+)(')/$1$binddn$3/g) {
			die("failed to update secioss-ini.php");
		}
		if ($contents !~ s/('bindpw'\s*=>\s*')([^']+)(')/$1$bindpw$3/g) {
			die("failed to update secioss-ini.php");
		}
		if ($contents !~ s/('basedn'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
			die("failed to update secioss-ini.php");
		}
		if ($contents !~ s/('realnc'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
			die("failed to update secioss-ini.php");
		}
		if ($contents !~ s/('suffix'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
			die("failed to update secioss-ini.php");
		}
		if ($contents !~ s/('ou=[^,]+,)([^']+)('\s*=>\s*array)/$1$basedn$3/g) {
			die("failed to update secioss-ini.php");
		}
		if ($contents !~ s/('ou=\[\^,)([^']+)('\s*=>\s*array)/'ou=[^,]+,$basedn$3/g) {
			die("failed to update secioss-ini.php");
		}
	}
	
	# for mysql
	if (defined($data->{'mysql'})) {
		my $host = $data->{'mysql'}->{'host'};
		my $port = $data->{'mysql'}->{'port'};
		my $user = $data->{'mysql'}->{'user'};
		my $password = $data->{'mysql'}->{'password'};
		if ($contents !~ s/('db'\s*=>\s*array\(\s*'host'\s*=>\s*')([^']+)(',\s*'user'\s*=>\s*')([^']+)(',\s*'password'\s*=>\s*')([^']+)(',[^)]+\))/$1$host:$port$3$user$5$password$7/gs) {
			die("failed to update secioss-ini.php");
		}
	}
	
	# for memcached
	if (defined($data->{'memcached'})) {
		my $index = 0;
		my $str_memcached = '';
		my $hosts = $data->{'memcached'}->{'hosts'};
		foreach my $host (@$hosts) {
			$str_memcached .= "$index => array('memcache_host' => '$host->{'host'}', 'memcache_port' => $host->{'port'}),\n";
			
			$index ++;
		}
		
		if ($contents !~ s/('memcache'\s*=>\s*array\(\s*'ethna_app_manager'\s*=>\s*array\(\s*)([0-9]+\s*=>\s*array\([^)]+\),?\s*)+(\),?\s*\),?)/$1$str_memcached$3/s) {
			die("failed to update secioss-ini.php");
		}
	}
	
	# for office365
	if (defined($data->{'office365'})) {
		my $host = $data->{'office365'}->{'host'};
		if ($contents !~ s/('office365'\s*=>\s*array\(\s*'host'\s*=>\s*')([^']*)(',\s*'username'[^)]+\))/$1$host$3/s) {
			die("failed to update secioss-ini.php");
		}
	};
	
	seek($fh, 0, 0);
	print($fh $contents);
	truncate($fh, tell($fh));
	
	close($fh);
}

sub update_lism_conf {
	my $data = shift;
	
	sysopen(my $fh, '/opt/secioss/etc/lism.conf', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	# for ldap
	if (defined($data->{'ldap'})) {
		my $uri = $data->{'ldap'}->{'uri'};
		my $basedn = $data->{'ldap'}->{'basedn'};
		my $binddn = $data->{'ldap'}->{'binddn'};
		my $bindpw = $data->{'ldap'}->{'bindpw'};

		if ($contents !~ /<storage master="true" [^>]*name="LDAP"[^>]*>(.*?)<\/storage>/s) {
			die("failed to update lism.conf configuration");
		}
		my $inner_storage = $1;
		if ($inner_storage !~ s/<uri>(ldaps?:\/\/[^\/]+)\/([^<]*)<\/uri>/<uri>$uri\/$basedn<\/uri>/) {
			die("failed to update lism.conf ldap uri");
		}
		my $basedn_org = $2;
		if ($inner_storage !~ s/<binddn>([^<]+)<\/binddn>/<binddn>$binddn<\/binddn>/) {
			die("failed to update lism.conf ldap binddn");
		}
		if ($inner_storage !~ s/<bindpw>([^<]+)<\/bindpw>/<bindpw>$bindpw<\/bindpw>/) {
			die("failed to update lism.conf ldap bindpw");
		}
		if ($contents !~ s/$basedn_org/$basedn/g)  {
			die("failed to update lism.conf");
		}
		if ($contents !~ s/(<storage master="true" [^>]*name="LDAP"[^>]*>).*?(<\/storage>)/$1$inner_storage$2/s) {
			die("failed to update lism.conf configuration");
		}
	}
	
	# for mysql
	if (defined($data->{'mysql'})) {
		if ($contents !~ s/(<db dsn="DBI:mysql:database=[^;]+;host=)([^;]+)(;port=)([0-9]+)(" admin=")([^"]+)(" passwd=")([^"]+)("\s*\/>)/$1$data->{'mysql'}->{'host'}$3$data->{'mysql'}->{'port'}$5$data->{'mysql'}->{'user'}$7$data->{'mysql'}->{'password'}$9/gs) {
			die("failed to update lism.conf");
		}
		if ($contents !~ s/(<dsn>DBI:mysql:database=[^;]+;host=)([^;]+)(;port=)([0-9]+)(<\/dsn>\s*<admin>)([^<]+)(<\/admin>\s*<passwd>)([^<]+)(<\/passwd>)/$1$data->{'mysql'}->{'host'}$3$data->{'mysql'}->{'port'}$5$data->{'mysql'}->{'user'}$7$data->{'mysql'}->{'password'}$9/gs) {
			# 無い場合も許容
			# die("failed to update lism.conf");
		}
	}
	
	seek($fh, 0, 0);
	print($fh $contents);
	truncate($fh, tell($fh));
	
	close($fh);
}

sub update_slapd_conf {
	my $data = shift;
	
	sysopen(my $fh, '/opt/secioss/etc/openldap/slapd.conf', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	# for ldap
	if (defined($data->{'ldap'})) {
		my $basedn = $data->{'ldap'}->{'basedn'};
		my $binddn = $data->{'ldap'}->{'binddn'};
		my $bindpw = $data->{'ldap'}->{'bindpw'};
		
		if ($contents !~ s/(suffix\s+)"([^"]+)"/$1"$basedn"/)  {
			die("failed to update slapd.conf");
		}
		if ($contents !~ s/(basedn\s+)"([^"]+)"/$1"$basedn"/)  {
			die("failed to update slapd.conf");
		}
		if ($contents !~ s/(admindn\s+)"([^"]+)"/$1"$binddn"/)  {
			die("failed to update slapd.conf");
		}
		if ($contents !~ s/(adminpw\s+)"([^"]+)"/$1"$bindpw"/)  {
			die("failed to update slapd.conf");
		}
		if ($contents !~ s/(auditformat\s+".*\s+dn=\\"[^"]+\),)[^"]+("\s+.*\s+dn=\\"[^"]*\$11,)[^"]+(".*)/$1$basedn\\$2$basedn\\$3/)  {
			die("failed to update slapd.conf");
		}
	}
	
	seek($fh, 0, 0);
	print($fh $contents);
	truncate($fh, tell($fh));
	
	close($fh);
}

sub update_lapd_conf {
	my $data = shift;
	
	sysopen(my $fh, '/etc/openldap/ldap.conf', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	if ($contents !~ s/^(TLS_REQCERT\s+)(\S+)$/$1never/m)  {
		$contents .= "\nTLS_REQCERT	never\n";
	}
	
	seek($fh, 0, 0);
	print($fh $contents);
	truncate($fh, tell($fh));
	
	close($fh);
}

sub update_httpd_conf {
	my $data = shift;
	
	sysopen(my $fh, '/etc/httpd/conf/httpd.conf', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	if (defined($data->{'fqdn'})) {
		my $fqdn = $data->{'fqdn'}->{'fqdn'};
		
		if ($contents !~ s/^(ServerName\s+)([-_.0-9A-Za-z]{1,255}(?::[0-9]+)?)/$1$fqdn:80/gm) {
			if ($contents !~ s/^(#ServerName\s+.*\n)/$1ServerName $fqdn:80/gm) {
				die("failed to update ssl.conf");
			}
		}
	}
	
	if ($contents !~ /^IncludeOptional +sso\/\*\.conf$/m) {
		$contents .= "\nIncludeOptional sso\/*.conf\n";
	}
	
	seek($fh, 0, 0);
	print($fh $contents);
	truncate($fh, tell($fh));
	
	close($fh);
}

sub update_ssl_conf {
	my $data = shift;
	
	sysopen(my $fh, '/etc/httpd/conf.d/ssl.conf', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	if (defined($data->{'fqdn'})) {
		my $fqdn = $data->{'fqdn'}->{'fqdn'};
		
		if ($contents !~ s/^(ServerName\s+)([-_.0-9A-Za-z]{1,255}(?::[0-9]+)?)/$1$fqdn:443/gm) {
			if ($contents !~ s/^(#ServerName\s+.*\n)/$1ServerName $fqdn:443/gm) {
				die("failed to update ssl.conf");
			}
		}
	}
	
	if ($contents !~ /^IncludeOptional +sso\/\*\.conf$/m) {
		$contents =~ s/(<\/VirtualHost>)/IncludeOptional sso\/*.conf\n$1/m
	}
	if ($contents !~ /^IncludeOptional +sso-ssl\/\*\.conf$/m) {
		$contents =~ s/(<\/VirtualHost>)/IncludeOptional sso-ssl\/*.conf\n$1/m
	}
	
	seek($fh, 0, 0);
	print($fh $contents);
	truncate($fh, tell($fh));
	
	close($fh);
}

sub update_php_ini {
	my $data = shift;
	
	my $file = Config::IniFiles->new( -file => "/etc/php.ini" ) or die "failed to open: @Config::IniFiles::errors";
	
	if (defined($data->{'memcached'})) {
		my $str_memcached = '';
		my $hosts = $data->{'memcached'}->{'hosts'};
		foreach my $host (@$hosts) {
			$str_memcached .= ',' if $str_memcached;
			$str_memcached .=  "tcp://$host->{'host'}:$host->{'port'}?timeout=3&retry_interval=60";
		}
		
		ini_setval($file, 'Session', 'session.save_handler', 'memcache');
		ini_setval($file, 'Session', 'session.save_path', '"'.$str_memcached.'"');
		ini_setval($file, 'Session', 'session.name', 'samsessid');
	}
	
	ini_save($file);
}

sub update_config_ini {
	my $data = shift;
	my $ldap_uri;
	
	my $file = Config::IniFiles->new( -file => "/var/www/conf/config.ini", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";
	
	if (defined($data->{'ldap'})) {
		ini_setval($file, "password", 'uri', '"'.$data->{'ldap'}->{'uri'}.'"');
		ini_setval($file, "password", 'binddn', '"'.$data->{'ldap'}->{'binddn'}.'"');
		ini_setval($file, "password", 'bindpw', '"'.$data->{'ldap'}->{'bindpw'}.'"');
		ini_setval($file, "password", 'basedn', '"'.$data->{'ldap'}->{'basedn'}.'"');
		ini_setval($file, "password", 'api_basedn', '"ou=Master,'.$data->{'ldap'}->{'basedn'}.'"');
		
		ini_setval($file, "account", 'uri', '"'.$data->{'ldap'}->{'uri'}.'"');
		ini_setval($file, "account", 'binddn', '"'.$data->{'ldap'}->{'binddn'}.'"');
		ini_setval($file, "account", 'bindpw', '"'.$data->{'ldap'}->{'bindpw'}.'"');
		ini_setval($file, "account", 'basedn', '"'.$data->{'ldap'}->{'basedn'}.'"');
		ini_setval($file, "account", 'api_basedn', '"ou=Master,'.$data->{'ldap'}->{'basedn'}.'"');

	}
	
	ini_save($file);
}

sub update_passwd {
	my $data = shift;
	
	if (defined($data->{'general'}->{'admin_password'})) {
		my $password = $data->{'general'}->{'admin_password'};
		my $rc = system("htpasswd -bv /usr/share/seciossadmin/etc/passwd admin '$password' >&/dev/null");
		if ($rc) {
			system("touch /usr/share/seciossadmin/etc/passwd");
			$rc = system("htpasswd -bcd /usr/share/seciossadmin/etc/passwd admin '$password' >&/dev/null");
			if ($rc) {
				die("failed to update passwd");
			}
		}
		
		$rc = chmod(0644, ("/usr/share/seciossadmin/etc/passwd"));
		if ($rc != 0) {
			$rc = chown(48, 48, ("/usr/share/seciossadmin/etc/passwd")); # apache:apache
		}
		if ($rc == 0) {
			die("failed to change permission");
		}
	}
}

sub update_auth_tkt_conf {
	my $data = shift;
	
	sysopen(my $fh, '/opt/secioss/etc/auth_tkt.conf', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	if (defined($data->{'general'}->{'admin_password'})) {
		my $secret = Digest::SHA1::sha1_base64($data->{'general'}->{'admin_password'});
		
		if ($contents !~ s/(TKTAuthSecret\s+)"[^"]+"/$1"$secret"/s)  {
			die("failed to update auth_tkt.conf");
		}
	}
	
	seek($fh, 0, 0);
	print($fh $contents);
	truncate($fh, tell($fh));
	
	close($fh);
}

sub config_fqdn {
	sysopen(my $fh, '/etc/httpd/conf.d/ssl.conf', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	
	my $fqdn;
	if ($contents =~ /^(ServerName\s+)([-_.0-9A-Za-z]{1,255}(?::[0-9]+)?)/gm) {
		$fqdn = $1;
	}
	
	if (!defined($fqdn) || $fqdn !~ s/^https?:\/\/([^\/]+)\/.*/$1/g) {
		$fqdn = `hostname`;
		chomp($fqdn);
	}
	
	# 項目の入力
	my $items = {
		'caption' => "FQDNの設定を行います。",
		'inputs' => [
			{
				'id' => 'fqdn',
				'name' => 'FQDN',
				'type' => 'text',
				'format' => '^[-_.0-9A-Za-z]{1,255}$',
				'default' => $fqdn,
			},
		],
	};
	inputItems($items);
	
	# 設定更新
	my $data = {
		'fqdn' => {
			'fqdn' => $items->{'inputs'}->[0]->{'value'},
		}
	};
	
	# httpd.conf 設定更新
	update_httpd_conf($data);
	
	# ssl.conf 設定更新
	update_ssl_conf($data);
	
	return 1;
}

sub config_visudo {
	# 項目の入力
	my $items = {
		'caption' => "sudoの設定変更を行います。",
		'inputs' => [
			{
				'id' => 'requiretty',
				'custom_text' => 'requirettyを無効にします。よろしいですか？ [yes/no]',
				'type' => 'text',
				'default' => 'yes',
				'format' => '^(yes)|(no)$',
			},
			{
				'id' => 'exec_in_apache',
				'custom_text' => 'apacheユーザーにコマンド実行時の昇格権限を付与します。よろしいですか？ [yes/no]',
				'type' => 'text',
				'default' => 'yes',
				'format' => '^(yes)|(no)$',
			},
		],
	};
	inputItems($items);
	
	my $use = $items->{'inputs'}->[0]->{'value'};
	
	my $data = {
		'visudo' => {
			'requiretty' => $items->{'inputs'}->[0]->{'value'},
			'exec_in_apache' => $items->{'inputs'}->[1]->{'value'},
		}
	};
	
	# sudoers 設定更新
	update_sudoers($data);
	
	return 1;
}

sub create_pw_words {
	# 項目の入力
	my $items = {
		'caption' => "パスワード辞書ファイルを作成します。",
		'inputs' => [
			{
				'id' => 'agree',
				'custom_text' => 'yumリポジトリから最新の辞書ファイルをインストールします。よろしいですか？[yes/no]',
				'type' => 'text',
				'default' => 'yes',
				'format' => '^(yes)|(no)$',
			},
		],
	};
	inputItems($items);
	
	my $agree = $items->{'inputs'}->[0]->{'value'};
	if ($agree =~ /yes/) {
		my $err = `yum -y install words 2>&1`;
		my $rc = $?;
		if ($rc) {
			die($err);
		}
		
		$err = `create-cracklib-dict /usr/share/dict/linux.words 2>&1`;
		if ($rc) {
			die($err);
		}
	}
	
	return 1;
}

sub build_ldap {
	return 0;
}

sub config_ldap {
	sysopen(my $fh, '/opt/secioss/etc/lism.conf', O_RDWR) or die("failed to open: $!");
	my $contents = do { local $/ = '\0'; <$fh> };
	close($fh);
	if ($contents !~ /<storage master="true" [^>]*name="LDAP"[^>]*>(.*?)<\/storage>/s) {
		die("failed to get ldap configuration");
	}
	my $inner_storage = $1;
	if ($inner_storage !~ /<uri>(ldaps?:\/\/[^\/]+)\/([^<]*)<\/uri>/) {
		die("failed to get ldap uri configuration");
	}
	my $ldapuri = $1;
	my $basedn = $2;
	if ($inner_storage !~ /<binddn>([^<]+)<\/binddn>/) {
		die("failed to get ldap binddn configuration");
	}
	my $binddn = $1;
	if ($inner_storage !~ /<bindpw>([^<]+)<\/bindpw>/) {
		die("failed to get ldap bindpw configuration");
	}
	my $bindpw = $1;
	
	# 項目の入力
	my $items = {
		'caption' => "LDAPサーバーの設定を行います。",
		'inputs' => [
			{
				'id' => 'ldapuri',
				'name' => 'LDAP-URI',
				'type' => 'text',
				'format' => '^ldaps?://[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?$',
				'default' => $ldapuri,
			},
			{
				'id' => 'basedn',
				'name' => 'BaseDN',
				'type' => 'text',
				'default' => $basedn,
			},
			{
				'id' => 'binddn',
				'name' => 'BindDN',
				'type' => 'text',
				'default' => $binddn,
			},
			{
				'id' => 'bindpw',
				'name' => 'Password',
				'type' => 'password',
			},
		],
		'check' => sub {
			my $input_map = shift;
			
			my $ldap = Net::LDAP->new($input_map->{'ldapuri'}->{'value'});
			if (!defined($ldap)) {
				printf("LDAPサーバーへの接続に失敗しました。[%s]\n", $input_map->{'ldapuri'}->{'value'});
				return 0;
			}
			
			my $msg = $ldap->bind($input_map->{'binddn'}->{'value'}, password => $input_map->{'bindpw'}->{'value'});
			if($msg->code) {
				printf("LDAPサーバーの認証に失敗しました。[%s][%s]\n", $msg->code, $msg->error);
				return 0;
			}
			
			$msg = $ldap->search(base => $input_map->{'basedn'}->{'value'}, filter => '(objectClass=*)', scope => 'one');
			if($msg->code) {
				printf("LDAPサーバーの検索に失敗しました。[%s][%s]\n", $msg->code, $msg->error);
				return 0;
			}
			
			$ldap->unbind;
			
			return 1;
		},
	};
	inputItems($items);
	
	# 設定更新
	my $data = {
		'ldap' => {
			'uri' => $items->{'inputs'}->[0]->{'value'},
			'basedn' => $items->{'inputs'}->[1]->{'value'},
			'binddn' => $items->{'inputs'}->[2]->{'value'},
			'bindpw' => $items->{'inputs'}->[3]->{'value'},
		}
	};
	
	# lism.conf 設定更新
	update_lism_conf($data);
	
	# slapd.conf 設定更新
	update_slapd_conf($data);
	
	# lapd.conf 設定更新
	update_lapd_conf($data);
	
	# secioss-ini.php 設定更新
	update_secioss_ini_php($data);
	
	# config.ini 設定更新
	update_config_ini($data);
	
	return 1;
}

sub build_mysql {
  # 現在の設定値の取得
  my $file = '/usr/share/seciossadmin/etc/secioss-ini.php';
  sysopen(my $fh, $file, O_RDONLY) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };
  close($fh);

  if ($contents !~ /'db'\s*=>\s*array\(\s*'host'\s*=>\s*'([^']+)',\s*'user'\s*=>\s*'([^']+)',\s*'password'\s*=>\s*'([^']+)',[^)]+\)/s) {
    die("failed to read mysql configuration");
  }
  my $host = $1;
  my $user = $2;
  my $password = $3;

  # 項目の入力
  my $items = {
    'caption' => "DBサーバの初期設定（テーブルの作成、接続ユーザの作成など）を行います。",
    'inputs' => [
      {
        'id' => 'host',
        'name' => 'DBサーバ',
        'type' => 'text',
        'default' => $host,
        'format' => '^[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?$',
      },
      {
        'id' => 'admin',
        'name' => '管理者ユーザ',
        'type' => 'text',
        'default' => 'root',
      },
      {
        'id' => 'admin_password',
        'name' => '管理者ユーザのパスワード',
        'type' => 'password',
        'nullable' => 1,
      },
      {
        'id' => 'user',
        'name' => 'Identity Managerからの接続に使用する接続ユーザ',
        'comment' => '存在しない場合は新規作成します。',
        'type' => 'text',
        'default' => $user,
      },
      {
        'id' => 'password',
        'name' => '接続ユーザのパスワード',
        'type' => 'password',
      },
      {
        'id' => 'confirm',
        'name' => '接続ユーザのパスワード(再入力)',
        'type' => 'password',
      },
    ],
    'check' => sub {
      my $input_map = shift;

      my $host = $input_map->{'host'}->{'value'};
      $host =~ s/^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/$1/;
      my $port = $2 || 3306;
      my $admin = $input_map->{'admin'}->{'value'};
      my $admin_password = $input_map->{'admin_password'}->{'value'};
      my $password = $input_map->{'password'}->{'value'};
      my $confirm = $input_map->{'confirm'}->{'value'};

      if ($password ne $confirm) {
        printf("入力されたパスワードが一致しません。\n");
        return 0;
      }

      #  MySQL接続テスト
      my $dbh = DBI->connect("DBI:mysql:host=$host;port=$port", $admin, $admin_password);
      if (!$dbh) {
        printf("MySQLサーバへの接続に失敗しました。[%s:%d]\n", $host, $port);
        return 0;
      }
      $dbh->disconnect();

      return 1;
    },
  };
  inputItems($items);

  # 設定更新
  $host = $items->{'inputs'}->[0]->{'value'};
  $host =~ s/^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/$1/;
  my $port = $2 || 3306;

  my $data = {
    'mysql' => {
      'host' => $host,
      'port' => $port,
      'admin' => $items->{'inputs'}->[1]->{'value'},
      'admin_password' => $items->{'inputs'}->[2]->{'value'},
      'user' => $items->{'inputs'}->[3]->{'value'},
      'password' => $items->{'inputs'}->[4]->{'value'},
    }
  };

  if ($data->{'mysql'}->{'host'} =~ /^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/) {
    $data->{'mysql'}->{'host'} = $1;
    if ($2) {
      $data->{'mysql'}->{'port'} = $2;
    }
  }

  # DBの初期設定
  create_db_schema($data);

  # secioss-ini.php 設定更新
  update_secioss_ini_php($data);

  # 入力項目の保存
  update_config($data);

  return 1;
}

sub config_mysql {
  # 現在の設定値の取得
  my $file = '/usr/share/seciossadmin/etc/secioss-ini.php';
  sysopen(my $fh, $file, O_RDONLY) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };
  close($fh);

  if ($contents !~ /'db'\s*=>\s*array\(\s*'host'\s*=>\s*'([^']+)',\s*'user'\s*=>\s*'([^']+)',\s*'password'\s*=>\s*'([^']+)',[^)]+\)/s) {
    die("failed to read mysql configuration");
  }
  my $host = $1;
  my $user = $2;
  my $password = $3;

  # 項目の入力
  my $items = {
    'caption' => "DBサーバへの接続情報の設定を行います。",
    'inputs' => [
      {
        'id' => 'host',
        'name' => 'DBサーバ',
        'type' => 'text',
        'default' => $host,
        'format' => '^[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?$',
      },
      {
        'id' => 'user',
        'name' => '接続ユーザ',
        'type' => 'text',
        'default' => $user,
      },
      {
        'id' => 'password',
        'name' => '接続ユーザのパスワード',
        'type' => 'password',
      },
    ],
    'check' => sub {
      my $input_map = shift;

      my $host = $input_map->{'host'}->{'value'};
      $host =~ s/^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/$1/;
      my $port = $2 || 3306;
      my $user = $input_map->{'user'}->{'value'};
      my $password = $input_map->{'password'}->{'value'};

      #  MySQL接続テスト
      my $dbh = DBI->connect("DBI:mysql:host=$host;port=$port", $user, $password);
      if (!$dbh) {
        printf("MySQLサーバへの接続に失敗しました。[%s:%d]\n", $host, $port);
        return 0;
      }
      $dbh->disconnect();

      return 1;
    },
  };
  inputItems($items);

  # 設定更新
  my $data = {
    'mysql' => {
      'host' => $items->{'inputs'}->[0]->{'value'},
      'port' => 3306,
      'user' => $items->{'inputs'}->[1]->{'value'},
      'password' => $items->{'inputs'}->[2]->{'value'},
    }
  };

  if ($data->{'mysql'}->{'host'} =~ /^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/) {
    $data->{'mysql'}->{'host'} = $1;
    if ($2) {
      $data->{'mysql'}->{'port'} = $2;
    }
  }

  # secioss-ini.php 設定更新
  update_secioss_ini_php($data);

  # 入力項目の保存
  update_config($data);

  return 1;
}

sub config_memcached {
	# 現在の設定値の取得
	my $file = Config::IniFiles->new( -file => "/etc/php.ini" ) or die "failed to open: @Config::IniFiles::errors";
	my $values = ini_getval($file, 'Session', 'session.save_path');
	my $default_value = '';
	while ($values =~ /tcp:\/\/([-_.0-9A-Za-z]{1,255}:[0-9]{1,5})(\?(\w+=[0-9]+)(&(\w+=[0-9]+))*)/) {
		my $value = $1;
		$values = $';
		
		$default_value .= ',' if $default_value;
		$default_value .= $value;
	}
	if (!$default_value) {
		$default_value = 'localhost:11211';
	}
	
	# 項目の入力
	my $items = {
		'caption' => "memcachedサーバーの設定をします。",
		'inputs' => [
			{
				'id' => 'hosts',
				'name' => 'memcachedサーバー',
				'comment' => 'カンマ区切りで複数指定できます。',
				'type' => 'text',
				'default' => $default_value,
				'format' => '^[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?(,[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?)*$',
			},
		],
		'check' => sub {
			my $input_map = shift;
			
			# memcached接続テスト
			my $hosts = $input_map->{'hosts'}->{'value'};
			while ($hosts =~ /([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5})?)/) {
				my $host = $1;
				my $port = $2 || 11211;
				$hosts = $';
				
				my $memd = Cache::Memcached::Fast->new({ servers => [ { address => $host.':'.$port }] }); 
				if (!defined($memd->server_versions) || !%{$memd->server_versions}) {
					printf("memcachedサーバーへの接続に失敗しました。[%s]\n", $host.':'.$port);
					return 0;
				}
			}
			
			return 1;
		},
	};
	inputItems($items);
	
	# 設定更新
	my $data = {
		'memcached' => {
			'hosts' => [
			]
		}
	};
	
	my $hosts = $items->{'inputs'}->[0]->{'value'};
	while ($hosts =~ /([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?/) {
		my $host = $1;
		my $port = $2 || 11211;
		$hosts = $';
		
		push(@{$data->{'memcached'}->{'hosts'}}, {'host' => $host, 'port' => $port});
	}
	
	# php.ini 設定更新
	update_php_ini($data);
	
	# secioss-ini.php 設定更新
	update_secioss_ini_php($data);
	
	return 1;
}

sub set_admin_password {
	# 項目の入力
	my $items = {
		'caption' => "LISM 管理者パスワードを設定します。",
		'inputs' => [
			{
				'id' => 'password',
				'name' => '管理者パスワード',
				'type' => 'password',
				'format' => '^[!-~]{1,32}$',
			},
			{
				'id' => 'confirm',
				'name' => '管理者パスワード(再入力)',
				'type' => 'password',
			},
		],
		'check' => sub {
			my $input_map = shift;
			if ($input_map->{'password'}->{'value'} ne $input_map->{'confirm'}->{'value'}) {
				printf("入力されたパスワードが一致しません。\n");
				return 0;
			}
			return 1;
		},
	};
	inputItems($items);
	
	my $data = {
		'general' => {
			'admin_password' => $items->{'inputs'}->[0]->{'value'}
		}
	};
	
	update_passwd($data);
	
	update_auth_tkt_conf($data);
	
	return 1;
}

sub restart_daemon {
	# 項目の入力
	my $items = {
		'caption' => "サービスの再起動を行います。",
		'inputs' => [
			{
				'id' => 'httpd',
				'custom_text' => 'httpdを再起動しますか？ [yes/no]',
				'type' => 'text',
				'default' => 'yes',
				'format' => '^(yes)|(no)$',
			},
			{
				'id' => 'openldap-lism',
				'custom_text' => 'openldap-lismを再起動しますか？ [yes/no]',
				'type' => 'text',
				'default' => 'yes',
				'format' => '^(yes)|(no)$',
			},
		],
	};
	inputItems($items);
	
	foreach my $item(@{$items->{'inputs'}}) {
		my $service = $item->{'id'};
		my $value = $item->{'value'};
		if ($value =~ /yes/i) {
			printf("%sを再起動しています。\n", $service);
			my $msg = `/bin/systemctl restart $service 2>&1`;
			if ($?) {
				die("failed in restart $service:$msg");
			}
		}
	}
	
	return 1;
}

sub stop_daemon {
	# 項目の入力
	my $items = {
		'caption' => "サービスの停止を行います。",
		'inputs' => [
			{
				'id' => 'httpd',
				'custom_text' => 'httpdを停止しますか？ [yes/no]',
				'type' => 'text',
				'default' => 'yes',
				'format' => '^(yes)|(no)$',
			},
			{
				'id' => 'openldap-lism',
				'custom_text' => 'openldap-lismを停止しますか？ [yes/no]',
				'type' => 'text',
				'default' => 'yes',
				'format' => '^(yes)|(no)$',
			},
		],
	};
	inputItems($items);
	
	foreach my $item(@{$items->{'inputs'}}) {
		my $service = $item->{'id'};
		my $value = $item->{'value'};
		if ($value =~ /yes/i) {
			printf("%sを停止しています。\n", $service);
			my $msg = `/bin/systemctl stop $service 2>&1`;
			if ($?) {
				die("failed in restart $service:$msg");
			}
		}
	}
	
	return 1;
}

#
# メイン処理
#
sub main {
	STDOUT->autoflush(1); # AutoFlush有効化

	ReadMode('cbreak');

	# シグナルハンドラーのセット
	$SIG{'INT'} = \&handler;
	$SIG{__DIE__} = \&handler;

	drawTitle();
	
	check_selinux(); # SELinuxチェック
	
	my $menu_data = {
		'caption' => "設定する項目を選んでください。",
		'items' => [
			{
				'id' => 'config_fqdn',
				'name' => 'FQDNの設定',
			},
			{
				'id' => 'config_visudo',
				'name' => 'visudoの設定変更',
			},
			{
				'id' => 'create_pw_words',
				'name' => 'パスワード辞書ファイルの作成',
			},
#			{
#				'id' => 'build_ldap',
#				'name' => 'LDAPサーバーの初期設定',
#			},
			{
				'id' => 'config_ldap',
				'name' => 'LDAPサーバーへの接続設定',
			},
			{
				'id' => 'build_mysql',
				'name' => 'DBサーバの初期設定',
			},
			{
				'id' => 'config_mysql',
 				'name' => 'DBサーバへの接続設定',
			},
			{
				'id' => 'config_memcached',
				'name' => 'memcachedサーバーへの接続設定',
			},
			{
				'id' => 'set_admin_password',
				'name' => '管理者パスワードの設定',
			},
			{
				'id' => 'restart_daemon',
				'name' => 'サービスの再起動',
			},
			{
				'id' => 'stop_daemon',
				'name' => 'サービスの停止',
			},
			{
				'id' => 'end',
				'name' => '終了',
			},
		]
	};

	while (1) {
		my $select_id = selectMenu($menu_data);

		if (!$select_id) {
			next;
		}
		elsif ($select_id eq 'end') {
			last;
		}
		else {
			my $r = eval "$select_id()";
			my $error = $@;
			if ($error) {
				$error =~ s/\s+at\s+.*$//;
				warn $error;
			}
			elsif (!$r) {
				next;
			}
			else {
				foreach my $item (@{$menu_data->{'items'}}) {
					if ($item->{'id'} eq $select_id) {
						printf("\n\n%sが完了しました。\n", $item->{'name'});
					}
				}
			}
		}
		
		print("\n\nPress Enter to continue.");
		while (<STDIN>) { last; }
	}

	resetTerm();
}
main;
