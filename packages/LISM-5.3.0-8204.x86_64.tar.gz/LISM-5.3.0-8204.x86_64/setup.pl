#!/usr/bin/perl
#
#  This code was developped by SECIOSS, Inc. (https://www.secioss.co.jp/).
#
#  Copyright (C) 2022 SECIOSS, Inc.
#  All rights reserved.
#

use 5.026003;

use strict;
use warnings;
use Encode;
use Fcntl;
use FindBin;
use File::Copy;
use File::Path;
use File::Spec;
use Getopt::Std;
use String::Random;
use Time::HiRes 'sleep';
use Term::ReadKey;
use Term::ReadLine;
use Digest::SHA;
use DBI;
use XML::Twig;
use Config::General;
use Config::IniFiles;
use JSON qw/encode_json decode_json/;
use Cache::Memcached::libmemcached;
use Net::FTP;
use Net::LDAP;
use Data::Dumper;

#
# 定数
#
use constant { Black=>0, Red=>1, Green=>2, Yellow=>3, Blue=>4, Purple=>5, Cyan=>6, White=>7 }; # 色
use constant { Regular=>0, Bold=>1, Underline=>4 }; # テキスト装飾
use constant { SETTINGS_DAT=>'/opt/secioss/var/lib/setup.dat' }; # 設定ファイル

#
# グローバル変数
#
our $width=`tput cols`;
our $height=`tput lines`;

#
# 関数
#

# 割り込みハンドラー
sub handler {
  my($sig) = @_;
  if ($sig eq "INT") {
    resetTerm();
    exit(0);
  }
  else {
    ReadMode('normal');
    setTextColor(White);
    setBackColor(Black);
  }
}

# ターミナルコンソールのリセット
sub resetTerm {
  printf("\ec");
  ReadMode('normal'); # コンソール入力を標準に戻す
}

# ターミナルコンソールの画面クリア
sub clearTerm {
  printf("\e[2J");
  setCursor(1, 1);
}

# カーソル位置の設定
sub setCursor {
  my ($x, $y) = @_;
  # 一番左上の座標が(1,1)
  printf("\e[%d;%dH", $y, $x);
}

# 文字色設定
sub setTextColor {
  my $color = shift;
  my $decoration = shift || Regular;
  # 文字の色
  #　 30 : 黒,  31 : 赤, 32 : 緑, 33 : 黄, 34 : 青, 35 : 紫, 36 : 水, 37 : 白
  printf("\e[".$decoration.";".(30+$color)."m");
}

# 背景色設定
sub setBackColor {
  # 背景色
  #　 40 : 黒, 41 : 赤, 42 : 緑, 43 : 黄, 44 : 青, 45 : 紫, 46 : 水, 47 : 白
  my $color = shift;
  printf("\e[".(40+$color)."m");
}

# 枠描画
sub drawFrame {
  setCursor(1, 1);
  printf("┏");
  for (my $x=2; $x<$width; $x++) {
    printf("━");
  }
  printf("┓");

  for (my $y=2; $y<$height; $y++) {
    setCursor(1, $y);
    printf("┃");
    setCursor($width, $y);
    printf("┃");
  }

  setCursor(1, $height);
  printf("┗");
  for (my $x=2; $x<$width; $x++) {
    printf("━");
  }
  printf("┛");

  setCursor(3, 2);
}

# 内枠描画
sub drawInnerFrame {
  my $y=shift;
  my $height=shift;

  setCursor(2, $y);
  printf("┏");
  for (my $x=3; $x<$width-1; $x++) {
    printf("━");
  }
  printf("┓");
  $y++;

  for (my $i=0; $i<$height; $i++) {
    setCursor(2, $y);
    printf("┃");
    for (my $x=3; $x<$width-1; $x++) {
      printf(" ");
    }
    setCursor($width-1, $y);
    printf("┃");
    $y++;
  }

  setCursor(2, $y);
  printf("┗");
  for (my $x=3; $x<$width-1; $x++) {
    printf("━");
  }
  printf("┛");
}

# スプラッシュスクリーン描画
sub drawTitle {
  my $data = shift;

  setTextColor(White);
  setBackColor(Black);

  clearTerm(); # 画面クリア

  drawFrame(); # 枠の表示

  my $y = 2;
  setTextColor(Cyan);
  foreach my $line (@{$data->{product}->{title}}) {
    setCursor(2, $y++);
    printf($line);
  }
  setTextColor(White);
  setCursor(2, $y++);
  setCursor(2, $y++);printf("                              Copyright (C) 2022 SECIOSS, INC.");
  setCursor(2, $y++);
  setCursor(2, $y++);printf("Press Enter to setup...");

  while (<STDIN>) { last; }
}

# メニュー描画
sub selectMenu {
  my $menu_data = shift;

  ReadMode('cbreak');

  setTextColor(White);
  setBackColor(Black);

  clearTerm(); # 画面クリア

  drawFrame(); # 枠の表示

  # キャプションの表示
  setCursor(3, 2);
  printf("%s", $menu_data->{'caption'});
  setCursor(2, 3);
  for (my $x=2; $x<$width; $x++) {
    printf("-");
  }

  # メニュー項目の表示
  my @tmp_items = @{$menu_data->{'items'}};
  my @items = ();
  my $item_start_y=4;
  my $y=$item_start_y;
  foreach my $item (@tmp_items) {
    if (defined($item->{'visible'}) && ! $item->{'visible'}->()) {
      next;
    }
    push(@items, $item);

    setCursor(3, $y);
    printf("[ ] %s", $item->{'name'});
    $y++;
  }

  # 選択項目にカーソルの表示
  $y=$item_start_y;
  my $input = "";
  while (1) {
    setCursor(4, $y);
    printf("*");
    setCursor(4, $y);
    my $c = ReadKey(1);
    next if (!defined($c));
    last if $c eq "\n";

    setCursor(4, $y);
    printf(" ");
    setCursor(4, $y);

    $input .= $c;
    if ($input =~ /\e\[A$/) {
      $y -= 1;
    } elsif ($input =~ /\e\[B$/) {
      $y += 1;
    }

    if ($y > @items + $item_start_y - 1) {
      $y = @items + $item_start_y - 1;
    } elsif ($y < $item_start_y) {
      $y = $item_start_y;
    }
  }

  return $items[$y - $item_start_y]->{'id'};
}

# 入力項目描画
sub inputItems {
  my $items = shift;

  resetTerm(); # 画面クリア

  setTextColor(White);
  setBackColor(Black);

  # キャプションの表示
  my $captions = $items->{'caption'};
  if (ref($captions) ne 'ARRAY') {
    $captions = [ $items->{'caption'} ];
  }
  my $y = 1;
  for my $caption (@$captions) {
    setCursor(1, $y++);
    printf("%s", $caption);
  }
  setCursor(1, $y++);
  for (my $x=1; $x<$width; $x++) {
    printf("-");
  }
  setCursor(1, $y++);

  while (1) {
    # 項目の入力
    my $input_map={};
    foreach my $input (@{$items->{'inputs'}}) {
      if ($input->{'type'} eq "password") {
        ReadMode('noecho'); # echo backしない
      } else {
        ReadMode('normal'); # echo backする
      }

      # 項目表示チェック
      if (defined($input->{'visible'}) && ! $input->{'visible'}->($items->{'inputs'})) {
        next;
      }

      # 項目名
      while (1) {
        my $default_value;
        if ($input->{'type'} ne "password" ) {
          # password属性以外なら、前回入力値をdefault valueとして入力する。
          # なかったら指定されたdefault値を使用する。それもないならデフォルト値なし。
          if (defined($input->{'value'})) {
            $default_value = $input->{'value'};
          }
          elsif (defined($input->{'default'})) {
            $default_value = $input->{'default'};
          }
        }

        if (defined($input->{'name'})) {
          printf("%sを入力してください。", $input->{'name'});
          printf("%s", $input->{'comment'}) if defined($input->{'comment'});
        }
        elsif (defined($input->{'custom_text'})) {
          print($input->{'custom_text'});
        }
        printf("(default: %s)", $default_value) if defined($default_value);
        printf("\n");
        my $str = readline();
        chomp($str);
        if ($input->{'type'} ne "password" && $default_value && length($str) == 0) {
          # password属性以外で入力値が空文字でデフォルトが設定されているならデフォルト値を使用する。
          $str = $default_value;
        }
        if (!$input->{'nullable'} && length($str) == 0) {
          # nullable属性以外は省略不可とする
          next;
        }
        if (defined($input->{'format'}) && $str !~ /$input->{'format'}/) {
          printf("不正な値が入力されました。\n");
          next;
        }
        $input->{'value'} = $str;
        if ($input->{'type'} eq "password" ) {
          printf("\n");
        }
        last;
      }

      $input_map->{$input->{'id'}} = $input;
    }

    # 入力チェック
    if (defined($items->{'check'}) && !$items->{'check'}($input_map)) {
      next;
    }
    last;
  }

  ReadMode('cbreak');

  return 0;
}

# INIファイルアクセスへルパー
sub ini_setval {
  my $file = shift;
  my $section = shift;
  my $parameter = shift;
  my $value = shift;

  my $double_quote = 0;

  my $old_value = $file->val($section, $parameter);
  if (defined($old_value) && $old_value =~ /^".*"$/) {
    $double_quote = 1;
  }
  elsif ($value =~ /.*=.*/) {
    $double_quote = 1;
  }

  if ($double_quote && $value !~ /^".*"$/) {
    $value = '"'.$value.'"';
  }

  if (!defined($file->setval($section, $parameter, $value))) {
    $file->newval($section, $parameter, $value);
  }
}

sub ini_getval {
  my $file = shift;
  my $section = shift;
  my $parameter = shift;

  my $value = $file->val($section, $parameter);
  $value =~ s/^"(.*)"$/$1/;

  return $value
}

sub ini_save {
  my $file = shift;

  # Config::IniFiles で 保存時にownerを書き換えてしまうバグがあるため
  my ($dev, $ino, $mode, $nlink, $uid, $gid, $rdev, $size, $atime, $mtime, $ctime, $blksize, $blocks) = stat $file->GetFileName();
  $file->RewriteConfig();
  chown($uid, $gid, $file->GetFileName());
}

# 入力項目の保存
sub update_settings {
  my $additional_data = shift;
  my $file = shift || SETTINGS_DAT;

  my $data = read_settings($file);
  $data = { %{$data}, %{$additional_data} };

  sysopen(my $fh, $file, O_WRONLY | O_CREAT | O_TRUNC) or die("failed to open: $file : $!");
  my $serialized = encode_json($data);
  print($fh $serialized);
  close($fh);
}

sub read_settings {
  my $file = shift || SETTINGS_DAT;

  sysopen(my $fh, $file, O_RDONLY | O_CREAT) or die("failed to open: $file : $!");
  my $serialized = do { local $/ = '\0'; <$fh> };
  my $data ={ };
  if ($serialized) {
    $data = decode_json($serialized);
  }
  close($fh);

  return $data;
}

sub check_selinux {
  my $data = shift;

  my $msg = `/usr/sbin/getenforce 2>&1`;
  chomp($msg);
  if ($msg =~ /(Permissive)|(Disabled)/i) {
    return;
  }

  setBackColor(White);

  clearTerm(); # 画面クリア

  my $y = 2;
  setBackColor(White);
  setTextColor(Red, Bold);
  setCursor(2, $y++);printf($data->{product}->{name}." はSELinuxに対応しておりません。");
  setCursor(2, $y++);printf("SELinuxを無効化してください。");
  setCursor(2, $y++);printf("");
  setBackColor(White);
  setTextColor(Black, Bold);
  setCursor(2, $y++);printf("Press Enter to end...");

  while (<STDIN>) { last; }

  resetTerm();
  exit 1;
}

#
# ldap構築用
#
sub ldapmodify_ldif {
  my $data = shift;
  my $file = shift;

  if (!defined $data->{'ldap'}) {
    die('failed in ldapmodify_ldif: ldap conection information not exists.');
  }
  if (! -e $file) {
    die("failed in ldapmodify_ldif: fine not found ($file)");
  }

  my $uri = $data->{'ldap'}->{'uri'};
  my $binddn = $data->{'ldap'}->{'binddn'};
  my $bindpw = $data->{'ldap'}->{'bindpw'};

  my $err = `ldapmodify -H $uri -D "$binddn" -w $bindpw -f $file 2>&1`;
  my $rc = $?;
  die('failed in ldapmodify_ldif '.$err) if ($rc);
}

sub ldapmodify_init_ldif {
  my $data = shift;
  my $file = shift;

  open(FH, '<', '/etc/system-release') or die("unknown os");
  my $os = <FH>;
  close(FH);

  if (!defined $data->{'ldap'}) {
    die('failed in ldapmodify_init_ldif: ldap conection information not exists.');
  }
  if (! -e $file) {
    die("failed in ldapmodify_init_ldif: file not found ($file)");
  }

  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  my $basedn = $data->{'ldap'}->{'basedn'};
  my ($org_basedn) = ($contents =~ /dn\s*:\s*o=System,([^\n]+)/);

  if ($contents !~ s/$org_basedn/$basedn/g) {
    die("failed to ldapmodify_init_ldif: update basedn $org_basedn -> $basedn ($file)");
  }

  if ($os =~ /release 9/) {
    if ($contents =~ /(dn: ou=Services,$basedn\nchangetype: )add\nobjectClass: organizationalUnit/) {
      if ($contents !~ s/(dn: ou=Services,$basedn\nchangetype: )add\nobjectClass: organizationalUnit/$1modify\nreplace: ou/) {
        die("failed to ldapmodify_init_ldif: update ou=Services ($file) ");
      }
    }
    if ($contents !~ /\ndn: ou=Groups,$basedn\nchangetype: modify\ndelete: aci\n/) {
      $contents .= "\ndn: ou=Groups,$basedn\nchangetype: modify\ndelete: aci\n";
    }
    if ($contents !~ /\ndn: ou=Services,$basedn\nchangetype: modify\ndelete: aci\n/) {
      $contents .= "\ndn: ou=Services,$basedn\nchangetype: modify\ndelete: aci\n";
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);

  ldapmodify_ldif($data, $file);
}

sub create_openldap {
  my $data = shift;

  if (!defined($data->{'ldap'})) {
    return;
  }

  my $ldif_dir = File::Spec->catfile($FindBin::Bin, 'secioss_openldap/ldif');
  if ( ! -d $ldif_dir ) {
    die("directory is not exists. $ldif_dir");
  }

  my $message = `cp /etc/pki/tls/certs/localhost.crt /etc/openldap/certs/openldap.crt 2>&1`;
  if ($?) {
    die("failed in create_openldap:$message");
  }
  $message = `cp /etc/pki/tls/private/localhost.key /etc/openldap/certs/openldap.key 2>&1`;
  if ($?) {
    die("failed in create_openldap:$message");
  }
  $message = `chown ldap:ldap /etc/openldap/certs/openldap.key 2>&1`;
  if ($?) {
    die("failed in create_openldap:$message");
  }
  $message = `chown ldap:ldap /etc/openldap/certs/openldap.crt 2>&1`;
  if ($?) {
    die("failed in create_openldap:$message");
  }

  ldapmodify_admin_ldif($data, File::Spec->catfile($ldif_dir, 'admin.ldif'));

  ldapmodify_schema_ldif($data, File::Spec->catfile($ldif_dir, 'schema.ldif'));

  ldapmodify_db_ldif($data, File::Spec->catfile($ldif_dir, 'db.ldif'));

  ldapmodify_module_ldif($data, File::Spec->catfile($ldif_dir, 'module.ldif'));

  print `systemctl restart slapd 2>&1`;

  ldapmodify_init_ldif($data, File::Spec->catfile($ldif_dir, 'init.ldif'));
}

sub create_389directoryserver {
  my $data = shift;

  if (!defined($data->{'ldap'})) {
    return;
  }
  my $message;

  open(FH, '<', '/etc/system-release') or die("unknown os");
  my $os = <FH>;
  close(FH);

  my $pkgchk = `rpm -qi 389-ds-base 2>&1`;
  if ($? eq 0) {
    # デーモンの停止
    daemon_control({ 'daemon' => { 'stop' => ['dirsrv@389ds'] } });

    # 389ds アンインストール
    if ($os =~ /release 9/) {
      if (-d '/etc/dirsrv/slapd-389ds/' && -e '/usr/sbin/dsctl') {
        $message = `dsctl 389ds remove --do-it 2>&1`;
        if ($?) {
          die("failed to remove 389 Directory Server: $message");
        }
    }
      dnf_control({ 'dnf' => { 'packages' => [ '389-ds-base' ] } }, 'erase');
    } else {
      dnf_control({ 'dnf' => { 'packages' => [ '389-ds-base', '389-ds-base-legacy-tools' ] } }, 'erase');
      rmtree('/etc/dirsrv/');
      rmtree('/var/lib/dirsrv/');
      rmtree('/var/log/dirsrv/');
    }
  }

  # 389ds パッケージインストール
  if ($os =~ /release 9/) {
    dnf_control({ 'dnf' => { 'packages' => [ '389-ds-base' ] } }, 'install');
  } else {
    dnf_control({ 'dnf' => { 'module' => [ '389-ds' ] } }, 'enable');
    dnf_control({ 'dnf' => { 'packages' => [ '389-ds-base', '389-ds-base-legacy-tools' ] } }, 'install');
  }

  # secioss-schema インストールチェック
  my $ldifdir = '/opt/secioss/ldap/389ds/ldif/';
  my $schemadir = '/opt/secioss/ldap/389ds/schema/';

  if ( ! -d $ldifdir) {
    die("directory is not exists. $ldifdir");
  }
  if ( ! -d $schemadir) {
    die("directory is not exists. $schemadir");
  }
  printf("パッケージのインストールが完了しました。\n");

  if ($os =~ /release 9/) {
    # setupv2.inf 作成
    update_389ds_setupv2_inf($data);

    # スキーマ
    $message = `cp /opt/secioss/ldap/389ds/schema/50secioss.ldif /etc/dirsrv/schema/ 2>&1`;
    if ($?) {
      die("failed to copy schema file:$message");
    }
    printf("LDAPスキーマを適用しました。\n");

    $message = `dscreate from-file /opt/secioss/ldap/389ds/setupv2.inf 2>&1`;
    if ($?) {
      die("failed to setup 389 Directory Server (dscreate): $message");
    }
    printf("389 Directory Server のインスタンスを作成しました。\n");
  } else {
    # setup.inf 作成
    update_389ds_setup_inf($data);

    $message = `setup-ds.pl -s -f /opt/secioss/ldap/389ds/setup.inf 2>&1`;
    if ($?) {
      die("failed to setup 389 Directory Server (setup-ds.pl): $message");
    }
    printf("389 Directory Server のインスタンスを作成しました。\n");

    # スキーマ
    $message = `cp /opt/secioss/ldap/389ds/schema/50secioss.ldif /etc/dirsrv/slapd-389ds/schema/ 2>&1`;
    if ($?) {
      die("failed to copy schema file:$message");
    }
    printf("LDAPスキーマを適用しました。\n");
  }

  # デーモンの再起動
  daemon_control({ 'daemon' => { 'restart' => [ 'dirsrv@389ds' ] } });

  # 389ds.ldif
  ldapmodify_ldif($data, '/opt/secioss/ldap/389ds/ldif/389ds.ldif');
  printf("基本設定を適用しました。\n");

  # 389ds_index.ldif
  ldapmodify_ldif($data, '/opt/secioss/ldap/389ds/ldif/389ds_index.ldif');
  printf("インデックスを作成しました。\n");

  # デーモンの再起動
  daemon_control({ 'daemon' => { 'restart' => [ 'dirsrv@389ds' ] } });

  # プロダクトごとの init.ldif
  if (defined($data->{'ldap'}->{'product'})) {
    my $file = '/opt/secioss/ldap/389ds/ldif/init.389ds.'.$data->{'ldap'}->{'product'}.'.ldif';
    ldapmodify_init_ldif($data, $file);
  }
  printf("製品データセットを登録しました。\n");

}

sub update_389ds_setup_inf {
  my $data = shift;

  my $file = '/opt/secioss/ldap/389ds/setup.inf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    my $fqdn = (defined $data->{'ldap'}->{'fqdn'}) ? $data->{'ldap'}->{'fqdn'} : 'localhost';
    if ($contents !~ s/^(FullMachineName\s*=\s*)(.*)$/$1$fqdn/m) {
      die("failed to update /opt/secioss/ldap/389ds/setup.inf [FullMachineName]");
    }
    if ($contents !~ s/^(Suffix\s*=\s*)(.*)$/$1$basedn/m) {
      die("failed to update /opt/secioss/ldap/389ds/setup.inf [Suffix]");
    }
    if ($contents !~ s/^(RootDN\s*=\s*)(.*)$/$1$binddn/m) {
      die("failed to update /opt/secioss/ldap/389ds/setup.inf [RootDN]");
    }
    if ($contents !~ s/^(RootDNPwd\s*=\s*)(.*)$/$1$bindpw/m) {
      die("failed to update /opt/secioss/ldap/389ds/setup.inf [RootDNPwd]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_389ds_setupv2_inf {
  my $data = shift;

  my $file = '/opt/secioss/ldap/389ds/setupv2.inf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    my $fqdn = (defined $data->{'ldap'}->{'fqdn'}) ? $data->{'ldap'}->{'fqdn'} : 'localhost';
    if ($contents !~ s/^(uri\s*=\s*ldaps:\/\/)(.*)$/$1$fqdn/m) {
      die("failed to update /opt/secioss/ldap/389ds/setupv2.inf [uri]");
    }
    if ($contents !~ s/^(suffix\s*=\s*)(.*)$/$1$basedn/m) {
      die("failed to update /opt/secioss/ldap/389ds/setupv2.inf [suffix]");
    }
    if ($contents !~ s/^(root_dn\s*=\s*)(.*)$/$1$binddn/m) {
      die("failed to update /opt/secioss/ldap/389ds/setupv2.inf [root_dn]");
    }
    if ($contents !~ s/^(root_password\s*=\s*)(.*)$/$1$bindpw/m) {
      die("failed to update /opt/secioss/ldap/389ds/setupv2.inf [root_password]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

#
# DB構築用
#
sub create_mariadb {
  my $data = shift;
  my $pkgchk = `rpm -qi mariadb-server 2>&1`;
  if ($? eq 0) {
    # デーモンの停止
    daemon_control({ 'daemon' => { 'stop' => ['mariadb'] } });

    # mariadb アンインストール
    dnf_control({ 'dnf' => { 'packages' => [ 'mariadb-server' ] } }, 'erase');
    rmtree('/var/lib/mysql/');
  }

  # mariadb パッケージインストール
  dnf_control({ 'dnf' => { 'packages' => [ 'mariadb-server' ] } }, 'install');

  # デーモンの再起動
  daemon_control({ 'daemon' => { 'restart' => [ 'mariadb' ] } });
}

sub create_db_schema {
  my $data = shift;

  my $host = $data->{'mysql'}->{'host'};
  my $port = $data->{'mysql'}->{'port'};
  my $admin = $data->{'mysql'}->{'admin'};
  my $admin_password = $data->{'mysql'}->{'admin_password'};
  my $user = $data->{'mysql'}->{'user'};
  my $password = $data->{'mysql'}->{'password'};

  my $dbh = DBI->connect("DBI:mysql:host=$host;port=$port", $admin, $admin_password);
  if (!$dbh) {
    die("failed to connect db server");
  }

  my $create_db = sub {
    my ($database, $option) = @_;

    # database option
    if(!defined $option){
      $option = '';
    }

    my $rows = $dbh->selectall_arrayref("show databases");
    my $find = undef;
    foreach my $row (@$rows) {
      if ($row->[0] eq $database) {
        $find = 1;
        last;
      }
    }
    if (!$find) {
      if (!$dbh->do("CREATE DATABASE $database $option")) {
        die("failed to create db:".$dbh->errstr);
      }
    }

    if (!$dbh->do("GRANT ALL ON $database.* to $user")) {
      die("failed to grand authority:".$dbh->errstr);
    }
    if (!$dbh->do("GRANT ALL ON $database.* to $user\@localhost")) {
      die("failed to grand authority:".$dbh->errstr);
    }
    if (!$dbh->do("use $database")) {
      die("failed to use database:".$dbh->errstr);
    }
  };

  my $exists_table = sub {
    my $table = shift;
    my $rows = $dbh->selectall_arrayref("show tables");
    my $find = undef;
    foreach my $row (@$rows) {
      if ($row->[0] eq $table) {
        return 1;
      }
    }
    return undef;
  };

  my $exists_user = sub {
    my ($user, $host) = @_;
    my $rows = $dbh->selectall_arrayref("select user , host from mysql.user");
    my $find = undef;
    foreach my $row (@$rows) {
      if ($row->[0] eq $user && $row->[1] eq $host) {
        return 1;
      }
    }
    return undef;
  };

  # create user
  if (!$exists_user->($user, 'localhost')) {
    if (!$dbh->do("CREATE USER $user IDENTIFIED BY '$password'")) {
      die("failed to create user:".$dbh->errstr);
    }
    if (!$dbh->do("CREATE USER $user\@localhost IDENTIFIED BY '$password'")) {
      die("failed to create user:".$dbh->errstr);
    }
  }

  # get MariaDB version
  my $db_version = sub {
    my $rows = $dbh->selectall_arrayref('SELECT VERSION();');
    my ($ver) = (@{@$rows[0]}[0] =~ /^([^\.]+\.[^\.]+)/);
    return $ver;
  };

  # set password of connect user
  if ($db_version->() >= 10.4) {
    if (!$dbh->do("SET PASSWORD FOR $user=PASSWORD('$password');")) {
      die("failed to update password:".$dbh->errstr);
    }
  } else {
    if (!$dbh->do("UPDATE mysql.user SET Password=PASSWORD('$password') WHERE User='$user';")) {
      die("failed to update password:".$dbh->errstr);
    }
  }

  # create db syslogng
  $create_db->('syslogng');

  # create db cybozu_csv
  $create_db->('cybozu_csv');
  foreach my $table (('user_csv', 'group_csv', 'organization_csv')) {
    if (!$exists_table->($table)) {
      if (!$dbh->do("CREATE TABLE $table (id bigint(20) NOT NULL AUTO_INCREMENT, csv varchar(5120), timestamp char(15), PRIMARY KEY (id))")) {
        die("failed to create table:".$dbh->errstr);
      }
    }
  }

  # create db certificate
  $create_db->('certificate');
  if (!$exists_table->('client_certificate')) {
    if (!$dbh->do("CREATE TABLE client_certificate (tenant varchar(100) NOT NULL, cert_id varchar(100) NOT NULL, user_id varchar(100) NOT NULL, sscep_option varchar(767), cert_data text, download_history text, secret varchar(40), order_id varchar(30), ca VARCHAR(30), tool MEDIUMBLOB, PRIMARY KEY (tenant, cert_id), KEY idx_user_id (user_id)) DEFAULT CHARSET=latin1")) {
      die("failed to create client table:".$dbh->errstr);
    }
  }
  if (!$exists_table->('device_certificate')) {
    if (!$dbh->do("CREATE TABLE device_certificate (tenant varchar(100) NOT NULL, device_id varchar(100) NOT NULL, expire_date varchar(20) NOT NULL, order_id varchar(10), cert_data text, download_history text, secret varchar(50), PRIMARY KEY (tenant, device_id)) DEFAULT CHARSET=latin1")) {
      die("failed to create device table:".$dbh->errstr);
    }
  }

  # create db slink_queue
  $create_db->('slink_queue');
  if (!$exists_table->('lism_queue')) {
    if (!$dbh->do("CREATE TABLE lism_queue (id bigint(20) NOT NULL auto_increment, timestamp char(15) default NULL, tenant varchar(256) default NULL, binddn varchar(256) default NULL, ldif varchar(5120) default NULL, PRIMARY KEY (id))")) {
      die("failed to create table:".$dbh->errstr);
    }
  }
  if (!$exists_table->('primedrive_user_csv')) {
    if (!$dbh->do("CREATE TABLE primedrive_user_csv (id bigint(20) NOT NULL auto_increment, csv varchar(5120) default NULL, timestamp char(15) default NULL, PRIMARY KEY (id))")) {
      die("failed to create table:".$dbh->errstr);
    }
  }

  # create db oauth_db
  $create_db->('oauth_db');
  if (!$exists_table->('oauth_tbl')) {
    if (!$dbh->do("CREATE TABLE oauth_tbl (id int(11) NOT NULL AUTO_INCREMENT, user_id varchar(255) NOT NULL, client_id varchar(255) NOT NULL, scope varchar(255), additional_data varchar(255), create_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, update_time timestamp, access_time timestamp, deleted int(11) NOT NULL DEFAULT '0', PRIMARY KEY (id), KEY user_id (user_id, client_id))")) {
      die("failed to create table:".$dbh->errstr);
    }
  }
  if (!$exists_table->('auth_code_tbl')) {
    if (!$dbh->do("CREATE TABLE auth_code_tbl ( code CHAR(60) NOT NULL , client_id VARCHAR(100) NOT NULL , redirect_uri VARCHAR(200) NOT NULL , username VARCHAR(100) NOT NULL , expires CHAR(10) NOT NULL , scope VARCHAR(100) NULL , additional_data VARCHAR(255) NULL , nonce VARCHAR(100) NULL , claims VARCHAR(255) NULL , PRIMARY KEY (code) )")) {
      die("failed to create table:".$dbh->errstr);
    }
  }
  if (!$exists_table->('access_token_tbl')) {
    if (!$dbh->do("CREATE TABLE access_token_tbl ( access_token CHAR(60) NOT NULL , client_id VARCHAR(100) NOT NULL , username VARCHAR(100) NOT NULL , expires CHAR(10) NOT NULL , scope VARCHAR(100) NULL , additional_data VARCHAR(255) NULL , nonce VARCHAR(100) NULL , claims VARCHAR(255) NULL , PRIMARY KEY (access_token) )")) {
      die("failed to create table:".$dbh->errstr);
    }
  }
  if (!$exists_table->('refresh_token_tbl')) {
    if (!$dbh->do("CREATE TABLE refresh_token_tbl ( refresh_token CHAR(60) NOT NULL , access_token CHAR(60) NULL , client_id VARCHAR(100) NOT NULL , username VARCHAR(100) NOT NULL , expires CHAR(10) NOT NULL , scope VARCHAR(100) NULL , additional_data VARCHAR(255) NULL , nonce VARCHAR(100) NULL , claims VARCHAR(255) NULL , PRIMARY KEY (refresh_token) )")) {
      die("failed to create table:".$dbh->errstr);
    }
  }
  if (!$exists_table->('oidc_tbl')) {
    if (!$dbh->do("CREATE TABLE oidc_tbl ( id int(11) NOT NULL AUTO_INCREMENT, user_id varchar(255) NOT NULL, client_id varchar(255) NOT NULL, scope varchar(255) DEFAULT NULL, additional_data varchar(255) DEFAULT NULL, create_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, update_time timestamp NULL DEFAULT NULL, access_time timestamp NULL DEFAULT NULL, deleted int(11) NOT NULL DEFAULT '0', PRIMARY KEY (id), KEY user_id (user_id, client_id) )")) {
      die("failed to create table:".$dbh->errstr);
    }
  }

  # create db consent_db
  $create_db->('consent_db');
  if (!$exists_table->('consent')) {
    if (!$dbh->do("CREATE TABLE consent ( consent_date datetime NOT NULL, usage_date datetime NOT NULL, hashed_user_id varchar(80) NOT NULL, service_id varchar(255) NOT NULL, attribute varchar(80) NOT NULL, selected varchar(1000) NOT NULL, user_id varchar(255) NOT NULL, service_name varchar(255) NOT NULL, UNIQUE KEY hashed_user_id ( hashed_user_id , service_id ) ) ENGINE=InnoDB DEFAULT CHARSET=utf8")) {
      die("failed to create table:".$dbh->errstr);
    }
  }

  # create db secioss
  $create_db->('secioss');
  if (!$exists_table->('service_license_role')) {
    if (!$dbh->do("CREATE TABLE service_license_role ( service varchar(255) NOT NULL,  role_id varchar(255) NOT NULL,  name varchar(255) DEFAULT NULL,  type varchar(64) NOT NULL DEFAULT '',  tenant varchar(255) NOT NULL DEFAULT '',  description varchar(255) DEFAULT NULL,  created_at datetime NOT NULL,  updated_at datetime NOT NULL,  PRIMARY KEY (tenant,service,type,role_id) ) ENGINE=InnoDB DEFAULT CHARSET=utf8")) {
      die("failed to create table:".$dbh->errstr);
    }
  }

  # create db authdevice
  $create_db->('authdevice');
  if (!$exists_table->('registrations')) {
    if (!$dbh->do("CREATE TABLE registrations ( id int(11) NOT NULL AUTO_INCREMENT, user_id int(11) DEFAULT NULL, keyHandle varchar(255) DEFAULT NULL, publicKey varchar(255) DEFAULT NULL, certificate text, counter int(11) DEFAULT NULL, device_id varchar(255) DEFAULT NULL, status int(11) DEFAULT '0', register_user varchar(255) DEFAULT NULL, register_date timestamp NULL DEFAULT CURRENT_TIMESTAMP, register_ip varchar(39) DEFAULT NULL, tenant varchar(255) DEFAULT NULL, PRIMARY KEY (id), UNIQUE KEY device_id (device_id,tenant), KEY user_id (user_id,device_id,tenant) ) ENGINE=InnoDB DEFAULT CHARSET=latin1")) {
      die("failed to create table:".$dbh->errstr);
    }
  }
  if (!$exists_table->('users')) {
    if (!$dbh->do("CREATE TABLE users ( id int(11) NOT NULL AUTO_INCREMENT, name varchar(255) DEFAULT NULL, tenant varchar(255) DEFAULT NULL, PRIMARY KEY (id), KEY name (name,tenant) ) ENGINE=InnoDB DEFAULT CHARSET=latin1")) {
      die("failed to create table:".$dbh->errstr);
    }
  }

  # create db alogin
  $create_db->('alogin');
  if (!$exists_table->('alogin')) {
    if (!$dbh->do("CREATE TABLE alogin (  uid VARCHAR(129) NOT NULL COMMENT 'ユーザーID', tenant VARCHAR(64) NOT NULL, name VARCHAR(255) NOT NULL COMMENT 'アプリケーションID', appname VARCHAR(255) NOT NULL COMMENT 'アプリケーション名', addon INT(2) COMMENT 'アドオン有効フラグ', loginurl VARCHAR(255) NOT NULL COMMENT 'ログインURL', topurl VARCHAR(255) COMMENT 'アクセスURL', logouturl VARCHAR(255) COMMENT 'ログアウトURL', userparam VARCHAR(100) NOT NULL COMMENT 'ユーザIDのパラメータ', uservalue VARCHAR(100) NOT NULL COMMENT 'ユーザIDの値', passparam VARCHAR(100) COMMENT 'パスワードのパラメータ', passvalue VARCHAR(100) COMMENT 'パスワードの値', postdata TEXT COMMENT 'POSTデータ', ignorehidden INT(2) COMMENT 'ログイン画面のHidden属性送信フラグ', cookiename VARCHAR(100) COMMENT 'セッションのクッキー名', loginscript TEXT COMMENT 'ログインスクリプト', hasloginscript TEXT COMMENT 'ログイン済み判定スクリプト', logourl VARCHAR(255) COMMENT 'ポータルに表示するロゴ画像', create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, update_time TIMESTAMP NULL DEFAULT NULL, PRIMARY KEY (uid,tenant,name), INDEX (uid,tenant,name,loginurl) ) ENGINE=InnoDB DEFAULT CHARSET=utf8")) {
      die("failed to create table:".$dbh->errstr);
    }
  }

  # create db report
  $create_db->('report', 'DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci');
  ## ログダッシュボード
  # create table corp_login_info
  if (!$exists_table->('corp_login_info')) {
    if (!$dbh->do("CREATE TABLE corp_login_info (tenant VARCHAR(64) NOT NULL COMMENT 'テナントID', login_time DATETIME NOT NULL COMMENT '日時', login_succeeded_number INT UNSIGNED NULL DEFAULT 0 COMMENT 'ログインの成功数', login_failed_number INT UNSIGNED NULL DEFAULT 0 COMMENT 'ログインの失敗数', PRIMARY KEY (tenant, login_time), INDEX (login_time)) ENGINE=InnoDB")) {
      die("failed to create corp_login_info table:".$dbh->errstr);
    }
  }

  # create table application_login_info
  if (!$exists_table->('application_login_info')) {
    if (!$dbh->do("CREATE TABLE application_login_info (tenant VARCHAR(64) NOT NULL COMMENT 'テナントID', login_time DATETIME NOT NULL COMMENT '日時', application_id VARCHAR(129) NOT NULL COMMENT 'アプリケーションID', application_name VARCHAR(129) NOT NULL COMMENT '登録のアプリケーションの種類', login_user_number INT UNSIGNED NULL DEFAULT 0 COMMENT 'ログイン数', country_code VARCHAR(3) NOT NULL COMMENT '国コード', longitude VARCHAR(12) COMMENT '経度', latitude VARCHAR(12) COMMENT '緯度', PRIMARY KEY (tenant, login_time, application_id, country_code), INDEX (login_time, application_id), INDEX (login_time, application_id, country_code)) ENGINE=InnoDB DEFAULT CHARSET=utf8")) {
      die("failed to create application_login_info table:".$dbh->errstr);
    }
  }

  # create table user_login_each_application
  if (!$exists_table->('user_login_each_application')) {
    if (!$dbh->do("CREATE TABLE user_login_each_application (tenant VARCHAR(64) NOT NULL,  datetime CHAR(19) NOT NULL,  uid VARCHAR(129) NOT NULL,  application_id VARCHAR(255) NOT NULL,  application_name VARCHAR(255),  agent VARCHAR(16),  ipaddress VARCHAR(80),  country VARCHAR(3),  longitude VARCHAR(12),  latitude VARCHAR(12),  PRIMARY KEY (tenant, datetime, uid, application_id), INDEX (tenant, datetime, country, application_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8")) {
      die("failed to create user_login_each_application table:".$dbh->errstr);
    }
  }

  # create table user_active_info
  if (!$exists_table->('user_active_info')) {
    if (!$dbh->do("CREATE TABLE user_active_info (tenant VARCHAR(64) NOT NULL COMMENT 'テナントID', uid VARCHAR(129) NOT NULL COMMENT 'ユーザーID', inactived_at DATETIME NOT NULL COMMENT 'ユーザーがサスペンドされた日時', actived_at DATETIME NULL DEFAULT NULL COMMENT 'ユーザーが有効化された日時', PRIMARY KEY (tenant, uid, inactived_at), INDEX (uid, inactived_at)) ENGINE=InnoDB")) {
      die("failed to create user_active_info table:".$dbh->errstr);
    }
  }

  # create table user_login_info
  if (!$exists_table->('user_login_info')) {
    if (!$dbh->do("CREATE TABLE user_login_info (tenant VARCHAR(255) NOT NULL COMMENT 'テナントID', uid VARCHAR(255) NOT NULL COMMENT 'ユーザーID', result VARCHAR(16) NOT NULL COMMENT 'ログインの結果：(login success; login failed; lock out)', login_time DATETIME NOT NULL COMMENT 'ログイン日時分秒', auth_type VARCHAR(32) COMMENT '認証の種類', supple_info VARCHAR(255) COMMENT '補足情報(端末IDなど)', ipaddress VARCHAR(45) COMMENT 'IPアドレス', country_code VARCHAR(3) NOT NULL COMMENT '国コード', longitude VARCHAR(12) COMMENT '経度', latitude VARCHAR(12) COMMENT '緯度', PRIMARY KEY (tenant, uid, result, login_time), INDEX (uid, result, login_time), INDEX (ipaddress, result, login_time), INDEX (country_code, result, login_time), INDEX (tenant, auth_type, supple_info, login_time)) ENGINE=InnoDB")) {
      die("failed to create user_login_info table:".$dbh->errstr);
    }
  }

  # create table user_external_login_info
  if (!$exists_table->('user_external_login_info')) {
    if (!$dbh->do("CREATE TABLE user_external_login_info (tenant VARCHAR(255) NOT NULL COMMENT 'テナントID', uid VARCHAR(255) NOT NULL COMMENT 'ユーザーID', login_time DATETIME NOT NULL COMMENT 'ログイン日時分秒', auth_type VARCHAR(32) COMMENT '認証の種類', login_user_number INT UNSIGNED NULL DEFAULT 0 COMMENT 'ログイン数', supple_info VARCHAR(255) COMMENT '補足情報(端末IDなど)', PRIMARY KEY (tenant, uid, login_time, auth_type), INDEX (tenant, uid, login_time), INDEX (tenant, login_time), INDEX (tenant)) ENGINE=InnoDB")) {
      die("failed to create user_external_login_info table:".$dbh->errstr);
    }
  }

  # create table user_info
  if (!$exists_table->('user_info')) {
    if (!$dbh->do("CREATE TABLE user_info (tenant VARCHAR(64) NOT NULL, uid VARCHAR(129) NOT NULL COMMENT 'ユーザーID', created_at DATETIME NOT NULL COMMENT 'ユーザーの新規登録日時', deleted_at DATETIME NULL DEFAULT NULL COMMENT 'ユーザーが削除された日時', PRIMARY KEY (tenant, uid, created_at), INDEX (uid, created_at)) ENGINE=InnoDB")) {
      die("failed to create user_info table:".$dbh->errstr);
    }
  }

  # create table activity_info
  if (!$exists_table->('activity_info')) {
    if (!$dbh->do("CREATE TABLE activity_info (tenant varchar(64) NOT NULL, date datetime NOT NULL, service varchar(129) NOT NULL, activity varchar(32) NOT NULL, country_code varchar(3) NOT NULL, domain varchar(64) NOT NULL, longitude varchar(12) DEFAULT NULL, latitude varchar(12) DEFAULT NULL, number int(10) DEFAULT NULL, PRIMARY KEY (tenant,date,service,activity,country_code,domain)) ENGINE=InnoDB DEFAULT CHARSET=utf8")) {
      die("failed to create activity_info table:".$dbh->errstr);
    }
  }

  # create view digits_view
  if (!$exists_table->('digits_view')) {
    if (!$dbh->do("CREATE VIEW digits_view AS SELECT 0 i UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9")) {
      die("failed to create view digits_view:".$dbh->errstr);
    }
  }

  # create view hours_view
  if (!$exists_table->('hours_view')) {
    if (!$dbh->do("CREATE VIEW hours_view AS SELECT ones.i * 1 + tens.i * 10 hours FROM digits_view ones JOIN digits_view tens HAVING HOURS < 24")) {
      die("failed to create view hours_view:".$dbh->errstr);
    }
  }

  # create view days_view
  if (!$exists_table->('days_view')) {
    if (!$dbh->do("CREATE VIEW days_view AS SELECT LAST_DAY(CURRENT_DATE) + INTERVAL 1 DAY - INTERVAL 25 MONTH + INTERVAL ones.i * 1 + tens.i * 10 + hundreds.i * 100 day days FROM digits_view ones JOIN digits_view tens JOIN digits_view hundreds")) {
      die("failed to create view days_view:".$dbh->errstr);
    }
  }

  # create view months_view
  if (!$exists_table->('months_view')) {
    if (!$dbh->do("CREATE VIEW months_view AS SELECT DISTINCT DATE_FORMAT(days_view.days, '%Y-%m') months FROM days_view WHERE days_view.days BETWEEN LAST_DAY(CURRENT_DATE) + INTERVAL 1 DAY - INTERVAL 25 MONTH AND LAST_DAY(CURRENT_DATE) - INTERVAL 1 MONTH")) {
      die("failed to create view months_view:".$dbh->errstr);
    }
  }
  ## /ログダッシュボード

  if (!$dbh->do("FLUSH PRIVILEGES")) {
    die("failed to flush privileges:".$dbh->errstr);
  }

  $dbh->disconnect();
}

#
# 設定ファイル更新用
#
sub update_sudoers {
  my $data = shift;

  my $file = '/etc/sudoers';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'visudo'})) {
    if ($data->{'visudo'}->{'requiretty'} =~ /yes/i) {
      if ($contents !~ s/\n#?\s*(Defaults\s+)!?(requiretty\n)/\n$1!$2/) {
        $contents .= "\nDefaults !requiretty\n";
      }
    }

    if ($data->{'visudo'}->{'exec_in_apache'} =~ /yes/i) {
      if ($contents !~ s/\napache\s+.*\n/\napache ALL=\(ALL\) NOPASSWD: \/usr\/share\/seciossadmin\/bin\/replacecsv.sh, \/usr\/share\/seciossadmin\/bin\/mkcert.sh, \/opt\/secioss\/sbin\/idm_rt.sh, \/opt\/secioss\/sbin\/simcmd, \/usr\/share\/seciossadmin\/bin\/reload_lism.sh\n/) {
        $contents .= "\napache ALL=(ALL) NOPASSWD: /usr/share/seciossadmin/bin/replacecsv.sh, /usr/share/seciossadmin/bin/mkcert.sh, /opt/secioss/sbin/idm_rt.sh, /opt/secioss/sbin/simcmd, /usr/share/seciossadmin/bin/reload_lism.sh\n";
      }
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_secioss_ini_php {
  my $data = shift;

  my $file = '/usr/share/seciossadmin/etc/secioss-ini.php';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($data->{product}->{code} =~ /same|siam/) {
      if ($contents !~ s/('ldap'\s*=>\s*\[\s*\n\s*'uri'\s*=>\s*')([^']+)(')/$1$uri$3/g) {
        die("failed to update secioss-ini.php [ldap]");
      }
      if ($contents !~ s/('binddn'\s*=>\s*')([^']+)(')/$1$binddn$3/g) {
        die("failed to update secioss-ini.php [binddn]");
      }
      if ($contents !~ s/('bindpw'\s*=>\s*')([^']+)(')/$1$bindpw$3/g) {
        die("failed to update secioss-ini.php [bindpw]");
      }
      if ($contents !~ s/('basedn'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
        die("failed to update secioss-ini.php [basedn]");
      }
      if ($contents !~ s/('suffix'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
        die("failed to update secioss-ini.php [suffix]");
      }
    }

    if ($data->{product}->{code} =~ /same/) {
      if ($contents !~ s/('ou=\(\?:AWS|Office365\),)([^']+)('\s*=>\s*\[\s*\n\s*'uri'\s*=>\s*')([^']+)(')/'ou=(?:AWS|Office365),$basedn$3ldap:\/\/localhost:3890$5/g) {
        die("failed to update secioss-ini.php [ldap]");
      }
      if ($contents !~ s/(?:'\.\*,[^']+')(\s=>\s\[\s*\n\s*'uri'\s*=>\s*')([^']+)(')/'.*,$basedn'$1$uri$3/g) {
        die("failed to update secioss-ini.php [ou=LDAP]");
      }
    }

    if ($data->{product}->{code} =~ /sime|siam/) {
      if ($contents !~ s/('ldap'\s*=>\s*\[\s*\n\s*'uri'\s*=>\s*')([^']+)(')/$1ldap:\/\/localhost:3890$3/g) {
        die("failed to update secioss-ini.php [ldap]");
      }
      if ($contents !~ s/('ou=Master,[^']+'\s=>\s\[\s*\n\s*'uri'\s*=>\s*')([^']+)(')/$1$uri$3/g) {
        die("failed to update secioss-ini.php [ou=Master]");
      }
      if ($contents !~ s/('ou=LDAP,[^']+'\s=>\s\[\s*\n\s*'uri'\s*=>\s*')([^']+)(')/$1$uri$3/g) {
        die("failed to update secioss-ini.php [ou=LDAP]");
      }
      if ($contents !~ s/('binddn'\s*=>\s*')([^']+)(')/$1$binddn$3/g) {
        die("failed to update secioss-ini.php [binddn]");
      }
      if ($contents !~ s/('bindpw'\s*=>\s*')([^']+)(')/$1$bindpw$3/g) {
        die("failed to update secioss-ini.php [bindpw]");
      }
      if ($contents !~ s/('basedn'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
        die("failed to update secioss-ini.php [basedn]");
      }
      if ($contents !~ s/('realnc'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
        die("failed to update secioss-ini.php [realnc]");
      }
      if ($contents !~ s/('suffix'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
        die("failed to update secioss-ini.php [suffix]");
      }
      if ($contents !~ s/('ou=[^,]+,)([^']+)('\s*=>\s*)/$1$basedn$3/g) {
        die("failed to update secioss-ini.php [ou,basedn]");
      }
      if ($contents !~ s/('ou=\[\^,)([^']+)('\s*=>\s*\[\s*\n\s*'uri'\s*=>\s*')([^']+)(')/'ou=[^,]+,$basedn$3ldap:\/\/localhost:3890$5/g) {
        die("failed to update secioss-ini.php [ldap]");
      }
    }

    if (defined($data->{'ldap'}->{'option'})) {
      my $option = $data->{'ldap'}->{'option'};
      if ($contents !~ s/('option'\s*=>\s*')([^']*)(vlv[^',]*)(,?[^']*)(')/$1$2$option$4$5/g) {
        die("failed to update secioss-ini.php [option]");
      }
    }
  }

  # for mysql
  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    my $port = $data->{'mysql'}->{'port'};
    my $user = $data->{'mysql'}->{'user'};
    my $password = $data->{'mysql'}->{'password'};

    if ($data->{product}->{code} =~ /same|siam/) {
      if ($contents !~ s/('db'\s*=>\s*\[\s*'host'\s*=>\s*')([^']+)(',\s*'user'\s*=>\s*')([^']+)(',\s*'password'\s*=>\s*')([^']+)(',\s*'database'\s*=>\s*'alogin'[^\]]+\])/$1$host$3$user$5$password$7/gs) {
        die("failed to update secioss-ini.php [db alogin]");
      }
      if ($contents !~ s/('db'\s*=>\s*\[\s*'host'\s*=>\s*')([^']+)(',\s*'user'\s*=>\s*')([^']+)(',\s*'password'\s*=>\s*')([^']+)(',\s*'database'\s*=>\s*'certificate'[^\]]+\])/$1$host$3$user$5$password$7/gs) {
        die("failed to update secioss-ini.php [db certificate]");
      }
    }

    if ($data->{product}->{code} =~ /sime|siam/) {
      if ($contents !~ s/('db'\s*=>\s*\[\s*'host'\s*=>\s*')([^']+)(',\s*'user'\s*=>\s*')([^']+)(',\s*'password'\s*=>\s*')([^']+)(',\s*'database'\s*=>\s*'secioss'[^\]]+\])/$1$host$3$user$5$password$7/gs) {
        die("failed to update secioss-ini.php [db secioss]");
      }
    }

    if ($contents !~ s/('db'\s*=>\s*\[\s*'host'\s*=>\s*')([^']+)(',\s*'user'\s*=>\s*')([^']+)(',\s*'password'\s*=>\s*')([^']+)(',\s*'database'\s*=>\s*'syslogng'[^\]]+\])/$1$host:$port$3$user$5$password$7/gs) {
      die("failed to update secioss-ini.php [db syslogng]");
    }
  }

  # for office365
  if (defined($data->{'office365'})) {
    my $host = $data->{'office365'}->{'host'};
    if ($contents !~ s/('office365'\s*=>\s*\[\s*'host'\s*=>\s*')([^']*)(',\s*'username'[^\]]+\])/$1$host$3/s) {
      die("failed to update secioss-ini.php [office365 host]");
    }
    my $sshuser = $data->{'office365'}->{'sshuser'};
    if ($contents !~ s/('office365'\s*=>\s*\[(?:\s*'[^']+'\s*=>\s*'[^']*',?)*\s*'username'\s*=>\s*')([^']*)(',)/$1$sshuser$3/s) {
      die("failed to update secioss-ini.php [office365 sshuser]");
    }
  }

  # for admin allowip
  if (defined($data->{'adminconsole'})) {
    my $allowip = $data->{'adminconsole'}->{'admin_allowip'};
    if (!$allowip) {
      $allowip = '*';
    }

    if ($contents !~ s/('admin_allow'\s*=>\s*')([^']*)(',)/$1$allowip$3/s) {
      die("failed to update secioss-ini.php [admin_allow]");
    }
  }

  # for select function
  if (defined($data->{'function'})) {
    my $use_gakunin = $data->{'function'}->{'gakunin'};
    if ($use_gakunin =~ /yes/i) {
      if ($contents =~ /('idm'\s*=>\s*\[\s*)((?:\s*'(?!(?:attributes))[^']+'\s*=>\s*(?:'[^']*',\s*|\s*\[[^\]*]*\],))+\s*)(\s*'attributes'\s*=>\s*\[\s*'user'\s*=>\s*\[)((?:\s*'[^']+'\s*=>\s*'[^']*'(?:,)?)+)(\s*\],)/m ) {
        my @matches = ("$1$2$3", "$4", "$5");
        if ($matches[1] !~ /eduPersonAffiliation/) {
          my ($space) = ($matches[1] =~ /^(\s*)'/);
          my $endcomma = substr($matches[1], -1) eq ',' ? '' : ',';
          $matches[1] = $matches[1].$endcomma.$space."'eduPersonAffiliation' => 'eduPersonAffiliation'";
          my $replaceobj = join('',@matches);

          $contents =~ s/('idm'\s*=>\s*\[\s*)((?:\s*'(?!(?:attributes))[^']+'\s*=>\s*(?:'[^']*',\s*|\[[^)*]*\],))+\s*)(\s*'attributes'\s*=>\s*\[\s*'user'\s*=>\s*\[)((?:\s*'[^']+'\s*=>\s*'[^']*'(?:,)?)+)(\s*\],)/$replaceobj/m;
        }
      }
    } else {
      $contents =~ s/^(\s*'eduPersonAffiliation'\s*=>\s*'[^']*'\s*(?:,)?\s*\n)//m;
    }

    if ($use_gakunin =~ /yes/i) {
      $contents =~ s/(\/\*\s*BEGIN_FUNCTION_GAKUNIN\s*)$/$1*\//m;
      $contents =~ s/^(\s*END_FUNCTION_GAKUNIN\s*\s*\*\/)/\/\*$1/m;
    } else {
      $contents =~ s/(\/\*\s*BEGIN_FUNCTION_GAKUNIN\s*)\*\//$1/m;
      $contents =~ s/\/\*(\s*END_FUNCTION_GAKUNIN\s*\s*\*\/)/$1/m;
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub create_oidc_cert {
  my $data = shift;

  # OIDC id_token jwk signing certificate
  if (!defined($data->{'oidc_cert'}) || !defined($data->{'oidc_cert'}->{'oidc_key_id'}) || !defined($data->{'oidc_cert'}->{'oidc_key_pass'})) {
    my $key_id = String::Random->new->randregex('[A-Za-z0-9]{32}');
    my $key_pass = String::Random->new->randregex('[A-Za-z0-9]{16}');

    $data = { %$data, (
      'oidc_cert' => {
        'oidc_key_id' => $key_id,
        'oidc_key_pass' => $key_pass
      }
    ) };
    update_settings($data);

    my $message = `openssl genrsa -aes256 -passout pass:$key_pass -out /usr/share/oidc/conf/private.key 2048 2>&1`;
    if ($?) {
      die("failed to create private.key:$message");
    }

    $message = `openssl rsa -in /usr/share/oidc/conf/private.key -passin pass:$key_pass -pubout -out /usr/share/oidc/conf/public.key 2>&1`;
    if ($?) {
      die("failed to create public.key:$message");
    }

    $message = `echo $key_id >/usr/share/oidc/conf/key.id 2>&1`;
    if ($?) {
      die("failed to create key.id:$message");
    }

    $message = `chown apache:apache /usr/share/oidc/conf/private.key /usr/share/oidc/conf/public.key /usr/share/oidc/conf/key.id 2>&1`;
    if ($?) {
      die("failed to change owner key files:$message");
    }
  }
}

sub update_syslogng_service {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/usr/lib/systemd/system/syslog-ng.service", -fallback => "Unit", -nomultiline => 1) or die "failed to open: @Config::IniFiles::errors";
  my $update_syslog_ng = $data->{'syslogng'}->{'servicefile_setting'};
  if ($update_syslog_ng =~ /yes/i) {
    ini_setval($file, "Unit", 'Wants', 'network.target network-online.target');
    ini_setval($file, "Unit", 'After', 'network.target network-online.target');
  }

  ini_save($file);
}

sub update_syslogng_conf {
  my $data = shift;

  my $file = '/etc/syslog-ng/conf.d/secioss.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    my $port = $data->{'mysql'}->{'port'};
    my $user = $data->{'mysql'}->{'user'};
    my $password = $data->{'mysql'}->{'password'};
    if ($contents !~ s/(host\(")([^"]+)("\)\s+port\()([^)]+)(\)\s+username\(")([^"]+)("\)\s+password\(")([^"]+)("\))/$1$host$3$port$5$user$7$password$9/gs) {
      die("failed to update secioss.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_ms365_license_importer_conf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/opt/secioss/etc/microsoft365_license_importer.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  # for mysql
  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    my $port = $data->{'mysql'}->{'port'};
    my $user = $data->{'mysql'}->{'user'};
    my $password = $data->{'mysql'}->{'password'};

    ini_setval($file, "GENERAL", 'database_name', 'secioss');
    ini_setval($file, "GENERAL", 'host', "$host:$port");
    ini_setval($file, "GENERAL", 'user', $user);
    ini_setval($file, "GENERAL", 'password', $password);
  }

  ini_save($file);
}

sub update_cybozucsv_conf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/opt/secioss/etc/cybozucsv.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    my $port = $data->{'mysql'}->{'port'};
    my $user = $data->{'mysql'}->{'user'};
    my $password = $data->{'mysql'}->{'password'};

    ini_setval($file, "GENERAL", 'dsn', "DBI:mysql:database=cybozu_csv;host=$host;port=$port");
    ini_setval($file, "GENERAL", 'dbuser', $user);
    ini_setval($file, "GENERAL", 'dbpasswd', $password);
  }

  ini_save($file);
}

sub update_lism_conf {
  my $data = shift;

  my $file = '/opt/secioss/etc/lism.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ /<storage [^>]*name="SLDAP"[^>]*>(.*?)<\/storage>/s) {
      die("failed to update lism.conf configuration");
    }
    my $inner_storage = $1;
    if ($inner_storage !~ s/<uri>(ldaps?:\/\/[^\/]+)\/([^<]*)<\/uri>/<uri>$uri\/$basedn<\/uri>/) {
      die("failed to update lism.conf ldap uri");
    }
    my $basedn_org = $2;
    if ($inner_storage !~ s/<binddn>([^<]+)<\/binddn>/<binddn>$binddn<\/binddn>/) {
      die("failed to update lism.conf ldap binddn");
    }
    if ($inner_storage !~ s/<bindpw>([^<]+)<\/bindpw>/<bindpw>$bindpw<\/bindpw>/) {
      die("failed to update lism.conf ldap bindpw");
    }
    if ($contents !~ s/$basedn_org/$basedn/g)  {
      die("failed to update lism.conf");
    }
    if ($contents !~ s/(<storage [^>]*name="SLDAP"[^>]*>).*?(<\/storage>)/$1$inner_storage$2/s) {
      die("failed to update lism.conf configuration");
    }
  }

  # for mysql
  if (defined($data->{'mysql'})) {
    if ($contents !~ s/<db [^\n]*dsn="DBI:mysql:database=([^;]+);[^\n]+\/>/<db dsn="DBI:mysql:database=$1;host=$data->{'mysql'}->{'host'};port=$data->{'mysql'}->{'port'}" admin="$data->{'mysql'}->{'user'}" passwd="$data->{'mysql'}->{'password'}"\/>/g) {
      die("failed to update lism.conf");
    }
    if ($contents !~ s/(<dsn>DBI:mysql:database=[^;]+;host=)([^;]+)(;port=)([0-9]+)(<\/dsn>\s*<admin>)([^<]+)(<\/admin>\s*<passwd>)([^<]+)(<\/passwd>)/$1$data->{'mysql'}->{'host'}$3$data->{'mysql'}->{'port'}$5$data->{'mysql'}->{'user'}$7$data->{'mysql'}->{'password'}$9/gs) {
      # 無い場合も許容
      # die("failed to update lism.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_lism_tenantcsv_conf {
  my $data = shift;

  my $file = '/opt/secioss/etc/lism-tenantcsv.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ /<storage [^>]*name="LDAP"[^>]*>(.*?)<\/storage>/s) {
      die("failed to update lism-tenantcsv.conf configuration");
    }
    my $inner_storage = $1;
    if ($inner_storage !~ s/<uri>(ldaps?:\/\/[^\/]+)\/([^<]*)<\/uri>/<uri>$uri\/$basedn<\/uri>/) {
      die("failed to update lism.conf ldap uri");
    }
    my $basedn_org = $2;
    if ($inner_storage !~ s/<binddn>([^<]+)<\/binddn>/<binddn>$binddn<\/binddn>/) {
      die("failed to update lism.conf ldap binddn");
    }
    if ($inner_storage !~ s/<bindpw>([^<]+)<\/bindpw>/<bindpw>$bindpw<\/bindpw>/) {
      die("failed to update lism.conf ldap bindpw");
    }
    if ($contents !~ s/$basedn_org/$basedn/g)  {
      die("failed to update lism.conf");
    }
    if ($contents !~ s/(<storage [^>]*name="LDAP"[^>]*>).*?(<\/storage>)/$1$inner_storage$2/s) {
      die("failed to update lism-tenantcsv.conf configuration");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_template_lism_conf {
  my $data = shift;

  my $file = '/opt/secioss/etc/template/lism.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $basedn = $data->{'ldap'}->{'basedn'};

    if ($contents !~ s/(<uri>ldap[^<>]*o=TENANT,)[^<>]*(<\/uri>)/$1$basedn$2/s)  {
      die("failed to update template/lism.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_template_lism_rule_conf {
  my $data = shift;

  my $file = '/opt/secioss/etc/template/lism-rule.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};

    $uri .= '/' if $uri !~ /\/$/;

    if ($contents !~ s/<uri>ldaps?:\/\/[^<>]*<\/uri>/<uri>$uri$basedn<\/uri>/s)  {
      die("failed to update template/lism-rule.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_slapd_conf {
  my $data = shift;

  my $file = '/opt/secioss/etc/openldap/slapd.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ s/(suffix\s+)"([^"]+)"/$1"$basedn"/)  {
      die("failed to update slapd.conf");
    }
    if ($contents !~ s/(basedn\s+)"([^"]+)"/$1"$basedn"/)  {
      die("failed to update slapd.conf");
    }
    if ($contents !~ s/(admindn\s+)"([^"]+)"/$1"$binddn"/)  {
      die("failed to update slapd.conf");
    }
    if ($contents !~ s/(adminpw\s+)"([^"]+)"/$1"$bindpw"/)  {
      die("failed to update slapd.conf");
    }
    if ($contents !~ s/(auditformat\s+".*\s+dn=\\"[^"]+\),)[^\\]+(\\"\s+.*\s+dn=\\"[^"]*\$11,)[^\\]+(\\".*)/$1$basedn$2$basedn$3/)  {
      die("failed to update slapd.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_ldap_conf {
  my $data = shift;

  my $file = '/etc/openldap/ldap.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if ($contents !~ s/^(TLS_REQCERT\s+)(\S+)$/$1never/m)  {
    $contents .= "\nTLS_REQCERT never\n";
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_lism_idp_conf {
  my $data = shift;

  my $file = '/usr/share/seciossadmin/conf/idsync/lism-idp.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ s/(<uri>)(ldaps?:\/\/[^\/]+\/)([^<]*)(<\/uri>\s*<binddn>)([^<]+)(<\/binddn>\s*<bindpw>)([^<]+)(<\/bindpw>)/$1$uri\/$basedn$4$binddn$6$bindpw$8/s)  {
      die("failed to update lism-idp.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_lism_slink_conf {
  my $data = shift;

  my $file = '/usr/share/seciossadmin/conf/idsync/lism-slink.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ s/(<uri>)(ldaps?:\/\/[^\/]+\/)([^<]*)(<\/uri>\s*<binddn>)([^<]+)(<\/binddn>\s*<bindpw>)([^<]+)(<\/bindpw>)/$1$uri\/$basedn$4$binddn$6$bindpw$8/s)  {
      die("failed to update lism-slink.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_httpd_conf {
  my $data = shift;

  my $file = '/etc/httpd/conf/httpd.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};

    if ($contents =~ /^(ServerName\s+)[-_.0-9A-Za-z]{1,255}(:[0-9]+)?/m) {
      my $res = 0;
      if (defined($2)) {
        # ポートあり
        if($contents !~ s/^(ServerName\s+)[-_.0-9A-Za-z]{1,255}(:[0-9]+)/$1$fqdn$2/gm) {
          $res = 1;
        }
      } else {
        # ポートなし
        if($contents =~ s/^(ServerName\s+)[-_.0-9A-Za-z]{1,255}/$1$fqdn/gm){
          $res = 1;
        }
      }
      # コメント行も書き換え
      if ($res && $contents !~ s/^(#ServerName\s+.*\n)/$1ServerName $fqdn:80/gm) {
        die("failed to update httpd.conf [ServerName]");
      }
    }
  }

  if ($contents !~ /^IncludeOptional +sso\/\*\.conf$/m) {
    $contents .= "\nIncludeOptional sso\/*.conf\n";
  }

  # Security Config
  if ($contents !~ s/Options.*FollowSymLinks$/Options FollowSymLinks/gm) {
    die("failed to update httpd.conf [Indexes]");
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_ssl_conf {
  my $data = shift;

  my $file = '/etc/httpd/conf.d/ssl.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};
    my $port = $data->{'fqdn'}->{'port'} ? $data->{'fqdn'}->{'port'} : '443';

    if ($contents !~ s/^(ServerName\s+)([-_.0-9A-Za-z]{1,255}(?::[0-9]+)?)/$1$fqdn:$port/gm) {
      if ($contents !~ s/^(#ServerName\s+.*\n)/$1ServerName $fqdn:$port/gm) {
        die("failed to update ssl.conf [ServerName]");
      }
    }
  }

  #ssl.conf
  if ($data->{product}->{code} =~ /same|siam/) {
    if ($contents !~ /^SSLCACertificatePath +\/etc\/httpd\/conf\/ssl.crt$/m) {
      $contents =~ s/(<\/VirtualHost>)/SSLCACertificatePath \/etc\/httpd\/conf\/ssl.crt\n$1/m
    }
    if ($contents !~ /^SSLCARevocationPath +\/etc\/httpd\/crl$/m) {
      $contents =~ s/(<\/VirtualHost>)/SSLCARevocationPath \/etc\/httpd\/crl\n$1/m
    }
    if ($contents !~ /^SSLCARevocationCheck +chain$/m) {
      $contents =~ s/(<\/VirtualHost>)/SSLCARevocationCheck chain\n$1/m
    }
  }
  if ($contents !~ /^IncludeOptional +sso\/\*\.conf$/m) {
    $contents =~ s/(<\/VirtualHost>)/IncludeOptional sso\/*.conf\n$1/m
  }
  if ($contents !~ /^IncludeOptional +sso-ssl\/\*\.conf$/m) {
    $contents =~ s/(<\/VirtualHost>)/IncludeOptional sso-ssl\/*.conf\n$1/m
  }

  # Security Config
  if ($contents !~ s/^SSLProtocol.*$/SSLProtocol -all +TLSv1.2/gm) {
    if ($contents !~ s/#SSLProtocol.*$/SSLProtocol -all +TLSv1.2/gm) {
      die("failed to update ssl.conf [SSLProtocol]");
    }
  }
  if ($contents !~ /^Header always set X-Frame-Options "SAMEORIGIN"$/m) {
    $contents =~ s/(<\/VirtualHost>)/Header always set X-Frame-Options "SAMEORIGIN"\n$1/m
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_my_cnf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/etc/my.cnf.d/mariadb-server.cnf", -fallback => "MYSQLD", -nomultiline => 1 ) or die "failed to open: @Config::IniFiles::errors";

  ini_setval($file, "mysqld", 'default-storage-engine', 'InnoDB');
  ini_setval($file, "mysqld", 'character-set-server', 'utf8');
  ini_setval($file, "mysqld", 'sql_mode', '');

  ini_save($file);
}

sub update_mpm_conf {
  my $data = shift;

  my $file = '/etc/httpd/conf.d/mpm_event.conf';
  if (! -f $file) {
    sysopen(my $fh, $file, O_CREAT | O_WRONLY) or die("failed to open: $file : $!");
    print($fh <<'EOT'
<IfModule mpm_event_module>
    StartServers             2
    MinSpareThreads          1
    MaxSpareThreads          4
    ServerLimit              32
    ThreadsPerChild          2
    ThreadLimit              64
    MaxRequestWorkers        64
    MaxConnectionsPerChild   5000
</IfModule>
EOT
);
  close($fh);
  }
}


sub update_php_ini {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/etc/php-fpm.d/www.conf" ) or die "failed to open: @Config::IniFiles::errors";

  if (defined($data->{'memcached'})) {
    my $str_memcached = '';
    my $hosts = $data->{'memcached'}->{'hosts'};
    my $multi = '';
    foreach my $host (@$hosts) {
      if ($str_memcached) {
        $multi = 1;
        $str_memcached .= ',';
      }
      $str_memcached .=  "$host->{'host'}:$host->{'port'}";
    }
    ini_setval($file, 'www', 'php_admin_flag[log_errors]', 'on');
    ini_setval($file, 'www', 'php_admin_value[date.timezone]', 'Asia/Tokyo');
    ini_setval($file, 'www', 'php_admin_value[error_log]', '/var/log/php-fpm/www-error.log');
    ini_setval($file, 'www', 'php_admin_value[error_reporting]', 'E_ALL');
    ini_setval($file, 'www', 'php_admin_value[expose_php]', 'Off');
    ini_setval($file, 'www', 'php_admin_value[max_execution_time]', '30');
    ini_setval($file, 'www', 'php_admin_value[max_input_vars]', '2000');
    ini_setval($file, 'www', 'php_admin_value[memory_limit]', '512M');
    ini_setval($file, 'www', 'php_value[memcached.default_connect_timeout]', '1000');
    ini_setval($file, 'www', 'php_value[memcached.sess_binary]', 'On');
    ini_setval($file, 'www', 'php_value[memcached.sess_number_of_replicas]', (scalar(@$hosts)-1));
    ini_setval($file, 'www', 'php_value[memcached.sess_remove_failed_servers]', ($multi ? 'On' : 'Off'));
    ini_setval($file, 'www', 'php_value[memcached.sess_server_failure_limit]', ($multi ? '2' : '0'));
    ini_setval($file, 'www', 'php_value[memcached.sess_lock_retries]', '10');
    ini_setval($file, 'www', 'php_value[post_max_size]', '1024M');
    ini_setval($file, 'www', 'php_value[session.cookie_httponly]', '1');
    ini_setval($file, 'www', 'php_value[session.cookie_secure]', '1');
    ini_setval($file, 'www', 'php_value[session.gc_maxlifetime]', '1440');
    ini_setval($file, 'www', 'php_value[session.name]', 'samsessid');
    ini_setval($file, 'www', 'php_value[session.save_handler]', 'memcached');
    ini_setval($file, 'www', 'php_value[session.save_path]', '"'.$str_memcached.'"');
    ini_setval($file, 'www', 'php_value[upload_max_filesize]', '1024M');
  }

  ini_save($file);
}

sub update_config_ini {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/var/www/conf/config.ini", -fallback => "GENERAL", -nomultiline => 1 ) or die "failed to open: @Config::IniFiles::errors";

  if ($data->{product}->{code} =~ /same|siam/) {
    if (defined($data->{'fqdn'})) {
      my $port = $data->{'fqdn'}->{'port'} ? $data->{'fqdn'}->{'port'} : '';
      ini_setval($file, "autologin", 'domain', '"'.$data->{'fqdn'}->{'domain'}.$port.'"');

      ini_setval($file, "fido", 'rpid', '"https://'.$data->{'fqdn'}->{'fqdn'}.$port.'"');
    }
  }

  if (defined($data->{'ldap'})) {
    if ($data->{product}->{code} =~ /same|siam/) {
      ini_setval($file, "autologin", 'uri', '"'.$data->{'ldap'}->{'uri'}.'"');
      ini_setval($file, "autologin", 'binddn', '"'.$data->{'ldap'}->{'binddn'}.'"');
      ini_setval($file, "autologin", 'bindpw', '"'.$data->{'ldap'}->{'bindpw'}.'"');
      ini_setval($file, "autologin", 'basedn', '"'.$data->{'ldap'}->{'basedn'}.'"');
    }

    ini_setval($file, "password", 'uri', '"'.$data->{'ldap'}->{'uri'}.'"');
    ini_setval($file, "password", 'binddn', '"'.$data->{'ldap'}->{'binddn'}.'"');
    ini_setval($file, "password", 'bindpw', '"'.$data->{'ldap'}->{'bindpw'}.'"');
    ini_setval($file, "password", 'basedn', '"'.$data->{'ldap'}->{'basedn'}.'"');
    if ($data->{product}->{code} =~ /sime|siam/) {
      ini_setval($file, "password", 'api_basedn', '"ou=Master,'.$data->{'ldap'}->{'basedn'}.'"');
    }

    ini_setval($file, "account", 'uri', '"'.$data->{'ldap'}->{'uri'}.'"');
    ini_setval($file, "account", 'binddn', '"'.$data->{'ldap'}->{'binddn'}.'"');
    ini_setval($file, "account", 'bindpw', '"'.$data->{'ldap'}->{'bindpw'}.'"');
    ini_setval($file, "account", 'basedn', '"'.$data->{'ldap'}->{'basedn'}.'"');
    if ($data->{product}->{code} =~ /sime|siam/) {
      ini_setval($file, "account", 'api_basedn', '"ou=Master,'.$data->{'ldap'}->{'basedn'}.'"');
    }
  }

  if ($data->{product}->{code} =~ /same|siam/) {
    if (defined($data->{'mysql'})) {
      ini_setval($file, "cert_download", 'db_host', '"'.$data->{'mysql'}->{'host'}.'"');
      ini_setval($file, "cert_download", 'db_user', '"'.$data->{'mysql'}->{'user'}.'"');
      ini_setval($file, "cert_download", 'db_password', '"'.$data->{'mysql'}->{'password'}.'"');
    }
  }

  ini_save($file);
}

sub update_simapi_conf {
  my $data = shift;

  my $simapi_conf = Config::General->new('/var/www/conf/simapi.conf') or die "failed to open: $!";
  my %conf = $simapi_conf->getall;

  # for ldap
  if (defined($data->{'ldap'})) {
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $admin = $data->{'ldap'}->{'binddn'};
    my $adminpw = $data->{'ldap'}->{'bindpw'};

    $admin =~ s/cn=([^,]+),$basedn/$1/i;

    my $auditformat = $conf{'auditformat'};

    if ($auditformat !~ s/(.*\s+dn="[^"]+\),)[^"]+("\s+.*\s+dn="[^"]*\$11,)[^"]+(".*)/$1$basedn$2$basedn$3/m) {
      die("failed to update simapi.conf");
    }

    $conf{'basedn'} = $basedn;
    $conf{'admin'} = $admin;
    $conf{'adminpw'} = $adminpw;
    $conf{'auditformat'} = $auditformat;
  }

  # for memcache
  if (defined($data->{'memcached'})) {
    my $str_memcached = '';
    my $hosts = $data->{'memcached'}->{'hosts'};
    foreach my $host (@$hosts) {
      $str_memcached .= ' ' if $str_memcached;
      $str_memcached .= "$host->{'host'}:$host->{'port'}";
    }

    $conf{'memcache_host'} = $str_memcached;
  }

  Config::General::SaveConfig('/var/www/conf/simapi.conf', \%conf);
}

sub update_php_conf {
  my $file = '/etc/httpd/conf.d/php.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  $contents =~ s/^(SetEnv PHP_VALUE "session\.save.*)/#$1/gm;

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_office365_conf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/opt/secioss/etc/office365csv.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  if (defined($data->{'office365'})) {
    ini_setval($file, "GENERAL", 'host', $data->{'office365'}->{'host'});
    ini_setval($file, "GENERAL", 'protocol', 'ssh');
    ini_setval($file, "GENERAL", 'sshuser', $data->{'office365'}->{'sshuser'});
  }

  ini_save($file);
}

sub update_office365_csv {
  my $data = shift;

  if ($data->{'function'}) {
    if ($data->{'function'}->{'office365'} =~ /yes/i) {
      if (! -f '/opt/secioss/etc/office365csv.conf') {
        my $file = '/opt/secioss/etc/office365csv.conf';
        sysopen(my $fh, $file, O_CREAT | O_WRONLY) or die("failed to open: $file : $!");
        print($fh <<'EOT'
csvdir = /opt/secioss/var/lib/office365
datadir = /data/office365
host = office365.example.com
protocol = ssh
certdir =  cert
office365dir = C:/office365/data
sshuser =  Administrator
delexpire = 604800
EOT
);

        close($fh);
      }

      printf("Office 365連携を使用する場合は [Office 365連携サーバーへの接続設定] を行ってください。\n");
    } else {
      unlink('/opt/secioss/etc/office365csv.conf');
    }
  }
}

sub update_refreshtoken_conf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/opt/secioss/etc/refreshtoken.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    ini_setval($file, "GENERAL", 'ldap_uri', $uri);
    ini_setval($file, "GENERAL", 'ldap_user', $binddn);
    ini_setval($file, "GENERAL", 'ldap_password', $bindpw);
    ini_setval($file, "GENERAL", 'ldap_basedn', $basedn);
  }

  ini_save($file);
}

sub update_passwd {
  my $data = shift;

  if (defined($data->{'general'}->{'admin_password'})) {
    my $password = $data->{'general'}->{'admin_password'};
    my $rc = system("htpasswd -bv /usr/share/seciossadmin/etc/passwd admin '$password' >&/dev/null");
    if ($rc) {
      if (-e '/usr/share/seciossadmin/etc/passwd') {
        $rc = system("htpasswd -bs /usr/share/seciossadmin/etc/passwd admin '$password' >&/dev/null");
        if ($rc) {
          die("failed to update passwd[update]");
        }
        printf("管理者パスワードを更新しました。\n");
      } else {
        system("touch /usr/share/seciossadmin/etc/passwd");
        $rc = system("htpasswd -bcs /usr/share/seciossadmin/etc/passwd admin '$password' >&/dev/null");
        if ($rc) {
          die("failed to update passwd[create]");
        }
        printf("管理者パスワードファイルを作成しました。\n");
      }
    }

    $rc = chmod(0644, ("/usr/share/seciossadmin/etc/passwd"));
    if ($rc != 0) {
      $rc = chown(48, 48, ("/usr/share/seciossadmin/etc/passwd")); # apache:apache
    }
    if ($rc == 0) {
      die("failed to change permission");
    }
  }
}

sub update_auth_tkt_conf {
  my $data = shift;

  my $file = '/etc/httpd/conf.d/auth_tkt.conf';
  if ($data->{product}->{code} =~ /sime|siam/) {
    $file = '/opt/secioss/etc/auth_tkt.conf';
  }

  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'general'}->{'admin_password'})) {
    my $secret = Digest::SHA::sha256_base64($data->{'general'}->{'admin_password'}.time);

    $contents =~ s/(TKTAuthSecret\s+)"Appropriate Value"/$1"$secret"/s;
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_cacolabo_conf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/opt/secioss/etc/cacolabo.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    ini_setval($file, "GENERAL", 'ldap_uri', $uri);
    ini_setval($file, "GENERAL", 'ldap_user', $binddn);
    ini_setval($file, "GENERAL", 'ldap_password', $bindpw);
    ini_setval($file, "GENERAL", 'ldap_basedn', $basedn);
  }

  # for mysql
  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    my $port = $data->{'mysql'}->{'port'};
    my $user = $data->{'mysql'}->{'user'};
    my $password = $data->{'mysql'}->{'password'};

    ini_setval($file, "GENERAL", 'db_host', "$host:$port");
    ini_setval($file, "GENERAL", 'db_user', $user);
    ini_setval($file, "GENERAL", 'db_password', $password);
  }

  ini_save($file);
}

sub update_report_crawler_conf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/opt/secioss/etc/report_crawler.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    ini_setval($file, "GENERAL", 'ldap_uri', $uri);
    ini_setval($file, "GENERAL", 'ldap_user', $binddn);
    ini_setval($file, "GENERAL", 'ldap_password', $bindpw);
    ini_setval($file, "GENERAL", 'ldap_basedn', $basedn);
  }

  # for mysql
  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    my $port = $data->{'mysql'}->{'port'};
    my $user = $data->{'mysql'}->{'user'};
    my $password = $data->{'mysql'}->{'password'};

    ini_setval($file, "GENERAL", 'db_log_host', "$host:$port");
    ini_setval($file, "GENERAL", 'db_log_user', $user);
    ini_setval($file, "GENERAL", 'db_log_password', $password);
    ini_setval($file, "GENERAL", 'db_report_host', "$host:$port");
    ini_setval($file, "GENERAL", 'db_report_user', $user);
    ini_setval($file, "GENERAL", 'db_report_password', $password);
  }

  ini_save($file);
}

sub update_sam_conf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/var/www/conf/sam.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  if (defined($data->{'fqdn'})) {
    my $domain = $data->{'fqdn'}->{'domain'};
    my $port = $data->{'fqdn'}->{'port'};
    if ($port) {
      $domain .= ":$port";
    }

    ini_setval($file, "GENERAL", 'domain', $domain);

    $domain=~ s/\./\\./g;
    ini_setval($file, "GENERAL", 'check_back', 'https://(([^/]+\.)?'.$domain.')/');
  }

  if (defined($data->{'ldap'})) {
    ini_setval($file, "GENERAL", 'uri', $data->{'ldap'}->{'uri'});
    ini_setval($file, "GENERAL", 'admin', $data->{'ldap'}->{'binddn'});
    my $sampasswd = $data->{'ldap'}->{'bindpw'};
    $sampasswd =~ s/#/\\#/g;
    ini_setval($file, "GENERAL", 'passwd', $sampasswd);
    ini_setval($file, "GENERAL", 'basedn', $data->{'ldap'}->{'basedn'});

    ini_setval($file, "GENERAL", 'pw_uri', $data->{'ldap'}->{'uri'});
    ini_setval($file, "GENERAL", 'pw_binddn', $data->{'ldap'}->{'binddn'});
    ini_setval($file, "GENERAL", 'pw_bindpw', $sampasswd);
  }

  if (defined($data->{'memcached'})) {
    my $str_memcached = '';
    my $hosts = $data->{'memcached'}->{'hosts'};
    foreach my $host (@$hosts) {
      $str_memcached .= ' ' if $str_memcached;
      $str_memcached .= "$host->{'host'}:$host->{'port'}";
    }

    ini_setval($file, "GENERAL", 'memcache_host', $str_memcached);
  }

  ini_save($file);
}

sub update_sam_external_conf {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/var/www/conf/sam_external.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  if (defined($data->{'fqdn'})) {
    my $domain = $data->{'fqdn'}->{'domain'};
    my $port = $data->{'fqdn'}->{'port'};
    if ($port) {
      $domain .= $port;
    }

    ini_setval($file, "GENERAL", 'domain', $domain);

    $domain=~ s/\./\\./g;
    ini_setval($file, "GENERAL", 'check_back', 'https://(([^/]+\.)?'.$domain.')/');
  }

  if (defined($data->{'ldap'})) {
    ini_setval($file, "GENERAL", 'uri', $data->{'ldap'}->{'uri'});
    ini_setval($file, "GENERAL", 'admin', $data->{'ldap'}->{'binddn'});
    ini_setval($file, "GENERAL", 'passwd', $data->{'ldap'}->{'bindpw'});
    ini_setval($file, "GENERAL", 'basedn', $data->{'ldap'}->{'basedn'});

    ini_setval($file, "GENERAL", 'pw_uri', $data->{'ldap'}->{'uri'});
    ini_setval($file, "GENERAL", 'pw_binddn', $data->{'ldap'}->{'binddn'});
    ini_setval($file, "GENERAL", 'pw_bindpw', $data->{'ldap'}->{'bindpw'});
  }

  if (defined($data->{'memcached'})) {
    my $str_memcached = '';
    my $hosts = $data->{'memcached'}->{'hosts'};
    foreach my $host (@$hosts) {
      $str_memcached .= ' ' if $str_memcached;
      $str_memcached .= "$host->{'host'}:$host->{'port'}";
    }

    ini_setval($file, "GENERAL", 'memcache_host', $str_memcached);
  }

  ini_save($file);
}

sub update_kerb_conf {
  my $data = shift;

  my $file = '/etc/httpd/sso/kerb.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };
  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};
    my $port = $data->{'fqdn'}->{'port'};
    if ($port) {
      $fqdn .= ":$port";
    }
    if ($contents !~ s/https:\/\/([^\$].+)\$/https:\/\/$fqdn\$/g) {
      die("failed to update kerb.conf");
    }
    if ($contents !~ s/!\^([^\$].+)\$/!\^$fqdn\$/g) {
      die("failed to update2 kerb.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_kerblogin_conf {
  my $data = shift;

  my $file = '/var/www/conf/kerblogin.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };
  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};
    if ($contents !~ s/servername = (.*)/servername = $fqdn/g) {
      die("failed to update kerblogin.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_kerbextlogin_conf {
  my $data = shift;

  my $file = '/var/www/conf/kerbextlogin.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };
  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};

    if ($contents !~ s/servername = (.*)/servername = $fqdn/g) {
      die("failed to update kerbextlogin.conf");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_oauth_auth_config_ini {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/usr/share/oauth_auth/conf/config.ini", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  if (defined($data->{'ldap'})) {
    ini_setval($file, "GENERAL", 'uri', $data->{'ldap'}->{'uri'});
    ini_setval($file, "GENERAL", 'binddn', $data->{'ldap'}->{'binddn'});
    ini_setval($file, "GENERAL", 'bindpw', $data->{'ldap'}->{'bindpw'});
    ini_setval($file, "GENERAL", 'basedn', $data->{'ldap'}->{'basedn'});
  }

  ini_save($file);
}

sub update_oauth_service_config_ini {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/usr/share/oauth_service/conf/config.ini", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};
    ini_setval($file, "GENERAL", 'id_token_issuer', 'https://'.$fqdn);
  }

  if (defined($data->{'ldap'})) {
    ini_setval($file, "GENERAL", 'uri', $data->{'ldap'}->{'uri'});
    ini_setval($file, "GENERAL", 'binddn', $data->{'ldap'}->{'binddn'});
    ini_setval($file, "GENERAL", 'bindpw', $data->{'ldap'}->{'bindpw'});
    ini_setval($file, "GENERAL", 'basedn', $data->{'ldap'}->{'basedn'});
  }

  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    if(defined($data->{'mysql'}->{'port'}) && $data->{'mysql'}->{'port'} && $data->{'mysql'}->{'port'} ne 3306) {
      $host .= ":".$data->{'mysql'}->{'port'};
    }
    ini_setval($file, "GENERAL", 'db_host', $host);
    ini_setval($file, "GENERAL", 'db_user', $data->{'mysql'}->{'user'});
    ini_setval($file, "GENERAL", 'db_pass', $data->{'mysql'}->{'password'});
  }

  ini_save($file);
}

sub update_oidc_config_ini {
  my $data = shift;

  my $file = Config::IniFiles->new( -file => "/usr/share/oidc/conf/config.ini", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};
    ini_setval($file, "GENERAL", 'id_token_issuer', 'https://'.$fqdn);
  }

  if (defined($data->{'ldap'})) {
    ini_setval($file, "GENERAL", 'uri', $data->{'ldap'}->{'uri'});
    ini_setval($file, "GENERAL", 'binddn', $data->{'ldap'}->{'binddn'});
    ini_setval($file, "GENERAL", 'bindpw', $data->{'ldap'}->{'bindpw'});
    ini_setval($file, "GENERAL", 'basedn', $data->{'ldap'}->{'basedn'});
  }

  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    if(defined($data->{'mysql'}->{'port'}) && $data->{'mysql'}->{'port'} && $data->{'mysql'}->{'port'} ne 3306) {
      $host .= ":".$data->{'mysql'}->{'port'};
    }
    ini_setval($file, "GENERAL", 'db_host', $host);
    ini_setval($file, "GENERAL", 'db_user', $data->{'mysql'}->{'user'});
    ini_setval($file, "GENERAL", 'db_pass', $data->{'mysql'}->{'password'});
  }

  if (defined($data->{'oidc_cert'})) {
    ini_setval($file, "GENERAL", 'id_token_key_passphrase', $data->{'oidc_cert'}->{'oidc_key_pass'});
  }

  ini_save($file);
}

sub update_samoauth_conf {
  my $data = shift;

  if ($data->{product}->{code} =~ /sime/) {
    system('cp /etc/httpd/sso/samoauth.sime.conf.disable /etc/httpd/sso/samoauth.conf');
  } else {
    system('cp /etc/httpd/sso/samoauth.conf.disable /etc/httpd/sso/samoauth.conf');
  }
}

sub update_ldap_php {
  my $data = shift;

  my $file = '/usr/share/simplesamlphp/config/ldap.php';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ s/('auth.ldap.hostname'\s*=>\s*')([^']+)(')/$1$uri$3/g) {
      die("failed to update ldap.php [auth.ldap.hostname]");
    }
    if ($contents !~ s/('auth.ldap.search.base'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
      die("failed to update ldap.php [auth.ldap.search.base]");
    }
    if ($contents !~ s/('auth.ldap.search.username'\s*=>\s*')([^']+)(')/$1$binddn$3/g) {
      die("failed to update ldap.php [auth.ldap.search.username]");
    }
    if ($contents !~ s/('auth.ldap.search.password'\s*=>\s*')([^']+)(')/$1$bindpw$3/g) {
      die("failed to update ldap.php [auth.ldap.search.password]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_ldapwrite_php {
  my $data = shift;

  my $file = '/usr/share/simplesamlphp/config/ldap_write.php';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ s/('auth.ldap.hostname'\s*=>\s*')([^']+)(')/$1$uri$3/g) {
      die("failed to update ldap.php [auth.ldap.hostname]");
    }
    if ($contents !~ s/('auth.ldap.search.base'\s*=>\s*')([^']+)(')/$1$basedn$3/g) {
      die("failed to update ldap.php [auth.ldap.search.base]");
    }
    if ($contents !~ s/('auth.ldap.search.username'\s*=>\s*')([^']+)(')/$1$binddn$3/g) {
      die("failed to update ldap.php [auth.ldap.search.username]");
    }
    if ($contents !~ s/('auth.ldap.search.password'\s*=>\s*')([^']+)(')/$1$bindpw$3/g) {
      die("failed to update ldap.php [auth.ldap.search.password]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_config_php {
  my $data = shift;

  my $file = '/usr/share/simplesamlphp/config/config.php';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  # for mysql
  if (defined($data->{'mysql'})) {
    my $host = $data->{'mysql'}->{'host'};
    my $port = $data->{'mysql'}->{'port'};
    my $user = $data->{'mysql'}->{'user'};
    my $password = $data->{'mysql'}->{'password'};

    if ($contents !~ s/('consent_pdo_connect'\s*=>\s*')([^']+)(')/${1}mysql:host=$host;port=$port;dbname=consent_db$3/g) {
      die("failed to update mysql config.php [consent_pdo_connect]");
    }
    if ($contents !~ s/('consent_pdo_user'\s*=>\s*')([^']+)(')/$1$user$3/g) {
      die("failed to update mysql config.php [consent_pdo_user]");
    }
    if ($contents !~ s/('consent_pdo_passwd'\s*=>\s*')([^']+)(')/$1$password$3/g) {
      die("failed to update mysql config.php [consent_pdo_passwd]");
    }
  }

  # for memcached
  if (defined($data->{'memcached'})) {
    my $index = 0;
    my $str_memcached = "\n";
    my $hosts = $data->{'memcached'}->{'hosts'};
    foreach my $host (@$hosts) {
      $str_memcached .= "        [ ['hostname' => '$host->{'host'}'], ],\n";
      $index ++;
    }
    if ($contents !~ s/('memcache_store\.servers'\s*=>\s*\[)(?:\s*(\[\s*\[[^\]]+\],\s*\],\n))+(\s*\],)/$1$str_memcached$3/gm) {
      die("failed to update memcache config.php [memcache_store]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_authmemcookie_php {
  my $data = shift;

  my $file = '/usr/share/simplesamlphp/config/authmemcookie.php';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'memcached'})) {
    my $str_memcached = '';
    my $port = '';
    my $hosts = $data->{'memcached'}->{'hosts'};
    foreach my $host (@$hosts) {
      $str_memcached .= ',' if $str_memcached;
      $str_memcached .= "$host->{'host'}";
      $port = $host->{'port'};
    }

    if ($contents !~ s/('memcache.host'\s*=>\s*')([^']+)(')/$1$str_memcached$3/g) {
      die("failed to update authmemcookie.php [memcache.host]");
    }
    if ($contents !~ s/('memcache.port'\s*=>\s*)([0-9]+)([^0-9])/$1$port$3/g) {
      die("failed to update authmemcookie.php [memcache.port]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_saml20_idp_hosted_php {
  my $data = shift;

  my $file = '/usr/share/simplesamlphp/metadata/saml20-idp-hosted.php';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};
    my $port = $data->{'fqdn'}->{'port'};
    if ($port) {
      $fqdn .= ":$port";
    }

    if ($contents !~ s/(')(https?:\/\/[^'\/]+)([^']*'\s*=>\s*\[)/$1https:\/\/$fqdn$3/g) {
      die("failed to update saml20-idp-hosted.php [fqdn]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_saml20_sp_hosted_php {
  my $data = shift;

  my $file = '/usr/share/simplesamlphp/metadata/saml20-sp-hosted.php';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};
    my $port = $data->{'fqdn'}->{'port'};
    if ($port) {
      $fqdn .= ":$port";
    }

    if ($contents !~ s/(')([^']+)('\s*=>\s*\[)/$1https:\/\/$fqdn$3/g) {
      die("failed to update saml20-sp-hosted.php [fqdn]");
    }

    if ($contents !~ s/('host'\s*=>\s*')[^']*'/$1$fqdn'/g) {
      die("failed to update saml20-sp-hosted.php [host]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_shib13_idp_hosted_php {
  my $data = shift;

  my $file = '/usr/share/simplesamlphp/metadata/shib13-idp-hosted.php';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'fqdn'})) {
    my $fqdn = $data->{'fqdn'}->{'fqdn'};

    if ($contents !~ s/(')(https?:\/\/[^'\/]+)([^']*'\s*=>\s*\[)/$1https:\/\/$fqdn$3/g) {
      die("failed to update shib13-idp-hosted.php [fqdn]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_sso_conf {
  my $data = shift;

  my $file = '/etc/httpd/conf/sso.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'fqdn'})) {
    my $domain = $data->{'fqdn'}->{'domain'};
    my $port = $data->{'fqdn'}->{'port'};
    if ($port) {
      $domain .= ":$port";
    }

    if ($contents !~ s/^(TKTAuthDomain\s+).*/$1$domain/gm) {
      die("failed to update sso.conf [TKTAuthDomain]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_auth_memcookie_conf {
  my $data = shift;

  my $file = '/etc/httpd/auth/auth_memcookie.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if (defined($data->{'memcached'})) {
    my $str_memcached = '';
    my $hosts = $data->{'memcached'}->{'hosts'};
    foreach my $host (@$hosts) {
      $str_memcached .= ',' if $str_memcached;
      $str_memcached .= "$host->{'host'}:$host->{'port'}";
    }

    if ($contents !~ s/^(Auth_memCookie_Memcached_AddrPort\s+).*/$1$str_memcached/gm) {
      die("failed to update auth_memcookie.conf [Auth_memCookie_Memcached_AddrPort]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

# cronの有効/無効
sub update_cron {
  my $cron_filename = shift;
  my $use_flag = shift;
  my $cron_src = '/opt/secioss/cron/'.$cron_filename;
  my $cron_dest = '/etc/cron.d/'.$cron_filename;

  #filename check
  if (!defined $cron_filename || $cron_filename eq '') {
    die("No cron file specified.");
  }

  if ($use_flag =~ /yes/i) {
    # create symbolic link
    if (! -l $cron_src && ! -f $cron_dest){
      symlink $cron_src, $cron_dest or warn "Can't create symlink for $cron_dest:$!";
    }
    if (! -f $cron_dest) {
      die("Can't create symlink for $cron_dest");
    }
  } else {
    # delete symbolic link
    if (-l $cron_dest) {
      unlink $cron_dest
        or die "cannot unlink file: $!";
    }
    if (-l $cron_dest) {
      die("Can't delete symlink for $cron_dest");
    }
  }
}

sub update_pw_words {
  my $data = shift;

  if (defined($data->{'pw_words'}->{'agree'})) {
    if ($data->{'pw_words'}->{'agree'} =~ /yes/i) {
      yum_control({ 'yum' => { 'packages' => ['words'] } }, 'install');

      my $err = `create-cracklib-dict /usr/share/dict/linux.words 2>&1`;
      my $rc = $?;
      if ($rc) {
        die($err);
      }
    }
  }
}

sub update_seciossadmin_hosts {
  my $data = shift;

  if (defined($data->{'fqdn'})) {
    my $message = `echo $data->{'fqdn'}->{'fqdn'} >/usr/share/seciossadmin/etc/hosts 2>&1`;
    if ($?) {
      die("failed to create seciossadmin hosts");
    }
    my $rc = chmod(0644, ("/usr/share/seciossadmin/etc/hosts"));
    if ($rc != 0) {
      $rc = chown(48, 48, ("/usr/share/seciossadmin/etc/hosts")); # apache:apache
    }
    if ($rc == 0) {
      die("failed to change permission");
    }
  }
}

sub update_radius_ldap {
  my $data = shift;

  my $file = '/etc/raddb/mods-available/ldap';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    $uri =~ s/^(ldaps?):\/\/(.*)$/$2/;
    my $proto = $1;
    my $port = $proto eq 'ldaps' ? '636' : '389';

    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ s/(server\s*=\s*")([^"]*)(")/$1$uri$3/g) {
      die("failed to update radius ldap [server]");
    }
    if ($contents !~ s/(port\s*=\s*")([^"]*)(")/$1$port$3/g) {
      die("failed to update radius ldap [port]");
    }
    if ($contents !~ s/(identity\s*=\s*")([^"]*)(")/$1$binddn$3/g) {
      die("failed to update radius ldap [identity]");
    }
    if ($contents !~ s/(password\s*=\s*")([^"]*)(")/$1$bindpw$3/g) {
      die("failed to update radius ldap [password]");
    }
    if ($contents !~ s/(base_dn\s*=\s*")(dc=[^"]*)(")/$1$basedn$3/g) {
      die("failed to update radius ldap [base_dn]");
    }
  }

  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_radius_secioss_ini {
  my $data = shift;

# get AuthTicketSecret
  my $file = '/etc/httpd/conf.d/auth_tkt.conf';
  if ($data->{product}->{code} =~ /sime|siam/) {
    $file = '/opt/secioss/etc/auth_tkt.conf';
  }

  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };
  close($fh);
  my ($secret) = ($contents =~ /TKTAuthSecret\s+"([^"]+)"/);

# write radius_secioss.ini
  $file = '/opt/secioss/etc/radius_secioss.ini';
  sysopen($fh, $file, O_RDWR) or die("failed to open: $file : $!");
  $contents = do { local $/ = '\0'; <$fh> };

  # AuthTKT
  if ($contents !~ s/(TKTAuthSecret\s*=\s*")([^"]*)(")/$1$secret$3/g) {
    die("failed to update radius_secioss_ini [TKTAuthSecret]");
  }

  # memcached
  if (defined($data->{'memcached'})) {
    my $str_memcached = '';
    my $hosts = $data->{'memcached'}->{'hosts'};
    foreach my $host (@$hosts) {
      $str_memcached .= ($str_memcached ne '' ? ' ' : '')."$host->{'host'}:$host->{'port'}";
    }

    if ($contents !~ s/(memcache_host\s*=\s*")([^"]*)(")/$1$str_memcached$3/g) {
      die("failed to update radius_secioss_ini [memcache_host]");
    }
  }

  # ldap
  if (defined($data->{'ldap'})) {
    my $uri = $data->{'ldap'}->{'uri'};
    my $basedn = $data->{'ldap'}->{'basedn'};
    my $binddn = $data->{'ldap'}->{'binddn'};
    my $bindpw = $data->{'ldap'}->{'bindpw'};

    if ($contents !~ s/(ldap_uri\s*=\s*")([^"]*)(")/$1$uri$3/g) {
      die("failed to update radius_secioss_ini [ldap_uri]");
    }
    if ($contents !~ s/(ldap_binddn\s*=\s*")([^"]*)(")/$1$binddn$3/g) {
      die("failed to update radius_secioss_ini [ldap_binddn]");
    }
    if ($contents !~ s/(ldap_bindpw\s*=\s*")([^"]*)(")/$1$bindpw$3/g) {
      die("failed to update radius_secioss_ini [ldap_bindpw]");
    }
    if ($contents !~ s/(ldap_basedn\s*=\s*")([^"]*)(")/$1$basedn$3/g) {
      die("failed to update radius_secioss_ini [ldap_basedn]");
    }
  }


  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub delete_radius_enable {
  my $data = shift;

  if (defined($data->{'function'}->{'radius'})) {
    my @removelist = (
      '/etc/raddb/mods-enabled/cache_eap',
      '/etc/raddb/mods-enabled/date',
      '/etc/raddb/mods-enabled/detail.log',
      '/etc/raddb/mods-enabled/dhcp',
      '/etc/raddb/mods-enabled/digest',
      '/etc/raddb/mods-enabled/dynamic_clients',
      '/etc/raddb/mods-enabled/echo',
      '/etc/raddb/mods-enabled/exec',
      '/etc/raddb/mods-enabled/expr',
      '/etc/raddb/mods-enabled/files',
      '/etc/raddb/mods-enabled/linelog',
      '/etc/raddb/mods-enabled/ntlm_auth',
      '/etc/raddb/mods-enabled/passwd',
      '/etc/raddb/mods-enabled/realm',
      '/etc/raddb/mods-enabled/replicate',
      '/etc/raddb/mods-enabled/soh',
      '/etc/raddb/mods-enabled/sradutmp',
      '/etc/raddb/mods-enabled/unix',
      '/etc/raddb/mods-enabled/unpack',
      '/etc/raddb/mods-enabled/utf8',
      '/etc/raddb/sites-enabled/check-eap-tls',
      '/etc/raddb/sites-enabled/inner-tunnel',
      '/etc/raddb/sites-enabled/mac_addr',
      '/etc/raddb/sites-enabled/otp',
      '/etc/raddb/sites-enabled/default'
    );

    foreach my $removefile (@removelist) {
      if ( -e $removefile) {
        unlink $removefile
          or die "cannot unlink file: $!";
      }
    }
  }
}

sub create_ldap_cert {
  my $data = shift;

  if (defined($data->{'ldap_cert'}) && $data->{'ldap_cert'}->{'create'} eq 'yes') {
    my $country = $data->{'ldap_cert'}->{'country'};
    my $state = $data->{'ldap_cert'}->{'state'};
    my $locality = $data->{'ldap_cert'}->{'locality'};
    my $organizational_name = $data->{'ldap_cert'}->{'organizational_name'};
    my $organizational_unit = $data->{'ldap_cert'}->{'organizational_unit'};
    my $common_name = $data->{'ldap_cert'}->{'common_name'};
    my $expiration_date = $data->{'ldap_cert'}->{'expiration_date'};
    my $key_length = $data->{'ldap_cert'}->{'key_length'};
    if (!defined $data->{'ldap_cert'}->{'pkcs12_password'}) {
      $data->{'ldap_cert'}->{'pkcs12_password'} = String::Random->new->randregex('[A-Za-z0-9]{16}');
    }
    my $p12pass = $data->{'ldap_cert'}->{'pkcs12_password'};

    my $privkey = '/opt/secioss/ldap/389ds/slapd.key';
    my $pubkey = '/opt/secioss/ldap/389ds/slapd.crt';
    my $p12file = '/opt/secioss/ldap/389ds/slapd.p12';

    my $message = `openssl genrsa -out '$privkey' $key_length 2>&1`;
    if ($?) {
      die("failed to create slapd.key:$message");
    } else {
      printf("create slapd.key Success\n");
    }

    $message = `openssl req -new -x509 -key '$privkey' -out '$pubkey' -days $expiration_date -subj "/C=$country/ST=$state/L=$locality/O=$organizational_name/OU=$organizational_unit/CN=$common_name" 2>&1`;
    if ($?) {
      die("failed to create openldap.crt:$message");
    } else {
      printf("create slapd.crt Success\n");
    }

    $message = `openssl pkcs12 -export -inkey '$privkey' -in '$pubkey' -out '$p12file' -nodes -name Server-Cert -passout pass:$p12pass 2>&1`;
    if ($?) {
      die("failed to convert slapd.p12:$message");
    } else {
      printf("convert slapd.p12 Success\n");
    }
  }
}

sub update_389ds_slapd_cert {
  my $data = shift;

  my $p12file = '/opt/secioss/ldap/389ds/slapd.p12';
  my $dir389ds = '/etc/dirsrv/slapd-389ds';

  open(FH, '<', '/etc/system-release') or die("unknown os");
  my $os = <FH>;
  close(FH);

  if ($os =~ /release 9/) {
    my $file = '/etc/dirsrv/slapd-389ds/pin.txt';
    if(-e $file) {
      # pin.txt からパスワード読み込み
      sysopen(my $fh, $file, O_RDONLY | O_CREAT) or die("failed to open: $file : $!");
      my $contents = do { local $/ = '\0'; <$fh> };
      close($fh);
      $data->{'ldap_cert'}->{'nss_password'} = $1 if ($contents =~ /Internal\s*\(Software\)\s*Token:(.*)$/);
    }
  }

  if (defined $data->{'ldap_cert'}->{'pkcs12_password'} && defined $data->{'ldap_cert'}->{'nss_password'}) {
    # NSSを利用して 389ds に証明書をインポート
    if (! -d $dir389ds) {
      die("not exists 389DirectoryServer dir: $dir389ds");
    }
    my $p12pass = $data->{'ldap_cert'}->{'pkcs12_password'};
    my $nsspass = $data->{'ldap_cert'}->{'nss_password'};
    # 既に登録されている証明書を削除
    my $message = `certutil -L -d '$dir389ds' | grep Server-Cert`;
    if ($message) {
      my @matches = $message =~ m/Server-Cert/g;
      for (my $i=0; $i<scalar(@matches); $i++) {
        $message = `certutil -D -d '$dir389ds' -n 'Server-Cert'`;
        if ($?) {
          die("failed to 389DirectoryServer nssdb remove certificate: $message");
        }
      }
    }

    # 証明書登録
    $message = `pk12util -i '$p12file' -d '$dir389ds' -K $nsspass -W $p12pass 2>&1`;
    if ($?) {
      die("failed to 389DirectoryServer nssdb import certificate: $message");
    }

    # p12 のPINをテキストに登録
    $message = `echo 'Internal (Software) Token:$nsspass' > /etc/dirsrv/slapd-389ds/pin.txt 2>&1`;
    if ($?) {
      die("failed to create NSS pin.txt:$message");
    }

    printf("389DirectoryServer import certificate Success\n");
  }
}


sub update_openldap_ldapconf {
  my $data = shift;

  my $file = '/etc/openldap/ldap.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  if ($contents !~ /TLS_REQCERT\s*never/i) {
    $contents =~ s/\z/\nTLS_REQCERT\ never\n/g;
  }
  seek($fh, 0, 0);
  print($fh $contents);
  truncate($fh, tell($fh));

  close($fh);
}

sub update_welcomeconf {
  my $data = shift;

  my $file = '/etc/httpd/conf.d/welcome.conf';
  if (-e $file) {
    my $err = `mv $file $file.disable 2>&1`;
    my $rc = $?;
    if ($rc) {
      die($err);
    }
  }
}

sub update_samadminssh {
  my $data = shift;

  my $file = '/opt/secioss/etc/samadmin.conf';
  my $user = $data->{'ssh'}->{'user'};
  my $port = $data->{'ssh'}->{'port'};

  if (defined($data->{'ssh'}->{'user'}) && defined($data->{'ssh'}->{'port'})) {
    if (-e $file) {
      # update
      sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
      my $contents = do { local $/ = '\0'; <$fh> };

      if ($contents !~ s/^(ssh_user\s*=\s*")([^"]*)(")$/$1$user$3/gm) {
        die("failed to update samadmin_ssh [ssh_user]");
      }

      if ($contents !~ s/^(ssh_port\s*=\s*")([^"]*)(")$/$1$port$3/gm) {
        die("failed to update samadmin_ssh [ssh_port]");
      }

      seek($fh, 0, 0);
      print($fh $contents);
      truncate($fh, tell($fh));

      close($fh);
    } else {
      # create
    sysopen(my $fh, $file, O_CREAT | O_WRONLY) or die("failed to open: $file : $!");
    print($fh <<"EOT"
facility = "local5"
ssh_user = "${user}"
ssh_port = "${port}"
prefix_cmd = "sudo"
file_owner = "apache:apache"
timeout = "10"
EOT
);
  close($fh);
    }
  }
}

sub yum_control {
  my $data = shift;
  my $operation = shift;

  if (defined($data->{'yum'}->{'packages'})) {
    foreach my $pkg (@{$data->{'yum'}->{'packages'}}) {
      printf("%sを%sしています。\n", $pkg, $operation);
      my $err = `yum -y $operation $pkg 2>&1`;
      my $rc = $?;
      if ($rc) {
        die($err);
      }
    }
  }
}

sub dnf_control {
  my $data = shift;
  my $operation = shift;

  if (defined($data->{'dnf'}->{'packages'})) {
    # パッケージ 操作
    foreach my $pkg (@{$data->{'dnf'}->{'packages'}}) {
      printf("%sを%sしています。\n", $pkg, $operation);
      my $err = `dnf -y $operation $pkg 2>&1`;
      my $rc = $?;
      if ($rc) {
        die($err);
      }
    }
  } elsif (defined($data->{'dnf'}->{'module'})) {
    # モジュール 操作
    foreach my $module (@{$data->{'dnf'}->{'module'}}) {
      printf("モジュール%sを%sしています。\n", $module, $operation);
      my $err = `dnf -y module $operation $module 2>&1`;
      my $rc = $?;
      if ($rc) {
        die($err);
      }
    }
  }
}

sub daemon_control {
  my $data = shift;

  if (defined($data->{'daemon'}->{'restart'})) {
    foreach my $daemon (@{$data->{'daemon'}->{'restart'}}) {
      printf("%sを再起動しています。\n", $daemon);
      my $err = `systemctl restart $daemon 2>&1`;
      my $rc = $?;
      if ($rc) {
        die($err);
      }

      printf("%sの自動起動を有効化しています。\n", $daemon);
      $err = `systemctl enable $daemon 2>&1`;
      $rc = $?;
      if ($rc) {
        die($err);
      }
    }
  }

  if (defined($data->{'daemon'}->{'stop'})) {
    foreach my $daemon (@{$data->{'daemon'}->{'stop'}}) {
      printf("%sの自動起動を無効化しています。\n", $daemon);
      my $err = `systemctl disable $daemon 2>&1`;
      my $rc = $?;
      if ($rc) {
        die($err);
      }

      printf("%sを停止しています。\n", $daemon);
      $err = `systemctl stop $daemon 2>&1`;
      $rc = $?;
      if ($rc) {
        die($err);
      }
    }
  }
}

#
# インストール用
#
sub initialize_settings {
  my $data = shift;

  # 389ds インスタンス 作成
  create_389directoryserver($data);

  # ldap.conf 更新
  update_openldap_ldapconf();

  # 389ds 証明書 更新
  create_ldap_cert($data);

  # 389dsインスタンス 証明書 インポート
  update_389ds_slapd_cert($data);

  # mariadbの構築
  create_mariadb($data);

  # my.cnfの設定
  update_my_cnf($data);

  # DBの初期設定
  create_db_schema($data);

  # 製品の設定復旧
  restore_settings($data);

  # デーモンの再起動
  daemon_control({ 'daemon' => { 'restart' => [ 'dirsrv@389ds', 'mariadb', 'memcached' ] } });

  return 1;
}

#
# アップデート用
#
sub restore_settings {
  my $data = shift;

  # syslog-ng 起動設定
  update_syslogng_service($data);

  # httpd.conf 設定更新
  update_httpd_conf($data);

  # mpm_event.conf 設定更新
  update_mpm_conf($data);

  # config.ini 設定更新
  update_config_ini($data);

  # ssl.conf 設定更新
  update_ssl_conf($data);

  # php.conf session.saveコメントアウト
  update_php_conf;

  # php.ini 設定更新
  update_php_ini($data);

  # sudoers 設定更新
  update_sudoers($data);

  # syslog-ng/conf.d/secioss.conf 設定更新
  update_syslogng_conf($data);

  # パスワードファイルの更新
  update_passwd($data);

  # 認証チケットシークレット更新
  update_auth_tkt_conf($data);

  # seciossadmin/etc/hosts 設定更新
  update_seciossadmin_hosts($data);

  # sso/samoauth.conf 設定更新
  update_samoauth_conf($data);

  # welcomeconf 無効化
  update_welcomeconf($data);

  # secioss_ini.php 設定更新
  update_secioss_ini_php($data);

  # refreshtoken.conf 設定更新
  update_refreshtoken_conf($data);

  # ldap.conf 設定更新
  update_ldap_conf($data);

  # oauth_service/config.ini 設定更新
  update_oauth_service_config_ini($data);

  # lism.conf 設定更新
  update_lism_conf($data);

  # slapd.conf 設定更新
  update_slapd_conf($data);

  if ($data->{product}->{code} =~ /same|siam/) {
    # auth_memcookie.conf 設定更新
    update_auth_memcookie_conf($data);

    # authmemcookie.php 設定更新
    update_authmemcookie_php($data);

    # cacolabo.conf 設定更新
    update_cacolabo_conf($data);

    # report_crawler.conf 設定更新
    update_report_crawler_conf($data);

    # config.php 設定更新
    update_config_php($data);

    # kerb.conf 設定更新
    update_kerb_conf($data);

    # kerbextlogin.conf 設定更新
    update_kerbextlogin_conf($data);

    # kerblogin.conf 設定更新
    update_kerblogin_conf($data);

    # ldap.php 設定更新
    update_ldap_php($data);

    # ldap_write.php 設定更新
    update_ldapwrite_php($data);

    # oauth_auth/config.ini 設定更新
    update_oauth_auth_config_ini($data);

    # oidc/config.ini 設定更新
    update_oidc_config_ini($data);

    # sam.conf 設定更新
    update_sam_conf($data);

    # sam_external.conf 設定更新
    update_sam_external_conf($data);

    # saml20-idp-hosted.php 設定更新
    update_saml20_idp_hosted_php($data);

    # saml13-idp-hosted.php 設定更新
    update_shib13_idp_hosted_php($data);

    # saml20-sp-hosted.php 設定更新
    update_saml20_sp_hosted_php($data);

    # sso.conf 設定更新
    update_sso_conf($data);

    # OIDC {PrivateKey.pem,PublicKey.pem} 設定更新
    create_oidc_cert($data);

    # raddb/mods-available/ldap 設定更新
    update_radius_ldap($data);

    # radius_secioss.ini 設定更新
    update_radius_secioss_ini($data);

    # radius enable ファイル削除
    delete_radius_enable($data);
  }

  if ($data->{product}->{code} =~ /sime|siam/) {
    # cybozucsv.conf 設定更新
    update_cybozucsv_conf($data);

    # パスワード辞書更新
    update_pw_words($data);

    # lism-idp.conf 設定更新
    update_lism_idp_conf($data);

    # lism-slink.conf 設定更新
    update_lism_slink_conf($data);

    # lism-tenantcsv.conf 設定更新
    update_lism_tenantcsv_conf($data);

    # office365.csv 設定更新
    update_office365_csv($data);

    # simapi.conf 設定更新
    update_simapi_conf($data);

    # slapd.conf 設定更新
    update_slapd_conf($data);

    # template/lism.conf 設定更新
    update_template_lism_conf($data);

    # template/lism-rule.conf 設定更新
    update_template_lism_rule_conf($data);
  }

  # デーモンの再起動
  daemon_control({'daemon' => { 'restart' => [ 'httpd', 'syslog-ng', 'sim-server', 'sitaskctlr', 'sitaskmgr', 'php-fpm', ] } });

  return 1;
}

#
# メニューアイテム処理
#

# 簡単設定（現在未使用）
sub easy_settings {
  my $data = shift;

  # 項目の入力
  my $items = {
    'caption' => [
      "[かんたん設定]",
      $data->{product}->{name}." の動作に必要なすべてのソフトウェアを一台のサーバーで構成します。",
      "そのため、[かんたん設定]は運用サーバーの構築には不向きです。",
      "[かんたん設定]の中で以下のソフトウェアを再インストールし、初期化します。",
      "  * 389 DirectoryServer",
      "  * MariaDB",
    ],
    'inputs' => [
      {
        'id' => 'basedn',
        'name' => 'LDAP Base DN',
        'type' => 'text',
        'default' => 'dc=example,dc=com',
      },
      {
        'id' => 'binddn',
        'name' => 'LDAP Bind DN',
        'type' => 'text',
        'default' => 'cn=manager,dc=example,dc=com',
      },
      {
        'id' => 'agree',
        'custom_text' => '実行してよろしいですか？ [yes/no]',
        'type' => 'text',
        'format' => '^(yes)|(no)$',
      },
    ],
  };
  inputItems($items);

  my $fqdn = `hostname 2>&1`; chomp($fqdn);
  my $ldap_basedn = $items->{'inputs'}->[0]->{'value'};
  my $ldap_binddn = $items->{'inputs'}->[1]->{'value'};
  my $ldap_bindpw = String::Random->new->randregex('[A-Za-z0-9]{8}');
  my $db_user = 'dbuser';
  my $db_pw = String::Random->new->randregex('[A-Za-z0-9]{8}');
  my $admin_pw = String::Random->new->randregex('[A-Za-z0-9]{8}');

  if ($items->{'inputs'}->[2]->{'value'} !~ /yes/i) {
    printf("\n何も行われませんでした。\n");
    return 1;
  }

  # 初期パスワード保存
  my $passwords = '';
  $passwords .= sprintf("Hostname:           %s\n", $fqdn);
  $passwords .= sprintf("LDAP Bind DN:       %s\n", $ldap_binddn);
  $passwords .= sprintf("LDAP Bind Password: %s\n", $ldap_bindpw);
  $passwords .= sprintf("DB User:            %s\n", $db_user);
  $passwords .= sprintf("DB Password:        %s\n", $db_pw);
  $passwords .= sprintf("管理者ユーザー:     %s\n", 'admin');
  $passwords .= sprintf("管理者Password:     %s\n", $admin_pw);

  my $file = '/tmp/init_password';
  sysopen(my $fh, $file, O_CREAT|O_WRONLY|O_TRUNC) or die("failed to open: $file : $!");
  printf($fh "%s", $passwords);
  close($fh);

  # 設定更新
  $data = { %$data, (
    'fqdn' => {
      'fqdn' => $fqdn,
    },
    'visudo' => {
      'requiretty' => 'yes',
      'exec_in_apache' => 'yes',
    },
    'pw_words' => {
      'agree' => 'yes',
    },
    'ldap' => {
      'uri' => 'ldap://localhost',
      'basedn' => $ldap_basedn,
      'binddn' => $ldap_binddn,
      'bindpw' => $ldap_bindpw,
    },
    'mysql' => {
      'host' => 'localhost',
      'port' => 3306,
      'admin' => 'root',
      'admin_password' => '',
      'user' => $db_user,
      'password' => $db_pw,
    },
    'memcached' => {
      'hosts' => [
        {
          'host' => 'localhost',
          'port' => 11211,
        }
      ]
    },
    'function' => {
      'office365' => 'no',
      'gakunin' => 'yes',
    },
    'general' => {
      'admin_password' => $admin_pw,
    },
  )};

  # 初期化
  initialize_settings($data);

  # 初期パスワード表示
  printf("\n");
  printf("各機能の初期パスワードは下記の通りです。\n");
  printf("%s", $passwords);

  # 設定項目の保存
  update_settings($data);

  return 1;
}

sub config_fqdn {
  my $data = shift;

  my $file = '/etc/httpd/conf.d/ssl.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };

  my $fqdn;
  if ($contents =~ /^ServerName\s+([-_.0-9A-Za-z]{1,255})(?::[0-9]+)?/gm) {
    $fqdn = $1;
  }

  my $domain = '';
  if ($data->{product}->{code} =~ /same|siam/) {
    $file = Config::IniFiles->new( -file => "/var/www/conf/config.ini", -fallback => "GENERAL", -nomultiline => 1 ) or die "failed to open: @Config::IniFiles::errors";
    $domain = ini_getval($file, "autologin", 'domain');
  }

  if (!defined($fqdn)) {
    # 各種設定ファイルから取得できない場合は hostname コマンドから取得する
    $fqdn = `hostname 2>&1`;
    chomp($fqdn);
    if ($data->{product}->{code} =~ /same|siam/) {
      if ($fqdn =~ /[^.]+\.(.+)/) {
        $domain = $1;
      }
    }
  }

  # 項目の入力
  my $items = {
    'caption' => "FQDNの設定を行います。",
    'inputs' => [
      {
        'id' => 'fqdn',
        'name' => 'FQDN',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?$',
        'default' => $fqdn,
      },
      {
        'id' => 'domain',
        'name' => 'ドメイン名',
        'type' => 'text',
        'default' => $domain,
        'visible' => sub {
          return $data->{product}->{code} =~ /same|siam/;
        },
      },
    ],
    'check' => sub {
      if ($data->{product}->{code} =~ /same|siam/) {
        my $input_map = shift;

        my $fqdn_tmp = $input_map->{'fqdn'}->{'value'};
        my $domain_tmp = $input_map->{'domain'}->{'value'};

        $fqdn_tmp =~ s/^([-_.0-9A-Za-z]{1,255})(?::[0-9]{1,5})?$/$1/;

        if ($fqdn_tmp !~ (quotemeta($domain_tmp) . '\z')) {
          printf("'FQDN'は'ドメイン名'で終わっている必要があります。[%s][%s]\n", $fqdn_tmp, $domain_tmp);
          return 0;
        }
      }

      return 1;
    },
  };
  inputItems($items);

  # 設定更新
  $data = { %$data, (
    'fqdn' => {
      'fqdn' => $items->{'inputs'}->[0]->{'value'},
      'domain' => $items->{'inputs'}->[1]->{'value'},
    }
  ) };

  if ($data->{'fqdn'}->{'fqdn'} =~ /^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/) {
    $data->{'fqdn'}->{'fqdn'} = $1;
    if ($2 && $2 ne '443') {
      $data->{'fqdn'}->{'port'} = $2;
    }
  }

  # httpd.conf 設定更新
  update_httpd_conf($data);

  # mpm_event.conf 設定更新
  update_mpm_conf($data);

  # ssl.conf 設定更新
  update_ssl_conf($data);

  # seciossadmin/etc/hosts 設定更新
  update_seciossadmin_hosts($data);

  # welcomeconf 無効化
  update_welcomeconf($data);

  if ($data->{product}->{code} =~ /same|siam/) {
    # sso.conf 設定更新
    update_sso_conf($data);

    # sam.conf 設定更新
    update_sam_conf($data);

    # sam_external.conf 設定更新
    update_sam_external_conf($data);

    # kerb.conf 設定更新
    update_kerb_conf($data);

    # kerblogin.conf 設定更新
    update_kerblogin_conf($data);

    # kerbextlogin.conf 設定更新
    update_kerbextlogin_conf($data);

    # secioss_ini.php 設定更新
    update_secioss_ini_php($data);

    # config.ini 設定更新
    update_config_ini($data);

    # saml20-idp-hosted.php 設定更新
    update_saml20_idp_hosted_php($data);

    # saml20-sp-hosted.php 設定更新
    update_saml20_sp_hosted_php($data);
  }

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub config_visudo {
  my $data = shift;

  # 項目の入力
  my $items = {
    'caption' => "sudoの設定変更を行います。",
    'inputs' => [
      {
        'id' => 'requiretty',
        'custom_text' => 'requirettyを無効にします。よろしいですか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
      },
      {
        'id' => 'exec_in_apache',
        'custom_text' => 'apacheユーザーにコマンド実行時の昇格権限を付与します。よろしいですか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
      },
    ],
  };
  inputItems($items);

  my $use = $items->{'inputs'}->[0]->{'value'};

  $data = { %$data, (
    'visudo' => {
      'requiretty' => $items->{'inputs'}->[0]->{'value'},
      'exec_in_apache' => $items->{'inputs'}->[1]->{'value'},
    }
  ) };

  # sudoers 設定更新
  update_sudoers($data);

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub create_pw_words {
  # 項目の入力
  my $items = {
    'caption' => "パスワード辞書ファイルを作成します。",
    'inputs' => [
      {
        'id' => 'agree',
        'custom_text' => 'yumリポジトリから最新の辞書ファイルをインストールします。よろしいですか？[yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
      },
    ],
  };
  inputItems($items);

  # 設定更新
  my $data = {
    'pw_words' => {
      'agree' => $items->{'inputs'}->[0]->{'value'},
    }
  };

  # パスワード辞書更新
  update_pw_words($data);

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub config_ldap {
  my $data = shift;

  my $ldapuri = '';
  my $basedn = '';
  my $binddn = '';
  my $bindpw = '';
  my $option = '';

  my $file = '';
  my $contents = '';

  if ($data->{product}->{code} =~ /same|siam/) {
    $file = Config::General->new('/var/www/conf/sam.conf') or die "failed to open: $!";
    my %conf = $file->getall;

    $ldapuri = $conf{'uri'} or die("failed to read sam configuration");
    $basedn = $conf{'basedn'} or die("failed to read sam configuration");
    $binddn = $conf{'admin'} or die("failed to read sam configuration");
    $bindpw = $conf{'passwd'} or die("failed to read sam configuration");
  }

  $file = '/opt/secioss/etc/lism.conf';
  sysopen(my $fh, $file, O_RDWR) or die("failed to open: $file : $!");
  $contents = do { local $/ = '\0'; <$fh> };
  close($fh);
  if ($contents !~ /<storage [^>]*name="SLDAP"[^>]*>(.*?)<\/storage>/s) {
    die("failed to get ldap configuration");
  }
  my $inner_storage = $1;
  if ($inner_storage !~ /<uri>(ldaps?:\/\/[^\/]+)\/([^<]*)<\/uri>/) {
    die("failed to get ldap uri configuration");
  }
  $ldapuri = $1;
  $basedn = $2;
  if ($inner_storage !~ /<binddn>([^<]+)<\/binddn>/) {
    die("failed to get ldap binddn configuration");
  }
  $binddn = $1;
  if ($inner_storage !~ /<bindpw>([^<]+)<\/bindpw>/) {
    die("failed to get ldap bindpw configuration");
  }
  $bindpw = $1;

  # 項目の入力
  my $items = {
    'caption' => "LDAPサーバーの設定を行います。",
    'inputs' => [
      {
        'id' => 'option',
        'custom_text' => "接続先LDAPの種類を数字で選択してください。\n 1 ... 389 Directory Server\n 2 ... OpenLDAP\n",
        'type' => 'text',
        'format' => '^(?:1|2)$',
      },
      {
        'id' => 'ldapuri',
        'name' => 'LDAP-URI',
        'type' => 'text',
        'format' => '^ldaps?://[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?$',
        'default' => $ldapuri,
      },
      {
        'id' => 'basedn',
        'name' => 'BaseDN',
        'type' => 'text',
        'default' => $basedn,
      },
      {
        'id' => 'binddn',
        'name' => 'BindDN',
        'type' => 'text',
        'default' => $binddn,
      },
      {
        'id' => 'bindpw',
        'name' => 'Password',
        'type' => 'password',
      },
    ],
    'check' => sub {
      my $input_map = shift;

      my $ldap = Net::LDAP->new($input_map->{'ldapuri'}->{'value'});
      if (!defined($ldap)) {
        printf("LDAPサーバーへの接続に失敗しました。[%s]\n", $input_map->{'ldapuri'}->{'value'});
        return 0;
      }

      if (defined($input_map->{'bindpw'}->{'value'}) && $input_map->{'bindpw'}->{'value'} =~ /#/ ) {
        printf("パスワードに「#」は使えません。[%s]\n", $input_map->{'bindpw'}->{'value'});
        return 0;
      }

      my $msg = $ldap->bind($input_map->{'binddn'}->{'value'}, password => $input_map->{'bindpw'}->{'value'});
      if($msg->code) {
        printf("LDAPサーバーの認証に失敗しました。[%s][%s]\n", $msg->code, $msg->error);
        return 0;
      }

      $msg = $ldap->search(base => $input_map->{'basedn'}->{'value'}, filter => '(objectClass=*)', scope => 'one');
      if($msg->code) {
        printf("LDAPサーバーの検索に失敗しました。[%s][%s]\n", $msg->code, $msg->error);
        return 0;
      }

      $ldap->unbind;

      return 1;
    },
  };
  inputItems($items);

  $option = $items->{'inputs'}->[0]->{'value'} eq '1' ? 'vlvNoOrder' : 'vlv';

  # 設定更新
  $data = { %$data, (
    'ldap' => {
      'option' => $option,
      'uri' => $items->{'inputs'}->[1]->{'value'},
      'basedn' => $items->{'inputs'}->[2]->{'value'},
      'binddn' => $items->{'inputs'}->[3]->{'value'},
      'bindpw' => $items->{'inputs'}->[4]->{'value'},
    }
  ) };

  if ($data->{product}->{code} =~ /same|siam/) {
    # sam.conf 設定更新
    update_sam_conf($data);

    # sam_external.conf 設定更新
    update_sam_external_conf($data);

    # oauth_auth/config.ini 設定更新
    update_oauth_auth_config_ini($data);

    # oidc/config.ini 設定更新
    update_oidc_config_ini($data);

    # ldap.php 設定更新
    update_ldap_php($data);

    # ldap_write.php 設定更新
    update_ldapwrite_php($data);

    # cacolabo.conf 設定更新
    update_cacolabo_conf($data);

    # report_crawler.conf 設定更新
    update_report_crawler_conf($data);

    # OIDC {PrivateKey.pem,PublicKey.pem} 設定更新
    create_oidc_cert($data);

    # raddb/mods-available/ldap 設定更新
    update_radius_ldap($data);

    # radius_secioss.ini 設定更新
    update_radius_secioss_ini($data);
  }

  if ($data->{product}->{code} =~ /sime|siam/) {
    # lism-tenantcsv.conf 設定更新
    update_lism_tenantcsv_conf($data);

    # template/lism.conf 設定更新
    update_template_lism_conf($data);

    # template/lism-rule.conf 設定更新
    update_template_lism_rule_conf($data);

    # simapi.conf 設定更新
    update_simapi_conf($data);

    # lism-idp.conf 設定更新
    update_lism_idp_conf($data);

    # lism-slink.conf 設定更新
    update_lism_slink_conf($data);
  }

  # ldap.conf 設定更新
  update_ldap_conf($data);

  # oauth_service/config.ini 設定更新
  update_oauth_service_config_ini($data);

  # secioss_ini.php 設定更新
  update_secioss_ini_php($data);

  # config.ini 設定更新
  update_config_ini($data);

  # lism.conf 設定更新
  update_lism_conf($data);

  # slapd.conf 設定更新
  update_slapd_conf($data);

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub build_mysql {
  my $data = shift;

  # 現在の設定値の取得
  my $host = '';
  my $user = '';
  my $password = '';

  if ($data->{product}->{code} =~ /same|siam/) {
    my $file = Config::IniFiles->new( -file => "/usr/share/oidc/conf/config.ini", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

    $host = ini_getval($file, "GENERAL", 'db_host');
    $user = ini_getval($file, "GENERAL", 'db_user');
    $password = ini_getval($file, "GENERAL", 'db_pass');

    if (!defined($host) || !defined($user)) {
      die("failed to read mysql configuration");
    }
  }

  if ($data->{product}->{code} =~ /sime|siam/) {
    my $file = '/usr/share/seciossadmin/etc/secioss-ini.php';
    sysopen(my $fh, $file, O_RDONLY) or die("failed to open: $file : $!");
    my $contents = do { local $/ = '\0'; <$fh> };
    close($fh);

    if ($contents !~ /'db'\s*=>\s*\[\s*'host'\s*=>\s*'([^']+)',\s*'user'\s*=>\s*'([^']+)',\s*'password'\s*=>\s*'([^']+)',[^\]]+\]/s) {
      die("failed to read mysql configuration");
    }

    $host = $1;
    $user = $2;
    $password = $3;
  }

  # 項目の入力
  my $items = {
    'caption' => "DBサーバーの初期設定（テーブルの作成、接続ユーザーの作成など）を行います。",
    'inputs' => [
      {
        'id' => 'host',
        'name' => 'DBサーバー',
        'type' => 'text',
        'default' => $host,
        'format' => '^[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?$',
      },
      {
        'id' => 'admin',
        'name' => '管理者ユーザー',
        'type' => 'text',
        'default' => 'root',
      },
      {
        'id' => 'admin_password',
        'name' => '管理者ユーザーのパスワード',
        'type' => 'password',
        'nullable' => 1,
      },
      {
        'id' => 'user',
        'name' => $data->{product}->{name}.' からの接続に使用する接続ユーザー',
        'comment' => '存在しない場合は新規作成します。',
        'type' => 'text',
        'default' => $user,
      },
      {
        'id' => 'password',
        'name' => '接続ユーザーのパスワード',
        'type' => 'password',
      },
      {
        'id' => 'confirm',
        'name' => '接続ユーザーのパスワード(再入力)',
        'type' => 'password',
      },
    ],
    'check' => sub {
      my $input_map = shift;

      my $host = $input_map->{'host'}->{'value'};
      $host =~ s/^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/$1/;
      my $port = $2 || 3306;
      my $admin = $input_map->{'admin'}->{'value'};
      my $admin_password = $input_map->{'admin_password'}->{'value'};
      my $password = $input_map->{'password'}->{'value'};
      my $confirm = $input_map->{'confirm'}->{'value'};

      if ($password ne $confirm) {
        printf("入力されたパスワードが一致しません。\n");
        return 0;
      }

      #  MySQL接続テスト
      my $dbh = DBI->connect("DBI:mysql:host=$host;port=$port", $admin, $admin_password);
      if (!$dbh) {
        printf("MySQLサーバーへの接続に失敗しました。[%s:%d]\n", $host, $port);
        return 0;
      }
      $dbh->disconnect();

      return 1;
    },
  };
  inputItems($items);

  # 設定更新
  $host = $items->{'inputs'}->[0]->{'value'};
  $host =~ s/^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/$1/;
  my $port = $2 || 3306;

  $data = { %$data, (
    'mysql' => {
      'host' => $host,
      'port' => $port,
      'admin' => $items->{'inputs'}->[1]->{'value'},
      'admin_password' => $items->{'inputs'}->[2]->{'value'},
      'user' => $items->{'inputs'}->[3]->{'value'},
      'password' => $items->{'inputs'}->[4]->{'value'},
    }
  ) };

  if ($data->{'mysql'}->{'host'} =~ /^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/) {
    $data->{'mysql'}->{'host'} = $1;
    if ($2) {
      $data->{'mysql'}->{'port'} = $2;
    }
  }

  # DBの初期設定
  create_db_schema($data);

  # syslog-ng/conf.d/secioss.conf 設定更新
  update_syslogng_conf($data);

  # secioss-ini.php 設定更新
  update_secioss_ini_php($data);

  # oauth_service/config.ini 設定更新
  update_oauth_service_config_ini($data);

  # lism.conf 設定更新
  update_lism_conf($data);

  if ($data->{product}->{code} =~ /same|siam/) {
    # oidc/config.ini 設定更新
    update_oidc_config_ini($data);

    # config.php 設定更新
    update_config_php($data);

    # cacolabo.conf 設定更新
    update_cacolabo_conf($data);

    # report_crawler.conf 設定更新
    update_report_crawler_conf($data);
  }

  if ($data->{product}->{code} =~ /sime|siam/) {
    # cybozucsv.conf 設定更新
    update_cybozucsv_conf($data);
  }

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub config_mysql {
  my $data = shift;

  # 現在の設定値の取得
  my $file = '/usr/share/seciossadmin/etc/secioss-ini.php';
  sysopen(my $fh, $file, O_RDONLY) or die("failed to open: $file : $!");
  my $contents = do { local $/ = '\0'; <$fh> };
  close($fh);

  if ($contents !~ /'db'\s*=>\s*\[\s*'host'\s*=>\s*'([^']+)',\s*'user'\s*=>\s*'([^']+)',\s*'password'\s*=>\s*'([^']+)',[^\]]+\]/s) {
    die("failed to read mysql configuration");
  }
  my $host = $1;
  my $user = $2;
  my $password = $3;

  # 項目の入力
  my $items = {
    'caption' => "DBサーバーへの接続情報の設定を行います。",
    'inputs' => [
      {
        'id' => 'host',
        'name' => 'DBサーバー',
        'type' => 'text',
        'default' => $host,
        'format' => '^[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?$',
      },
      {
        'id' => 'user',
        'name' => '接続ユーザー',
        'type' => 'text',
        'default' => $user,
      },
      {
        'id' => 'password',
        'name' => '接続ユーザーのパスワード',
        'type' => 'password',
      },
    ],
    'check' => sub {
      my $input_map = shift;

      my $host = $input_map->{'host'}->{'value'};
      $host =~ s/^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/$1/;
      my $port = $2 || 3306;
      my $user = $input_map->{'user'}->{'value'};
      my $password = $input_map->{'password'}->{'value'};

      #  MySQL接続テスト
      my $dbh = DBI->connect("DBI:mysql:host=$host;port=$port", $user, $password);
      if (!$dbh) {
        printf("MySQLサーバーへの接続に失敗しました。[%s:%d]\n", $host, $port);
        return 0;
      }
      $dbh->disconnect();

      return 1;
    },
  };
  inputItems($items);

  # 設定更新
  $data = { %$data, (
    'mysql' => {
      'host' => $items->{'inputs'}->[0]->{'value'},
      'port' => 3306,
      'user' => $items->{'inputs'}->[1]->{'value'},
      'password' => $items->{'inputs'}->[2]->{'value'},
    }
  ) };

  if ($data->{'mysql'}->{'host'} =~ /^([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?$/) {
    $data->{'mysql'}->{'host'} = $1;
    if ($2) {
      $data->{'mysql'}->{'port'} = $2;
    }
  }

  # syslog-ng/conf.d/secioss.conf 設定更新
  update_syslogng_conf($data);

  # secioss-ini.php 設定更新
  update_secioss_ini_php($data);

  # oauth_service/config.ini 設定更新
  update_oauth_service_config_ini($data);

  # lism.conf 設定更新
  update_lism_conf($data);

  if ($data->{product}->{code} =~ /same|siam/) {
    # oidc/config.ini 設定更新
    update_oidc_config_ini($data);

    # config.php 設定更新
    update_config_php($data);

    # cacolabo.conf 設定更新
    update_cacolabo_conf($data);

    # report_crawler.conf 設定更新
    update_report_crawler_conf($data);

    # config.ini 設定更新
    update_config_ini($data);
  }

  if ($data->{product}->{code} =~ /sime|siam/) {
    # cybozucsv.conf 設定更新
    update_cybozucsv_conf($data);

    # microsoft365 license importer 設定更新
    if (-f '/opt/secioss/etc/microsoft365_license_importer.conf') {
      update_ms365_license_importer_conf($data);
    }
  }

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub config_memcached {
  my $data = shift;

  # 現在の設定値の取得
  my $file = Config::IniFiles->new( -file => "/etc/php-fpm.d/www.conf" ) or die "failed to open: @Config::IniFiles::errors";
  my $values = ini_getval($file, 'www', 'php_value[session.save_path]');
  my $default_value = '';
  while ($values =~ /(?:tcp\:\/\/)?([-_.0-9A-Za-z]{1,255}:[0-9]{1,5})(\?(\w+=[0-9]+)(&(\w+=[0-9]+))*)?/) {
    my $value = $1;
    $values = $';

    $default_value .= ',' if $default_value;
    $default_value .= $value;
  }
  if (!$default_value) {
    $default_value = 'localhost:11211';
  }

  # 項目の入力
  my $items = {
    'caption' => "memcachedサーバーの設定をします。",
    'inputs' => [
      {
        'id' => 'hosts',
        'name' => 'memcachedサーバー',
        'comment' => 'カンマ区切りで複数指定できます。',
        'type' => 'text',
        'default' => $default_value,
        'format' => '^[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?(,[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?)*$',
      },
    ],
    'check' => sub {
      my $input_map = shift;

      # memcached接続テスト
      my $hosts = $input_map->{'hosts'}->{'value'};
      while ($hosts =~ /([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?/) {
        my $host = $1;
        my $port = $2 || 11211;
        $hosts = $';

        my $memd = Cache::Memcached::libmemcached->new({ servers => [ $host.':'.$port ] });
        if (!defined($memd->stats) || !%{$memd->stats}) {
          printf("memcachedサーバーへの接続に失敗しました。[%s]\n", $host.':'.$port);
          return 0;
        }
        printf("memcachedサーバーへの接続に成功しました。[%s]\n", $host.':'.$port);
      }

      return 1;
    },
  };
  inputItems($items);

  # 設定更新
  $data = { %$data, (
    'memcached' => {
      'hosts' => [
      ]
    }
  ) };

  my $hosts = $items->{'inputs'}->[0]->{'value'};
  while ($hosts =~ /([-_.0-9A-Za-z]{1,255})(?::([0-9]{1,5}))?/) {
    my $host = $1;
    my $port = $2 || 11211;
    $hosts = $';

    push(@{$data->{'memcached'}->{'hosts'}}, {'host' => $host, 'port' => $port});
  }

  # php.ini 設定更新
  update_php_ini($data);

  # secioss-ini.php 設定更新
  update_secioss_ini_php($data);

  # php.conf session.saveコメントアウト
  update_php_conf;

  # oauth_service/config.ini 設定更新
  update_oauth_service_config_ini($data);

  if ($data->{product}->{code} =~ /same|siam/) {
    # sam.conf 設定更新
    update_sam_conf($data);

    # sam_external.conf 設定更新
    update_sam_external_conf($data);

    # config.php 設定更新
    update_config_php($data);

    # authmemcookie.php 設定更新
    update_authmemcookie_php($data);

    # auth_memcookie.conf 設定更新
    update_auth_memcookie_conf($data);

    # radius_secioss.ini 設定更新
    update_radius_secioss_ini($data);
  }

  # oauth_auth/config.ini 設定更新
  update_oauth_auth_config_ini($data);

  if ($data->{product}->{code} =~ /sime|siam/) {
    # simapi.conf 設定更新
    update_simapi_conf($data);
  }

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub config_function {
  my $data = shift;

  # 現在の設定値の取得
  my $use_gakunin = 0;
  {
    my $file = '/usr/share/seciossadmin/etc/secioss-ini.php';
    sysopen(my $fh, $file, O_RDONLY) or die("failed to open: $file : $!");
    my $contents = do { local $/ = '\0'; <$fh> };
    close($fh);
    $use_gakunin = ($contents !~ /\/\*\s*BEGIN_FUNCTION_GAKUNIN\s*$/m);
  }
  my $use_privilegedid = 0;
  if( -f '/etc/cron.d/privilegedid.cron'){
    $use_privilegedid = 1;
  }
  my $use_radius = 0;
  if( -f '/etc/cron.d/updateradius.cron'){
    $use_radius = 1;
  }

  # 項目の入力
  my $items = {
    'caption' => $data->{product}->{name}." の機能の有効/無効を切り替えます。",
    'inputs' => [
      {
        'id' => 'office365',
        'custom_text' => 'Office 365連携を使用しますか？ [yes/no]',
        'type' => 'text',
        'default' => (-f '/opt/secioss/etc/office365csv.conf') ? 'yes' : 'no',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|siam/;
        },
      },
      {
        'id' => 'gakunin',
        'custom_text' => '学認を使用しますか？ [yes/no]',
        'type' => 'text',
        'default' => $use_gakunin ? 'yes' : 'no',
        'format' => '^(yes)|(no)$',
      },
      {
        'id' => 'radius',
        'custom_text' => 'RADIUS機能を使用しますか？ [yes/no]',
        'type' => 'text',
        'default' => $use_radius ? 'yes' : 'no',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /same|siam/;
        },
      },
    ],
  };
  inputItems($items);

  $data = { %$data, (
    'function' => {
      'office365' => $items->{'inputs'}->[0]->{'value'},
      'gakunin' => $items->{'inputs'}->[1]->{'value'},
      'radius' => $items->{'inputs'}->[2]->{'value'},
    }
  ) };

  if ($data->{product}->{code} =~ /sime|siam/) {
    # office365.csv 設定更新
    update_office365_csv($data);
  }

  # secioss_ini.php 設定更新
  update_secioss_ini_php($data);

  if ($data->{product}->{code} =~ /same|siam/) {
    # cronの有効化
    update_cron('report_crawler.cron', 'yes');
  }

  if(defined $data->{'function'}->{'radius'}) {
    # cronの有効化
    update_cron('updateradius.cron', $data->{'function'}->{'radius'});

    # radius enable ファイル削除
    delete_radius_enable($data);
  }

  # 学認の機能有効化でJavaのインストール
  if ($data->{'function'}->{'gakunin'} =~ /yes/i) {
    dnf_control({ 'dnf' => { 'packages' => [ 'java-1.8.0-openjdk' ] } }, 'install');
  }

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub config_office365 {
  my $data = shift;

  # 現在の設定値の取得
  my $file = Config::IniFiles->new( -file => "/opt/secioss/etc/office365csv.conf", -fallback => "GENERAL" ) or die "failed to open: @Config::IniFiles::errors";

  my $host = ini_getval($file, "GENERAL", 'host');
  my $sshuser = ini_getval($file, "GENERAL", 'sshuser');

  # 項目の入力
  my $items = {
    'caption' => "Office 365連携サーバーの設定をします。Office 365連携を行わない場合は不要です。",
    'inputs' => [
      {
        'id' => 'host',
        'name' => 'Office 365連携サーバー',
        'type' => 'text',
        'default' => $host,
        'format' => '^[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?(,[-_.0-9A-Za-z]{1,255}(:[0-9]{1,5})?)*$',
      },
      {
        'id' => 'ssh_user',
        'name' => 'SSH接続ユーザー',
        'type' => 'text',
        'default' => $sshuser,
      },
    ],
    'check' => sub {
      my $input_map = shift;

      my $host = $input_map->{'host'}->{'value'};
      my $ssh_user = $input_map->{'ssh_user'}->{'value'};

      # Office 365連携サーバー接続テスト
      printf("\nOffice 365連携サーバーへ接続確認しています。\n");


      # SSH
      my $msg = `sudo -u apache ssh $ssh_user\@$host echo 2>&1`;
      my $rc = $?;
      chomp($msg);
      if ($rc) {
          printf("Office 365連携サーバーへのssh接続に失敗しました。[%d:%s]\n", $rc, $msg);
        return 0;
      }

      return 1;
    },
  };
  inputItems($items);

  $data = { %$data, (
    'office365' => {
      'host' => $items->{'inputs'}->[0]->{'value'},
      'sshuser' => $items->{'inputs'}->[1]->{'value'},
    }
  ) };

  # secioss-ini.php 設定更新
  update_secioss_ini_php($data);

  # office365.conf 設定更新
  update_office365_conf($data);

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub set_admin_password {
  my $data = shift;

  # 項目の入力
  my $items = {
    'caption' => "管理画面の管理者(admin)パスワードを設定します。",
    'inputs' => [
      {
        'id' => 'password',
        'name' => '管理者パスワード',
        'type' => 'password',
        'format' => '^[!-~]{1,32}$',
      },
      {
        'id' => 'confirm',
        'name' => '管理者パスワード(再入力)',
        'type' => 'password',
      },
    ],
    'check' => sub {
      my $input_map = shift;
      if ($input_map->{'password'}->{'value'} ne $input_map->{'confirm'}->{'value'}) {
        printf("入力されたパスワードが一致しません。\n");
        return 0;
      }
      return 1;
    },
  };
  inputItems($items);

  $data = { %$data, (
    'general' => {
      'admin_password' => $items->{'inputs'}->[0]->{'value'}
    }
  ) };

  # パスワードファイルの更新
  update_passwd($data);

  # 認証チケットシークレット更新
  update_auth_tkt_conf($data);

  if ($data->{product}->{code} =~ /same|siam/) {
    # radius_secioss.ini 設定更新
    update_radius_secioss_ini($data);
  }

  # 入力項目の保存
  update_settings($data);

  # sso/samoauth.conf 設定更新
  update_samoauth_conf($data);

  return 1;
}

sub set_admin_allowip {
  my $data = shift;

  # 項目の入力
  my $items = {
    'caption' => "管理画面へのログインを許可するIPアドレスを入力してください。",
    'inputs' => [
      {
        'id' => 'admin_allowip',
        'name' => '許可IPアドレス',
        'comment' => 'カンマ区切りで複数指定できます。すべて許可する場合は「*」を指定します。',
        'type' => 'text',
        'default' => '*',
        'format' => '^(?:\*|[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}(,[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})*)$',
      },
    ],
  };
  inputItems($items);

  $data = { %$data, (
    'adminconsole' => {
      'admin_allowip' => $items->{'inputs'}->[0]->{'value'}
    }
  ) };

  # secioss_ini.php 設定更新
  update_secioss_ini_php($data);

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub set_syslogng_service {
  my $data = shift;

  # 項目の入力
  my $items = {
    'caption' => "syslog-ngの再起動設定を行います。",
    'inputs' => [
      {
        'id' => 'syslog-ng',
        'custom_text' => 'syslog-ng.serviceへ再起動設定を追加しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
      },
    ],
  };
  inputItems($items);
  # 設定更新
  $data = {
    'syslogng' => {
      'servicefile_setting' => $items->{'inputs'}->[0]->{'value'},
    }
  };

  # 起動ファイルの設定変更
  update_syslogng_service($data);

  # 入力項目の保存
  update_settings($data);


  return 1;
}

sub config_samadminssh {
  my $data = shift;

  # 現在の設定値の取得
  my $user = 'root';
  my $port = '22';

  my $file = '/opt/secioss/etc/samadmin.conf';
  if (-e $file) {
    sysopen(my $fh, $file, O_RDONLY) or die("failed to open: $file : $!");
    my $contents = do { local $/ = '\0'; <$fh> };
    close($fh);

    if ($contents =~ /ssh_user\s*=\s*"([^"]+)"/s) {
      $user = $1;
    }
    if ($contents =~ /ssh_port\s*=\s*"([^"]+)"/s) {
      $port = $1;
    }
  }

  # 項目の入力
  my $items = {
    'caption' => [
      "冗長化構成時のSSH接続に使用する設定を変更します。",
      "※事前にSSH接続のための鍵作成、登録を行った上で実施してください。",
    ],
    'inputs' => [
      {
        'id' => 'user',
        'name' => '接続ユーザー',
        'type' => 'text',
        'default' => $user,
      },
      {
        'id' => 'port',
        'name' => '接続ポート',
        'type' => 'text',
        'default' => $port,
      },
    ],
  };
  inputItems($items);

  $data = { %$data, (
    'ssh' => {
      'user' => $items->{'inputs'}->[0]->{'value'},
      'port' => $items->{'inputs'}->[1]->{'value'},
    }
  ) };

  # SSH設定 設定更新
  update_samadminssh($data);

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub initialize_ldap {
  my $data = shift;

  # LDAPS通信用証明書作成
  my $country = 'JP';
  my $state = '';
  my $locality = '';
  my $organizational_name = '';
  my $organizational_unit = '';
  my $common_name = `hostname 2>&1`;
  my $items = '';
  chomp($common_name);

  if (-e '/opt/secioss/ldap/389ds/slapd.crt') {
    my $subject = `openssl x509 -in /opt/secioss/ldap/389ds/slapd.crt -text | grep Subject: 2>&1`;
    if ($? eq 0) {
      chomp($subject);
      $country = $1 if ($subject =~ /C\s*=\s*([^,]+),/);
      $state = $1 if ($subject =~ /ST\s*=\s*([^,]+),/);
      $locality = $1 if ($subject =~ /L\s*=\s*([^,]+),/);
      $organizational_name = $1 if ($subject =~ /O\s*=\s*([^,]+),/);
      $organizational_unit = $1 if ($subject =~ /OU\s*=\s*([^,]+),/);
      $common_name = $1 if ($subject =~ /CN\s*=\s*([^,]+?)$/);
    }
  }

  # 項目の入力

  $items = {
    'caption' => [
      "[389 Directory Server - 証明書作成]",
      "ldaps用証明書(自己署名)を作成します。",
      "作成が不要な場合はこの手順をスキップしても構いません。",
    ],
    'inputs' => [
      {
        'id' => 'create',
        'custom_text' => 'すでに存在する場合は上書きします。よろしいですか？ [yes/no]',
        'type' => 'text',
        'format' => '^(yes)|(no)$',
      },
      {
        'id' => 'country',
        'name' => '国名',
        'type' => 'text',
        'format' => '^[A-Za-z]{2}$',
        'default' => $country,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'state',
        'name' => '都道府県名',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $state,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'locality',
        'name' => '市区町村名',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $locality,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'organizational_name',
        'name' => '組織名',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $organizational_name,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'organizational_unit',
        'name' => '部門名',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $organizational_unit,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'common_name',
        'name' => 'コモンネーム',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $common_name,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'expiration_date',
        'name' => '証明書の有効期限(日)',
        'type' => 'text',
        'format' => '^[0-9]{1,5}$',
        'default' => '365',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'key_length',
        'name' => '秘密鍵の鍵長',
        'comment' => '[1024/2048]',
        'type' => 'text',
        'format' => '^(1024)|(2048)$',
        'default' => '2048',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
    ],
  };
  inputItems($items);

  # 設定更新
  $data = { %$data, (
    'ldap_cert' => {
      'create' => $items->{'inputs'}->[0]->{'value'},
      'country' => $items->{'inputs'}->[1]->{'value'},
      'state' => $items->{'inputs'}->[2]->{'value'},
      'locality' => $items->{'inputs'}->[3]->{'value'},
      'organizational_name' => $items->{'inputs'}->[4]->{'value'},
      'organizational_unit' => $items->{'inputs'}->[5]->{'value'},
      'common_name' => $items->{'inputs'}->[6]->{'value'},
      'expiration_date' => $items->{'inputs'}->[7]->{'value'},
      'key_length' => $items->{'inputs'}->[8]->{'value'},
    }
  ) };

  if ($items->{'inputs'}->[0]->{'value'} eq 'yes') {
    $data->{'ldap_cert'}->{'nss_password'} = String::Random->new->randregex('[A-Za-z0-9]{16}');
    $data->{'ldap_cert'}->{'pkcs12_password'} = String::Random->new->randregex('[A-Za-z0-9]{16}');
  }

  # 389ds 証明書 更新
  create_ldap_cert($data);

  # 入力項目の保存
  update_settings($data);

  print("\n\n次に 389 Directory Server の構築を行います。");
  print("\nPress Enter to continue.");
  while (<STDIN>) { last; }

  # 389 Directory Server インストール
  # 項目の入力
  $items = {
    'caption' => [
      "[389 Directory Server - インストール]",
      "本設定の実行により、本サーバーで稼働している389 Directory Serverが初期化されます。",
      "本サーバーで既に389 Directory Serverがインストールされている場合、バックアップを行ってください。",
    ],
    'inputs' => [
      {
        'id' => 'agree',
        'custom_text' => '389 Directory Serverを初期化、インストールします。実行してよろしいですか？ [yes/no]',
        'type' => 'text',
        'format' => '^(yes)|(no)$',
      },
      {
        'id' => 'basedn',
        'name' => 'LDAP BaseDN',
        'type' => 'text',
        'default' => 'dc=secioss,dc=ldap',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'binddn',
        'name' => 'LDAP Bind DN',
        'type' => 'text',
        'default' => 'cn=manager,dc=secioss,dc=ldap',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'password',
        'name' => 'LDAP Bind DN Password',
        'type' => 'password',
        'format' => '^[!-~]{1,32}$',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'confirm',
        'name' => 'LDAP Bind DN Password confirm',
        'type' => 'password',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'product',
        'custom_text' => '使用する製品を選択してください [same/sime/siam]',
        'type' => 'text',
        'format' => '^(same)|(sime)|(siam)$',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
    ],
    'check' => sub {
      my $input_map = shift;
      if(defined($input_map->{'password'}->{'value'})){
        if ($input_map->{'password'}->{'value'} ne $input_map->{'confirm'}->{'value'}) {
          printf("入力されたパスワードが一致しません。\n\n");
          return 0;
        }
      }
      return 1;
    },
  };
  inputItems($items);

  if ($items->{'inputs'}->[0]->{'value'} !~ /yes/i) {
    printf("\n389 Directory Server インストール処理を中止します。\n");
    return 1;
  }

  # 設定更新
  $data = { %$data, (
    'ldap' => {
      'create' => $items->{'inputs'}->[0]->{'value'},
      'basedn' => $items->{'inputs'}->[1]->{'value'},
      'binddn' => $items->{'inputs'}->[2]->{'value'},
      'bindpw' => $items->{'inputs'}->[3]->{'value'},
      'product' => $items->{'inputs'}->[5]->{'value'},
      'uri' => 'ldap://localhost',
    }
  ) };

  # セットアップ情報 保存
  my $setuplog = '/tmp/init_ldap_info';
  my $info = '';
  $info .= sprintf("LDAP Base DN      : %s\n", $items->{'inputs'}->[1]->{'value'});
  $info .= sprintf("LDAP Bind DN      : %s\n", $items->{'inputs'}->[2]->{'value'});
  $info .= sprintf("LDAP Bind Password: %s\n", $items->{'inputs'}->[3]->{'value'});
  $info .= sprintf("Secioss Product   : %s\n", $items->{'inputs'}->[5]->{'value'});
  sysopen(my $fh, $setuplog, O_CREAT|O_WRONLY|O_TRUNC) or die("failed to open: $setuplog : $!");
  printf($fh "%s", $info);
  close($fh);

  # 389ds インスタンス 作成
  create_389directoryserver($data);

  # ldap.conf 更新
  update_openldap_ldapconf();

  # 389dsインスタンス 証明書 インポート
  update_389ds_slapd_cert($data);

  # デーモンの再起動
  daemon_control({ 'daemon' => { 'restart' => [ 'dirsrv@389ds' ] } });

  # 初期情報表示
  printf("\n");
  printf("下記のLDAP情報を用いて、セシオス製品をセットアップしてください。\n\n");
  printf("%s", $info);

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub config_ldap_cert {
  my $data = shift;

  my $country = 'JP';
  my $state = '';
  my $locality = '';
  my $organizational_name = '';
  my $organizational_unit = '';
  my $common_name = `hostname 2>&1`;
  chomp($common_name);

  if (-e '/opt/secioss/ldap/389ds/slapd.crt') {
    my $subject = `openssl x509 -in /opt/secioss/ldap/389ds/slapd.crt -text | grep Subject: 2>&1`;
    if ($? eq 0) {
      chomp($subject);
      $country = $1 if ($subject =~ /C\s*=\s*([^,]+),/);
      $state = $1 if ($subject =~ /ST\s*=\s*([^,]+),/);
      $locality = $1 if ($subject =~ /L\s*=\s*([^,]+),/);
      $organizational_name = $1 if ($subject =~ /O\s*=\s*([^,]+),/);
      $organizational_unit = $1 if ($subject =~ /OU\s*=\s*([^,]+),/);
      $common_name = $1 if ($subject =~ /CN\s*=\s*([^,]+?)$/);
    }
  }

  my $file = '/etc/dirsrv/slapd-389ds/pin.txt';
  my $nss_password = '';
  if (defined $data->{'ldap_cert'}->{'nss_password'}) {
    # 構築時のパスワード読み込み
    $nss_password = $data->{'ldap_cert'}->{'nss_password'};
  } elsif(-e $file) {
    # pin.txt からパスワード読み込み
    sysopen(my $fh, $file, O_RDONLY | O_CREAT) or die("failed to open: $file : $!");
    my $contents = do { local $/ = '\0'; <$fh> };
    close($fh);
    $nss_password = $1 if ($contents =~ /Internal\s*\(Software\)\s*Token:(.*)$/);
  }

  # 項目の入力
  my $items = {
    'caption' => [
      "ldaps用証明書(自己署名)を作成します。",
    ],
    'inputs' => [
      {
        'id' => 'create',
        'custom_text' => 'すでに存在する場合は上書きします。よろしいですか？ [yes/no]',
        'type' => 'text',
        'format' => '^(yes)|(no)$',
      },
      {
        'id' => 'country',
        'name' => '国名',
        'type' => 'text',
        'format' => '^[A-Za-z]{2}$',
        'default' => $country,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'state',
        'name' => '都道府県名',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $state,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'locality',
        'name' => '市区町村名',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $locality,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'organizational_name',
        'name' => '組織名',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $organizational_name,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'organizational_unit',
        'name' => '部門名',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $organizational_unit,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'common_name',
        'name' => 'コモンネーム',
        'type' => 'text',
        'format' => '^[-_.0-9A-Za-z ]{1,64}$',
        'default' => $common_name,
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'expiration_date',
        'name' => '証明書の有効期限(日)',
        'type' => 'text',
        'format' => '^[0-9]{1,5}$',
        'default' => '365',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'key_length',
        'name' => '秘密鍵の鍵長',
        'comment' => '[1024/2048]',
        'type' => 'text',
        'format' => '^(1024)|(2048)$',
        'default' => '2048',
        'visible' => sub { my $inputs = shift; return $inputs->[0]->{'value'} eq 'yes'; },
      },
      {
        'id' => 'nss_password',
        'name' => '389DirectoryServer 証明書ストア パスワード',
        'format' => '^[0-9A-Za-z]+$',
        'type' => 'password',
        'default' => $nss_password,
        'visible' => sub { my $inputs = shift; return !$nss_password && ($inputs->[0]->{'value'} eq 'yes'); },
      },
    ],
  };
  inputItems($items);

  # 設定更新
  $data = { %$data, (
    'ldap_cert' => {
      'create' => $items->{'inputs'}->[0]->{'value'},
      'country' => $items->{'inputs'}->[1]->{'value'},
      'state' => $items->{'inputs'}->[2]->{'value'},
      'locality' => $items->{'inputs'}->[3]->{'value'},
      'organizational_name' => $items->{'inputs'}->[4]->{'value'},
      'organizational_unit' => $items->{'inputs'}->[5]->{'value'},
      'common_name' => $items->{'inputs'}->[6]->{'value'},
      'expiration_date' => $items->{'inputs'}->[7]->{'value'},
      'key_length' => $items->{'inputs'}->[8]->{'value'},
    }
  ) };

  if (defined $items->{'inputs'}->[9]->{'value'}) {
    $nss_password = $items->{'inputs'}->[9]->{'value'}
  }

  if ($items->{'inputs'}->[0]->{'value'} eq 'yes') {
    $data->{'ldap_cert'}->{'nss_password'} = $nss_password;
    $data->{'ldap_cert'}->{'pkcs12_password'} = String::Random->new->randregex('[A-Za-z0-9]{16}');
  }

  # 389ds 証明書 更新
  create_ldap_cert($data);

  # 389dsインスタンス 証明書 インポート
  update_389ds_slapd_cert($data);

  # 入力項目の保存
  update_settings($data);

  return 1;
}

sub restart_daemon {
  my $data = shift;

  # 項目の入力
  my $items = {
    'caption' => "サービスの再起動を行います。",
    'inputs' => [
      {
        'id' => 'httpd',
        'custom_text' => 'httpdを再起動しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'php-fpm',
        'custom_text' => 'php-fpmを再起動しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'syslog-ng',
        'custom_text' => 'syslog-ngを再起動しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'sim-server',
        'custom_text' => 'sim-serverを再起動しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'sitaskctlr',
        'custom_text' => 'sitaskctlrを再起動しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|siam/;
        },
      },
      {
        'id' => 'sitaskmgr',
        'custom_text' => 'sitaskmgrを再起動しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|siam/;
        },
      },
      {
        'id' => 'dirsrv@389ds',
        'custom_text' => '389 Directory Serverを再起動しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /ldap/;
        },
      },
    ],
  };
  inputItems($items);

  $data = { %$data, (
    'daemon' => {
      'restart' => []
    }
  ) };

  foreach my $item(@{$items->{'inputs'}}) {
    if (defined($item->{'visible'}) && ! $item->{'visible'}->()) {
      next;
    }
    my $service = $item->{'id'};
    my $value = $item->{'value'};
    if ($value =~ /yes/i) {
      push(@{$data->{'daemon'}->{'restart'}}, $service);
    }
  }

  # デーモンの再起動
  daemon_control($data);

  return 1;
}

sub stop_daemon {
  my $data = shift;

  # 項目の入力
  my $items = {
    'caption' => "サービスの停止を行います。",
    'inputs' => [
      {
        'id' => 'httpd',
        'custom_text' => 'httpdを停止しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'php-fpm',
        'custom_text' => 'php-fpmを停止しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'syslog-ng',
        'custom_text' => 'syslog-ngを停止しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'sim-server',
        'custom_text' => 'sim-serverを停止しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|siam/;
        },
      },
      {
        'id' => 'sitaskctlr',
        'custom_text' => 'sitaskctlrを停止しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|siam/;
        },
      },
      {
        'id' => 'sitaskmgr',
        'custom_text' => 'sitaskmgrを停止しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|siam/;
        },
      },
      {
        'id' => 'dirsrv@389ds',
        'custom_text' => '389 Directory Serverを停止しますか？ [yes/no]',
        'type' => 'text',
        'default' => 'yes',
        'format' => '^(yes)|(no)$',
        'visible' => sub {
          return $data->{product}->{code} =~ /ldap/;
        },
      },
    ],
  };
  inputItems($items);

  $data = { %$data, (
    'daemon' => {
      'stop' => []
    }
  ) };

  foreach my $item(@{$items->{'inputs'}}) {
    if (defined($item->{'visible'}) && ! $item->{'visible'}->()) {
      next;
    }
    my $service = $item->{'id'};
    my $value = $item->{'value'};
    if ($value =~ /yes/i) {
      push(@{$data->{'daemon'}->{'stop'}}, $service);
    }
  }

  # デーモンの停止
  daemon_control($data);

  return 1;
}

#
# メイン処理
#
sub main {
  my $data = shift;
  STDOUT->autoflush(1); # AutoFlush有効化

  ReadMode('cbreak');

  # シグナルハンドラーのセット
  $SIG{'INT'} = \&handler;
  $SIG{__DIE__} = \&handler;

  drawTitle($data);

  check_selinux($data); # SELinuxチェック

  my $menu_data = {
    'caption' => "設定する項目を選んでください。",
    'items' => [
      # {
      #   'id' => 'easy_settings',
      #   'name' => 'かんたん設定',
      # },
      {
        'id' => 'config_fqdn',
        'name' => 'FQDNの設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'config_visudo',
        'name' => 'visudoの設定変更',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'create_pw_words',
        'name' => 'パスワード辞書ファイルの作成',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|siam/;
        },
      },
      {
        'id' => 'config_ldap',
        'name' => 'LDAPサーバーへの接続設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'build_mysql',
        'name' => 'DBサーバーの初期設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'config_mysql',
        'name' => 'DBサーバーへの接続設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'config_memcached',
        'name' => 'memcachedサーバーへの接続設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'config_office365',
        'name' => 'Office 365連携サーバーへの接続設定',
        'visible' => sub {
          return ($data->{product}->{code} =~ /sime|same|siam/) && -f '/opt/secioss/etc/office365csv.conf';
        },
      },
      {
        'id' => 'config_function',
        'name' => '機能の設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'set_admin_password',
        'name' => '管理者パスワードの設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'set_admin_allowip',
        'name' => '管理画面IP制限設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'set_syslogng_service',
        'name' => 'syslog-ngの再起動設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /sime|same|siam/;
        },
      },
      {
        'id' => 'config_samadminssh',
        'name' => 'SSH接続設定',
        'visible' => sub {
          return $data->{product}->{code} =~ /same|siam/;
        },
      },
      {
        'id' => 'initialize_ldap',
        'name' => '389 Directory Server構築',
        'visible' => sub {
          return $data->{product}->{code} =~ /ldap/;
        },
      },
      {
        'id' => 'config_ldap_cert',
        'name' => '389 Directory Server用証明書再作成',
        'visible' => sub {
          return $data->{product}->{code} =~ /ldap/;
        },
      },
      {
        'id' => 'restart_daemon',
        'name' => 'サービスの再起動',
      },
      {
        'id' => 'stop_daemon',
        'name' => 'サービスの停止',
      },
      {
        'id' => 'end',
        'name' => '終了',
      },
    ]
  };

  while (1) {
    my $select_id = selectMenu($menu_data);

    if (!$select_id) {
      next;
    }
    elsif ($select_id eq 'end') {
      last;
    }
    else {
      my $r = eval "$select_id(".'$data)';
      my $error = $@;
      if ($error) {
        $error =~ s/\s+at\s+.*$//;
        warn $error;
      }
      elsif (!$r) {
        next;
      }
      else {
        foreach my $item (@{$menu_data->{'items'}}) {
          if ($item->{'id'} eq $select_id) {
            printf("\n\n%sが終了しました。\n", $item->{'name'});
          }
        }
      }
    }

    print("\n\nPress Enter to continue.");
    while (<STDIN>) { last; }
  }

  resetTerm();
}

#
# setup.pl option
# c ... 自動セットアップ
# r ... リストア
# f ... 読み込みに使用する setup.json のファイル名
#
my %opt;
getopts("crf:", \%opt);
my $configpath = "setup.json";
if (defined($opt{'f'})) {
  if (! -e $opt{'f'}) {
    die("指定されたファイルが見つかりません\n");
  }
  $configpath = $opt{'f'};
}

if (defined($opt{'c'})) {
  # for auto initialize
  my $data = read_settings();
  initialize_settings($data);
} elsif (defined($opt{'r'})) {
  # for restore
  my $data = read_settings();
  restore_settings($data);
} else {
  # for interactive command line
  my $data = read_settings($configpath);
  update_settings($data);
  $data = read_settings();
  main($data);
}
